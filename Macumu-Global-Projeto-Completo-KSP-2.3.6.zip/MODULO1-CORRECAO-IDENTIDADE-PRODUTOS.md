# Macumu Global — Correcção da identidade dos produtos

## Alterações desta versão

1. O catálogo inicial integrado na aplicação recebe IDs determinísticos SHA-256 com base em `sellerId`, `title` e `marketName`, normalizados. Assim, o mesmo item de demonstração recebe o mesmo ID em instalações diferentes.
2. A migração Room 3→4 mantém os registos existentes e converte IDs `legacy_` para IDs determinísticos. Em caso de colisão local, acrescenta o ID Room como sufixo para não violar o índice único.
3. O índice único `globalProductId` continua activo. O ID Room numérico permanece como chave local e não deve ser usado como identificador remoto.
4. Não foi usada migração destrutiva.

## Limite que permanece explicitamente

Produtos criados por vendedores recebem UUID no momento da criação. Para que esses produtos apareçam noutro dispositivo, ainda é necessário implementar o fluxo de publicação/consulta do catálogo central Firestore e aplicar regras de autorização para vendedores/administração. Esta alteração, isoladamente, não cria esse fluxo nem garante sincronização do catálogo.

## Validação

A alteração foi revista estruturalmente. Não foi possível executar Gradle/compilação Android neste ambiente porque o executável `gradle` não está instalado e o projecto não inclui `gradle-wrapper.jar`. A compilação e os testes continuam pendentes.
