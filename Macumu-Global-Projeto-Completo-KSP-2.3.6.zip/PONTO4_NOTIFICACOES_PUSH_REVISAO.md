MACUMU GLOBAL — PONTO 4: NOTIFICAÇÕES
REVISÃO DE ADAPTAÇÃO AO FIREBASE SPARK — 14/11/2026

Alterações desta revisão
- Adicionado PriceWatchWorker para verificar os preços locais dos produtos aprovados acompanhados pelo utilizador autenticado.
- Adicionado PriceWatchScheduler, com trabalho periódico WorkManager e requisito de conectividade.
- O worker regista alertas na tabela local notifications e tenta apresentar notificação Android usando o canal existente.
- Centralizada no worker a geração de alertas de preço; o ViewModel limita-se a registar observações e não cria o mesmo alerta em paralelo.
- Removida a dependência Android firebase-functions, que não é necessária para o cliente e não deve ser chamada a partir da aplicação.
- Removida a configuração de deploy de Cloud Functions do firebase.json para evitar uma implantação acidental no plano Spark.
- Mantidos FCM e registo de tokens como preparação futura para servidor autorizado. Não existe envio automático por evento Firestore no caminho Spark.

Limitações
- WorkManager tem intervalo mínimo de 15 minutos e execução oportunista; o Android pode atrasá-lo.
- A verificação usa preços que já chegaram ao catálogo local. Não rastreia preços directamente em lojas externas.
- Sem Cloud Functions/servidor, não há push remoto automático para alterações Firestore, campanhas ou pedidos.
- Não foram executados build Android, testes em dispositivo ou validação Firebase nesta revisão.

Próxima validação, após concluir os sete pontos do Módulo 1
- Build Android e correcção de erros.
- Confirmar permissão Android 13+ e canal de notificações.
- Confirmar agendamento WorkManager e comportamento offline/online.
- Confirmar que o alerta é apresentado uma única vez por descida relevante e fica no centro interno.
- Confirmar isolamento de acompanhamentos por UID e regras Firestore.
