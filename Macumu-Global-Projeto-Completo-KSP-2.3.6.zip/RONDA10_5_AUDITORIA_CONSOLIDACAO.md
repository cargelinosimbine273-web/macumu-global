# Macumu Global — Ronda 10.5
## Auditoria e consolidação do catálogo e dos conectores

### Objectivo
Rever a importação CSV, a identidade dos produtos, a fila Room/Firestore e as regras de actualização, mantendo a arquitectura sem serviços pagos e compatível com Firebase Spark.

### Correcções aplicadas

1. **Fila de sincronização por proprietário**
   - `catalog_sync_queue` passa a guardar `ownerUid`.
   - Consultas e processamento da fila são filtrados pelo UID autenticado.
   - O Worker só processa os itens da conta actualmente autenticada.
   - Migração Room 11 → 12 associa itens antigos ao proprietário do produto e remove entradas sem proprietário recuperável.

2. **Gravação local atómica**
   - Criação/actualização do produto e inclusão na fila são executadas numa transacção Room.
   - Evita que uma interrupção entre as duas operações deixe um produto sem intenção de sincronização.

3. **Reimportação de ofertas pendentes**
   - Uma oferta pendente do mesmo proprietário pode ser actualizada no Firestore.
   - A actualização remota limita-se aos campos editáveis pelo vendedor e não altera aprovação, classificação, avaliações ou propriedade.
   - Um produto já aprovado não é sobrescrito por uma importação. Se não houver alteração relevante, o resultado é `SEM_ALTERACOES`; se houver alteração relevante, a importação é bloqueada e a versão publicada é preservada.

4. **Validação reforçada**
   - Validação do identificador da origem e do identificador externo.
   - Limites de comprimento para título e identificador externo.
   - Validação de URLs HTTPS sem credenciais embutidas.
   - Verificação da sessão antes de cada item da importação.
   - Detecção de duplicações dentro do mesmo lote.

5. **Parser CSV**
   - Suporte a aspas escapadas, vírgulas e quebras de linha dentro de campos entre aspas.
   - Rejeição de cabeçalhos duplicados, linhas com número de colunas incompatível e aspas não fechadas.
   - Limite de entrada de 5 MB.
   - Validação de moeda e links opcionais.

6. **Relatório administrativo**
   - O resumo passa a distinguir produtos sincronizados, pendentes, falhados e sem alterações.
   - As ofertas sem taxa cambial continuam explicitamente identificadas antes da submissão; não são silenciosamente incluídas.

### Limitações e dependências externas
- Não foi activada nenhuma API de loja; os conectores comerciais continuam dependentes de autorização, API/feed e credenciais fornecidas pela plataforma.
- A aprovação de produtos continua protegida por custom claim `admin` e pelas Firestore Security Rules. As regras do repositório precisam de ser publicadas manualmente na consola Firebase.
- A sincronização Firestore requer autenticação e ligação à Internet; o armazenamento local permanece em Room.
- Produtos já aprovados não podem ser alterados pelo fluxo de importação do vendedor. Uma futura função de revisão administrativa deve criar uma proposta de alteração separada, se o negócio exigir esse fluxo.
- A fila local é durável; o relatório visual detalhado permanece no estado do ecrã e não constitui um arquivo histórico permanente após limpar dados/reinstalar a aplicação.
- Não existe envio push remoto automático nem servidor pago nesta ronda.

### Validação efectuada
- Revisão estática dos ficheiros Kotlin alterados.
- Compilação isolada do módulo `CatalogConnectors.kt` com `kotlinc`.
- Teste de execução do parser CSV: campos com vírgulas e quebras de linha entre aspas, uma linha válida e uma linha com preço inválido (resultado esperado confirmado).
- Pesquisa de chamadas antigas sem parâmetro de UID na fila de sincronização.
- Verificação das referências da migração Room 11 → 12.
- Verificação de integridade do arquivo ZIP após empacotamento.

### Validação não efectuada
- Não foi executada compilação Android/Gradle.
- Não foram executados testes unitários, instrumentados ou funcionais.
- Não foram publicadas regras no Firebase Console.
- Não foram chamadas APIs externas de fornecedores.

### Compatibilidade de custos
As alterações usam Room, Firestore, Firebase Authentication e WorkManager já presentes no projecto. Não adicionam Cloud Functions, Cloud Run, servidores externos ou serviços pagos.
