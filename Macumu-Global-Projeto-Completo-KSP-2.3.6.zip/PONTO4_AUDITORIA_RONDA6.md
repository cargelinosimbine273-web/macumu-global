# Macumu Global — Ponto 4 — Auditoria e correcções (Ronda 6)

## Correcções aplicadas nesta ronda

1. **Notificações idempotentes no Firestore:** a gravação da notificação Price Watch passou a usar uma transacção que cria o documento apenas se ainda não existir. Uma repetição do Worker já não repõe `isRead=false` numa notificação que o utilizador tenha marcado como lida.
2. **Menos operações no Firebase:** o PriceWatchWorker só grava o estado da watch no Room e no Firestore quando o preço observado ou o estado do alerta realmente muda. Deixou de actualizar `updatedAt` e escrever no Firestore em cada ciclo sem alterações.
3. **Histórico idempotente:** mantém-se a chave única local por produto/preço para evitar duplicação causada por repetição do mesmo ciclo.
4. **Sessão e propriedade:** o Worker continua a validar o UID antes das operações de conta e os documentos são escritos apenas no caminho do próprio utilizador.

## Limites técnicos que não podem ser removidos apenas por alterações no APK

- **Push remoto automático com Firebase Spark:** o Spark permite o cliente receber FCM e registar tokens, mas não fornece um emissor fiável de notificações disparado por eventos Firestore. Para push remoto automático é necessário um serviço de backend confiável (por exemplo, Cloud Functions com plano de facturação compatível ou servidor próprio). Não se deve colocar credenciais administrativas no APK.
- **Remoção de tokens quando não há rede:** o aplicativo guarda a remoção pendente e volta a tentar quando a mesma conta autentica novamente. Se o utilizador nunca voltar a entrar nessa conta, o cliente não tem autorização para apagar o documento depois de perder a sessão. O token local é invalidado através de `deleteToken()` quando o Firebase Messaging consegue executar a operação; falhas de rede/serviço continuam fora do controlo da aplicação.
- **Entrega de notificações no Android:** depende da permissão de notificações, dos canais, das definições de bateria e das políticas do sistema operativo. O aplicativo não pode forçar o Android a apresentar notificações se o utilizador as bloquear.
- **Preço externo:** Price Watch compara os preços existentes no catálogo sincronizado/local. Não consulta directamente AliExpress, Alibaba ou SHEIN sem API, feed autorizado ou integração contratual.
- **Frequência:** WorkManager respeita o mínimo de 15 minutos para trabalho periódico, mas o Android pode executar mais tarde por Doze, poupança de bateria ou falta de rede.
- **Publicação das regras:** as regras actualizadas estão no ficheiro indicado pelo `firebase.json`, mas precisam de ser publicadas na consola Firebase antes de produzirem efeito no projecto remoto.

## Validação

- ZIP verificado com `unzip -t`.
- Revisão estática dos ficheiros alterados realizada.
- Compilação Android e testes funcionais não executados nesta ronda. O projecto não contém `gradlew` e não existe instalação Gradle disponível neste ambiente. Os testes funcionais continuam adiados conforme a sequência definida para os sete pontos do Módulo 1.
