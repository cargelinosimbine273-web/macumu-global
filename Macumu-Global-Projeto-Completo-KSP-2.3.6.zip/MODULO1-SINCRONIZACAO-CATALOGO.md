# Módulo 1 — Sincronização e recuperação do catálogo

## Implementação incluída

- Fila durável `catalog_sync_queue` em Room para anúncios que aguardam envio.
- Migração Room 5 → 6 que cria apenas a tabela da fila; não apaga produtos, carrinho ou encomendas.
- Envio idempotente: se a primeira gravação no Firestore tiver sido concluída mas a resposta se perder, a repetição reconhece o documento pendente do mesmo vendedor e não cria duplicado.
- WorkManager com rede obrigatória: tentativa imediata ao abrir a aplicação e repetição periódica (mínimo permitido pelo WorkManager: 15 minutos).
- Repetição imediata quando uma conta autenticada é detectada.
- Listener Firestore para incorporar alterações/aprovações do catálogo ao Room enquanto a aplicação está aberta.
- Actualização dos produtos remotos preserva o ID local Room existente, evitando quebrar referências do carrinho.
- A consulta de catálogo continua limitada a produtos `isApproved == true` pelas regras Firestore.

## Limites importantes

- O WorkManager não promete execução exacta aos 15 minutos; Android pode adiar tarefas conforme bateria/rede.
- O listener em tempo real funciona enquanto a aplicação está activa. Em segundo plano, a fila é recuperada pelo WorkManager.
- A fila mantém a tentativa quando o utilizador está sem sessão; após autenticação, é agendada uma tentativa imediata.
- Não há remoção automática de produtos locais quando um documento remoto é apagado/rejeitado; essa política deve ser definida para não apagar anúncios locais/semente por engano.
- A sincronização depende de Firebase Authentication, Firestore e das regras publicadas para `products` já existentes no projecto.

## Validação

A alteração foi revista estruturalmente. Não foi possível executar `gradle :app:assembleDebug` neste ambiente porque o executável Gradle não está instalado e o projecto não inclui o wrapper completo. A compilação e os testes no dispositivo continuam pendentes.
