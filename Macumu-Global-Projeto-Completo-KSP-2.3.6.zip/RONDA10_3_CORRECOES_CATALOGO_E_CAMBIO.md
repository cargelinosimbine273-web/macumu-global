# Macumu Global — Ronda 10.3
## Sincronização cambial, histórico, detecção de catálogo antigo e relatório CSV

### Implementado nesta ronda
- As taxas cambiais continuam a ser guardadas localmente como contingência.
- O painel tenta ler e sincronizar a tabela partilhada `platformConfig/exchangeRates` no Firestore para administradores autenticados com custom claim `admin == true`.
- Cada gravação sincronizada tenta acrescentar um registo imutável em `platformConfig/exchangeRates/history`.
- O painel mostra os cinco registos mais recentes do histórico.
- As regras Firestore dos dois ficheiros de regras autorizam leitura/escrita apenas a administradores com custom claim; histórico não pode ser alterado nem apagado pelo cliente.
- O importador CSV agora produz relatório com número de linhas analisadas, linhas válidas, rejeições e motivo/linha para as primeiras rejeições apresentadas.
- Produtos importados recebem uma marca temporal da última importação; a lista administrativa sinaliza produtos importados sem actualização há mais de 30 dias.
- A importação de várias ofertas continua a ser processada pelo fluxo existente, preservando a identidade externa e evitando criar uma segunda listagem para a mesma origem/ID.

### Limites e condições
- A sincronização cambial só funciona depois de publicar `FIRESTORE_RULES_CATALOGO.txt` (ou o ficheiro indicado por `firebase.json`) e de as contas administrativas terem o custom claim `admin=true`. Não se deve contornar essa regra com escrita pública.
- Sem claim administrativo, as taxas permanecem locais no dispositivo; a aplicação apresenta mensagem de sincronização recusada/indisponível.
- O histórico é registado quando a escrita principal é aceite e a escrita de histórico também é autorizada; falha de histórico é comunicada separadamente.
- A marca de 30 dias é um indicador de antiguidade do último CSV importado, não uma confirmação de que o preço externo mudou. Não existe consulta automática a lojas externas nesta ronda.
- A importação em lote usa o mecanismo actual de gravação/queue por produto; não é uma transacção atómica global. Uma falha individual não deve ser interpretada como sucesso total.
- Não foram adicionados serviços pagos nem chamadas de câmbio externo.

### Validação
- Inspecção estática dos ficheiros alterados.
- ZIP será verificado com `unzip -t`.
- Não foi executada compilação Android: o projecto não contém `gradlew` e não há Gradle instalado neste ambiente.
- Não foram executados testes funcionais, conforme a sequência acordada.
