# Macumu Global — Módulo 1: Home Dashboard

## Melhorias e funcionalidades nesta entrega

- Cabeçalho com identidade Macumu Global e indicador da moeda MZN.
- Selector de âmbito Tudo, Moçambique e Global ligado aos filtros existentes.
- Carrossel de campanhas com um cartão de promoções activas calculado a partir dos produtos aprovados que têm preço promocional inferior ao preço normal.
- Categorias visuais ligadas ao filtro de categoria.
- Descobertas em destaque baseadas no campo `isFeatured`.
- Favoritos com persistência local no dispositivo através de SharedPreferences; estado visível nos cartões e secção própria na Home.
- Macumu Price Watch: o utilizador activa/desactiva o acompanhamento de um produto; o preço actual fica guardado como referência local. Quando uma actualização do catálogo apresentar preço inferior, é criada uma notificação interna para o perfil Comprador e o acompanhamento é removido.
- Recomendações transparentes baseadas nas categorias dos favoritos; sem favoritos, a selecção usa classificação e número de avaliações. Não é apresentada como IA.
- Aproveita o fluxo de notificações Room já existente para alertas internos.
- Mantida a grelha de catálogo, navegação e carrosséis de mercados existentes.
- Removida da Home a promessa de Escrow operacional não confirmada.

## Limitações importantes

- Favoritos e Price Watch são locais ao dispositivo/instalação; ainda não sincronizam entre dispositivos ou contas.
- O Price Watch depende de o catálogo ser actualizado na base de dados. Não consulta automaticamente preços externos nem executa verificações em segundo plano.
- As notificações são internas à aplicação, usando a tabela Room existente; não são notificações push do Firebase.
- Campanhas são derivadas dos dados de produtos disponíveis. Ainda não existe um painel remoto para criar/editar campanhas.
- Recomendações são regras locais simples, não um modelo de IA.
- A entrega foi alterada no código-fonte, mas não foi possível executar Gradle neste ambiente porque não existe Gradle instalado nem `gradlew` no ZIP. É obrigatório validar no GitHub Actions antes de considerar a versão compilada.

## Actualização Firebase / FCM (14-11-2026)

- `app/google-services.json` foi alinhado com o ficheiro descarregado do projecto Firebase `macumu-global` e com o package `com.aistudio.macumuglobal.hqvkrz`.
- Adicionada a dependência Firebase Cloud Messaging através do Firebase BoM.
- Adicionado `MacumuFirebaseMessagingService` para receber mensagens FCM e apresentá-las no canal Android da aplicação.
- Adicionado `PushTokenRegistrar` para registar o token do dispositivo em `users/{uid}/deviceTokens/{token}` quando existe sessão autenticada.
- Adicionado o canal de notificações e a solicitação da permissão `POST_NOTIFICATIONS` em Android 13 ou superior.

### Requisitos externos ainda necessários

1. Activar/confirmar Cloud Messaging no projecto Firebase.
2. Rever e publicar regras Firestore que permitam a cada utilizador ler/escrever apenas os seus próprios tokens em `users/{uid}/deviceTokens/{token}`. Não publicar regras genéricas: o projecto já usa outras colecções e as regras devem preservar os fluxos existentes.
3. Implementar uma função de servidor confiável (por exemplo, Cloud Functions) para enviar mensagens FCM. A aplicação Android apenas recebe mensagens; não deve conter credenciais administrativas para as enviar.
4. Configurar e validar a compilação no GitHub Actions. Não foi possível executar Gradle neste ambiente porque o Gradle Wrapper JAR não está presente e não há instalação local do Gradle.
5. Testar em dispositivo Android real, incluindo a autorização de notificações e o registo do token após login.

Esta actualização prepara a recepção e o registo de tokens FCM; não declara ainda notificações push de produção activas.
