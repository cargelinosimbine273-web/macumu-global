# Macumu Global — Módulo 1 / Ponto 1 consolidado

Esta entrega reúne, numa única árvore de projecto, as alterações acumuladas para identidade global dos produtos, catálogo central, moderação segura, fila de publicação e favoritos.

## Componentes incluídos

1. **Identidade global:** `ProductEntity.globalProductId` separa a identidade estável do produto do ID numérico local Room.
2. **Migrações Room:** versões 3→4 (identidade global), 4→5 (ownerUid) e 5→6 (fila de sincronização), sem migração destrutiva.
3. **Catálogo central:** produtos aprovados são descarregados do Firestore e incorporados no Room, preservando o ID local quando o produto já existe.
4. **Publicação offline:** a fila Room guarda publicações pendentes; WorkManager tenta novamente quando existe rede.
5. **Moderação:** a aplicação chama `moderateProduct`; a Cloud Function verifica o custom claim `admin == true` no servidor.
6. **Favoritos:** documentos em `users/{uid}/favorites/{globalProductId}`; a interface antiga continua a usar IDs Room locais, fazendo a resolução por `globalProductId`.
7. **Conta e dispositivo:** os caminhos `utilizadores/{uid}` e `users/{uid}/deviceTokens/{tokenId}` estão cobertos nas regras fornecidas.

## Correcção de consistência incluída nesta consolidação

O código anterior tentava usar `legacyLocalProductId` ou `productId` de um documento remoto quando o produto ainda não existia no Room do dispositivo actual. Isso é inseguro: IDs Room são locais e podem apontar para outro produto noutro telemóvel.

A consolidação remove esse fallback. Os favoritos remotos são resolvidos exclusivamente pelo `globalProductId`. Depois de o catálogo remoto ser incorporado no Room, a aplicação volta a resolver os favoritos da conta. Assim, nunca interpreta o ID local de outro dispositivo como se fosse um ID local deste dispositivo. A leitura de recuperação dos favoritos foi também deslocada para `Dispatchers.IO`, evitando bloquear a thread principal enquanto o Firestore responde.

## Estrutura Firestore esperada

- `products/{globalProductId}` — catálogo central.
- `users/{uid}/favorites/{globalProductId}` — favoritos de cada conta.
- `users/{uid}/deviceTokens/{tokenId}` — tokens dos dispositivos.
- `utilizadores/{uid}` — perfil já utilizado pela aplicação.

## Configuração de backend necessária

- Deploy de `functions/` com Firebase CLI.
- Configurar o custom claim `admin: true` na conta administrativa através de script seguro com Firebase Admin SDK.
- Publicar as regras de `FIRESTORE_RULES_CATALOGO.txt` apenas depois de confirmar que a Cloud Function está implantada e que os caminhos/colecções adicionais do projecto foram contemplados.
- Configurar Firebase Authentication e Firestore no mesmo projecto `macumu-global`.

## Limitações e validação

- Esta consolidação **não equivale a testes de execução**. A compilação Android, os testes instrumentados e a validação contra o Firebase real continuam pendentes.
- A actualização em tempo real do catálogo depende de a aplicação estar activa; WorkManager faz recuperação eventual em segundo plano, sujeito às políticas de bateria/rede do Android.
- O catálogo remoto só disponibiliza produtos aprovados; anúncios pendentes permanecem privados do vendedor/moderação conforme as regras.
- Favoritos de produtos que ainda não foram descarregados não são convertidos em IDs locais até o produto existir no catálogo local; a resolução é repetida após a actualização do catálogo.
- Produtos de demonstração/semente e anúncios de vendedores devem ter IDs globais estáveis e não devem ser publicados automaticamente como produtos reais sem validação do proprietário e origem.

## Ordem de validação posterior

1. Compilar `:app:assembleDebug` no GitHub Actions.
2. Verificar migração Room 3→6 com dados preservados.
3. Criar produto de vendedor e confirmar fila offline.
4. Repor Internet e confirmar publicação pendente.
5. Aprovar produto com conta admin e confirmar distribuição no catálogo.
6. Favoritar o produto em dois dispositivos com a mesma conta.
7. Remover favorito num dispositivo e confirmar remoção no outro.
8. Confirmar que contas diferentes não conseguem ler/escrever favoritos umas das outras.
