# Catálogo central — ponto 1

## O que esta alteração faz
- Mantém o Room como cache local/offline.
- Adiciona `ownerUid` à entidade de produto (Room v4 -> v5, migração não destrutiva).
- Ao iniciar a ViewModel, tenta descarregar do Firestore os produtos aprovados.
- Ao publicar um produto com sessão Firebase iniciada, tenta criar `products/{globalProductId}` como anúncio pendente.
- O identificador global é usado como ID do documento remoto; o ID numérico Room continua local.

## Requisitos de segurança
1. Aplicar `FIRESTORE_RULES_CATALOGO.txt` apenas depois de criar o custom claim `admin: true` nas contas administrativas através de ambiente confiável (Admin SDK / Cloud Functions). Nunca atribuir claims a partir do cliente Android.
2. A aprovação remota exige claim `admin`. A aprovação local do ecrã administrativo não concede privilégios Firebase.
3. Produtos sem sessão autenticada permanecem locais e não são publicados na nuvem.

## Limitações ainda existentes
- A sincronização de catálogo é uma leitura pontual ao iniciar a ViewModel, não um listener em tempo real.
- Falhas de publicação ficam locais; ainda não existe fila persistente de retry.
- Os produtos de demonstração/seed não são enviados automaticamente para a nuvem.
- `sellerId` continua a ser um identificador legado numérico; a propriedade de segurança é `ownerUid`.
- Não foi executada compilação Android nem teste com Firestore real nesta preparação.
