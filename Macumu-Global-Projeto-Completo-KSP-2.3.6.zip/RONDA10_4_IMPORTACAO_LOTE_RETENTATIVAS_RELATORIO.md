# Macumu Global — Ronda 10.4
## Gestão de importações em lote, retentativas e relatório exportável

### Objectivo
Melhorar a rastreabilidade da importação CSV sem introduzir serviços pagos, Cloud Functions, Cloud Run ou credenciais administrativas no APK. A implementação utiliza Room, a fila local já existente e Firestore através do fluxo autenticado do catálogo.

### Alterações
1. **Resultado individual por produto** — cada oferta apresenta estado `NA_FILA`, `FALHOU`, `PENDENTE` ou `SINCRONIZADO`, com detalhe do resultado.
2. **Validação por item** — moeda MZN, preço finito/positivo, título e identificador externo são validados separadamente; uma linha com erro não interrompe o lote.
3. **Protecção de propriedade** — um produto cuja identidade está associada a outra conta não pode ser sobrescrito.
4. **Fila durável** — produtos gravados localmente entram na fila Room; falhas de Firestore permanecem na fila com contador de tentativas e última mensagem de erro.
5. **Retentativa manual** — o painel permite reprocessar a fila quando o utilizador está autenticado.
6. **Relatório CSV** — exportação dos resultados individuais através do selector de documentos Android.
7. **Comunicação transparente** — a interface distingue gravação local, sincronização Firestore e aprovação administrativa. Nenhum produto é automaticamente aprovado.

### Estados
- `NA_FILA`: gravado localmente e aguarda sincronização.
- `PENDENTE`: a sincronização falhou ou ainda não foi concluída; apresenta tentativas e erro quando disponível.
- `SINCRONIZADO`: removido da fila após envio ao Firestore; continua sujeito à aprovação.
- `FALHOU`: validação ou gravação local falhou.

### Compatibilidade de custos
Não foram adicionados serviços pagos nem novas dependências externas. O mecanismo utiliza o plano Firebase Spark, sujeito aos limites de utilização do Firestore e às regras publicadas no projecto.

### Limitações conhecidas
- A exportação contém os resultados de ofertas processadas pelo ViewModel; rejeições do parser CSV são apresentadas no resumo de leitura, mas ainda não são incorporadas como linhas individuais neste relatório.
- A indicação `SINCRONIZADO` significa que o envio para Firestore foi aceite e a entrada saiu da fila; não significa que o produto foi aprovado ou publicado.
- A execução de compilação Android e testes funcionais não foi realizada neste ambiente.
- O fluxo de sincronização requer sessão Firebase válida, conectividade e regras Firestore compatíveis/publicadas.

### Validação realizada
- Inspecção estática dos caminhos de importação, fila Room e painel administrativo.
- Verificação de consistência dos nomes dos estados e das ligações de callbacks.
- Integridade do ZIP verificada após empacotamento.
