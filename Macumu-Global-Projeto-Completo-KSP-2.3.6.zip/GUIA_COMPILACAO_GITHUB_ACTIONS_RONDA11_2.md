# Guia de compilação — Macumu Global / Ronda 11.2

## O que foi preparado

O workflow `.github/workflows/preparar-apk.yml` foi ajustado para:
- configurar Java 17;
- instalar Android SDK Platform 36.1, Build Tools 36.0.0 e Platform Tools;
- usar Gradle 9.3.1, compatível com o Android Gradle Plugin 9.1.1 declarado no catálogo;
- executar `:app:testDebugUnitTest` e `:app:assembleDebug`;
- disponibilizar o APK de depuração como artefacto, se a compilação terminar com sucesso;
- guardar os relatórios de testes mesmo se alguma etapa falhar.

## Como executar pelo telemóvel

1. Descarregue e extraia o ZIP da Ronda 11.2 no seu dispositivo ou computador.
2. Abra o repositório Macumu Global no GitHub.
3. Entre na pasta `.github/workflows` e abra `preparar-apk.yml`.
4. Substitua o conteúdo pelo ficheiro actualizado que acompanha esta versão, ou carregue o projecto completo actualizado para o repositório, preservando os restantes ficheiros.
5. Faça commit para a branch `main`.
6. No GitHub, abra o separador **Actions**.
7. Seleccione **Macumu Global - Build Android APK**.
8. Se o workflow não iniciar automaticamente, toque em **Run workflow**, escolha `main` e confirme.
9. Abra a execução mais recente e acompanhe cada etapa.
10. Se terminar em verde, abra a execução e descarregue os artefactos `Macumu-Global-APK` e `Macumu-Global-Relatorios-Testes`.

## Como interpretar o resultado

- **Verde / Success:** compilação debug e tarefa de testes unitários terminaram sem falha. Isto não substitui testes de instalação no telemóvel nem testes de integração com Firebase real.
- **Vermelho / Failure:** abra a primeira etapa vermelha, expanda os registos e partilhe o erro completo para diagnóstico.
- **APK ausente:** só é publicado quando `assembleDebug` termina com sucesso.

## Segurança e limites

- O workflow gera uma chave de assinatura **debug temporária** apenas para o APK de teste. Não é uma chave de lançamento da Play Store.
- Não carregue credenciais de serviço Firebase, chaves privadas ou ficheiros `.env` para o repositório.
- O workflow não publica regras Firestore e não altera o projecto Firebase.
- Nenhuma compilação foi executada nesta preparação; o resultado real depende da execução no GitHub Actions.
