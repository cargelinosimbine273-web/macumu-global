# Ponto 4 — Ronda 5: consistência, sincronização e limpeza FCM

## Correcções aplicadas

1. **Tokens FCM obsoletos e logout:** o token desta instalação é invalidado com `FirebaseMessaging.deleteToken()` no logout. A eliminação do documento em `users/{uid}/deviceTokens/{token}` é tentada enquanto a sessão antiga ainda está autenticada. Se falhar, o par UID/token fica numa fila local e é novamente tentado quando essa mesma conta iniciar sessão. A rotação de token usa a mesma fila, evitando abandonar silenciosamente documentos antigos.
2. **Sincronização da caixa de notificações:** notificações criadas pelo repositório passam a ser guardadas no Room e espelhadas em `users/{uid}/notifications/{eventKey}`. O Price Watch também espelha os seus alertas. O listener da conta importa os documentos para Room em outros dispositivos ou após reinstalação. A chave de evento evita inserir repetidamente o mesmo alerta local.
3. **Corrida no Price Watch:** o ViewModel deixou de actualizar `lastObservedPriceMzn` e de gravar histórico em paralelo. A observação, histórico e estado do alerta ficam sob responsabilidade do `PriceWatchWorker`, evitando que a interface antecipe o valor e faça o worker perder uma alteração.
4. **Histórico idempotente:** adicionada chave única `eventKey` ao histórico de preços, com migração Room 10→11 e inserção `IGNORE`, reduzindo duplicações quando o worker é repetido após interrupções.
5. **Regras Firestore:** acrescentadas regras para a caixa de notificações do próprio utilizador, incluindo validação do UID, chave do documento, tipo de destinatário e tipos dos campos. Aplicado nos dois ficheiros de regras do projecto.
6. **Ciclo de vida:** o listener de notificações na nuvem é removido quando a conta muda e quando o ViewModel é destruído.

## Limites que permanecem deliberadamente

- As regras alteradas estão apenas nos ficheiros do projecto. **Ainda não foram publicadas na consola Firebase**; até serem publicadas, a sincronização remota de notificações pode ser recusada pelas regras actualmente activas.
- A caixa de notificações é sincronizada por Firestore, mas isso **não equivale a envio remoto de push**. O APK regista/recebe tokens FCM; o envio automático a partir de eventos Firestore requer um emissor de confiança (por exemplo, Cloud Functions com plano Blaze ou servidor próprio). Não foram colocadas credenciais administrativas no APK.
- A fila local de tokens antigos só consegue apagar documentos quando a mesma conta voltar a autenticar-se. Se o utilizador nunca voltar, o documento antigo pode permanecer na nuvem; o token local, porém, é invalidado quando o serviço FCM aceita `deleteToken()`.
- A sincronização de histórico de preços continua local; esta ronda sincroniza a caixa de notificações e os acompanhamentos, não todo o histórico gráfico.
- Price Watch continua a analisar preços já presentes no catálogo local/sincronizado. Não consulta automaticamente Alibaba, AliExpress, SHEIN ou outras lojas sem APIs/feed autorizados.

## Validação

- Revisão estática dos ficheiros alterados e verificação de consistência dos caminhos de migração/regras.
- Não foi possível executar compilação Android: o projecto não contém o script `gradlew` e não há Gradle instalado neste ambiente.
- Não foram executados testes funcionais, respeitando a sequência definida: só depois de concluir os sete pontos do Módulo 1.
