# Ponto 4 — Revisão da Ronda 9: arquitectura estritamente gratuita (Firebase Spark)

## Decisão de arquitectura
O projecto deve permanecer no Firebase Spark, sem conta de facturação, sem Cloud Run, sem Cloud Functions e sem servidor externo pago ou de custo variável. Por isso, a proposta anterior de `push-server/` foi retirada: Cloud Run não está disponível no Spark e associar facturação pode mudar o projecto para Blaze.

## Comportamento real mantido nesta versão
- Price Watch corre no dispositivo através de WorkManager, respeitando o intervalo mínimo do Android.
- Quando o preço-alvo é atingido, o dispositivo que executou a verificação apresenta uma notificação Android local, mesmo que esteja temporariamente sem internet.
- O evento é guardado na caixa de notificações do utilizador em Firestore quando a ligação estiver disponível, com chave determinística para evitar duplicação e preservar o estado lido.
- Outros dispositivos da mesma conta recuperam a notificação dentro da aplicação através do listener Firestore.
- O registo de tokens FCM por instalação é mantido como preparação e gestão de dispositivos, mas não existe emissor automático remoto.
- Não há URL de servidor, chave de serviço, segredo administrativo nem chamada HTTP externa no APK.
- A moderação do catálogo usa escrita directa ao Firestore protegida por custom claim `admin: true` nas Security Rules, sem Cloud Function.

## Limitação assumida, sem promessas falsas
No Firebase Spark, FCM é um produto sem custo, mas isso não disponibiliza um backend de confiança para enviar automaticamente mensagens FCM em resposta a eventos Firestore. O envio manual pelo Firebase Console pode ser usado para comunicações pontuais, mas não substitui um emissor automático de eventos. O envio remoto automático fica adiado até existir receita e autorização explícita para escolher uma solução compatível com orçamento.

## Outras limitações do plano Spark
- Cloud Functions não podem ser implantadas no Spark. O código `moderateProduct` existente no directório `functions/` fica apenas como código-fonte futuro e não deve ser publicado enquanto o projecto permanecer no Spark.
- Cloud Firestore tem quotas gratuitas; ao excedê-las, o serviço pode ficar indisponível até ao próximo ciclo, conforme as regras do Spark.
- WorkManager não garante execução exacta a cada 15 minutos; Android pode atrasar tarefas por Doze, bateria ou restrições do fabricante.
- Price Watch acompanha apenas preços presentes/sincronizados no catálogo local; ainda não consulta directamente lojas externas.

## Alterações aplicadas nesta revisão
- Removido `push-server/` (Node.js, Express, Firebase Admin e instruções de Cloud Run).
- Removido `RemotePushClient.kt` e a chamada HTTP do `PriceWatchWorker`.
- Removida a propriedade Gradle `MACUMU_PUSH_API_URL` e a constante BuildConfig correspondente.
- Removida a dependência runtime da aplicação a callable Cloud Function para moderação; a aprovação usa regras Firestore e custom claim.
- Removido o script de deploy de Cloud Functions do package reservado e documentado que não deve ser implantado no Spark.
- Actualizados comentários e documentação para não sugerir que Cloud Run/Cloud Functions estão activos ou disponíveis no Spark.
- A notificação Android local passou a ser apresentada antes da sincronização remota, para funcionar também quando a rede está indisponível.

## Validação
- Revisão estática das referências ao servidor externo e callable functions: realizada.
- Verificação de ausência de `MACUMU_PUSH_API_URL`, `RemotePushClient`, `FirebaseFunctions`, `HttpsCallable` e `push-server` no runtime Android: realizada.
- Integridade do ZIP: verificada após empacotamento.
- Compilação Android e testes funcionais: não executados; o projecto não inclui `gradlew` e foi acordado adiar testes até concluir os sete pontos do Módulo 1.
