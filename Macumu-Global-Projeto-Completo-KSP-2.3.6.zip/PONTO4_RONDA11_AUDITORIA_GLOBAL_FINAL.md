# Macumu Global — Ponto 4 — Ronda 11
## Auditoria global e consolidação da arquitectura Spark

### Objectivo
Consolidar notificações, Price Watch, sincronização Room/Firestore, tokens FCM, permissões e regras de segurança, sem adicionar serviços pagos ou alterar o plano Firebase Spark.

### Correcções aplicadas nesta ronda

1. **Price Watch local-first**
   - O agendamento periódico deixou de exigir ligação à Internet.
   - O worker pode avaliar os preços que já estão em cache no Room e apresentar alertas locais mesmo quando o dispositivo está offline.
   - A verificação continua limitada aos preços existentes no catálogo Macumu; não é uma consulta em tempo real às lojas externas.

2. **Outbox durável de notificações**
   - Adicionado o campo `cloudSynced` à entidade local de notificações.
   - Criada a migração Room 12 → 13 sem apagar o histórico existente.
   - Criado `NotificationSyncWorker` para sincronizar notificações pendentes quando existe Internet.
   - Criado `NotificationSyncScheduler` com execução imediata e periódica, dependente apenas de rede disponível.
   - A criação local de notificações não depende de Firestore estar acessível.

3. **Sincronização de estado de leitura**
   - Marcar como lida actualiza primeiro Room e coloca a notificação novamente na fila de sincronização.
   - A interface de notificações passou a apresentar a acção «Marcar como lida» e o estado «Lida».
   - Uma notificação já lida num dispositivo não é automaticamente convertida para não lida por uma sincronização concorrente.
   - O listener remoto preserva alterações locais que ainda aguardam confirmação da nuvem.

4. **Sincronização de Price Watch**
   - O worker de sincronização também reconcilia os estados dos alertas de preço locais com a subcolecção Firestore da própria conta.
   - As gravações são filtradas pelo UID autenticado.

5. **Segurança Firestore**
   - Regras de notificações separaram criação e actualização.
   - O cliente só pode alterar `isRead` num documento de notificação já existente e pertencente à própria conta.
   - O conteúdo, proprietário, identificador e data de uma notificação não podem ser alterados pelo cliente após a criação.

6. **Fila de catálogo**
   - As operações de remoção e registo de falha da fila Room passaram a incluir também `ownerUid`, reforçando o isolamento por conta.

### Migração Room
- Versão anterior: 12.
- Nova versão: 13.
- Alteração: `notifications.cloudSynced INTEGER NOT NULL DEFAULT 0`.
- A migração mantém os registos anteriores e coloca-os na fila para sincronização, desde que tenham proprietário autenticado.

### Modelo de funcionamento dentro do Firebase Spark

- Room: armazenamento local, histórico e outbox.
- Firebase Authentication: identidade do utilizador.
- Firestore: sincronização da caixa de notificações, estado de leitura e preferências/Price Watch.
- FCM: registo de tokens e recepção de mensagens enviadas por um emissor autorizado.
- WorkManager: alertas locais e sincronização em segundo plano quando houver rede.
- Não são necessários Cloud Functions, Cloud Run, servidor externo, chave de serviço no APK ou plano Blaze para o fluxo implementado.

### Limites assumidos nesta fase de custo zero

1. **Push remoto automático:** não está activo. O FCM consegue receber mensagens e os tokens são registados, mas o Spark não fornece um emissor de confiança accionado por eventos Firestore. O Price Watch produz notificações locais e sincroniza a caixa de entrada quando há rede.
2. **Lojas externas:** o Price Watch não consulta AliExpress, Alibaba, SHEIN ou outras lojas em tempo real. Observa preços já presentes no catálogo local e sincronizado.
3. **Frequência:** WorkManager respeita as limitações do Android; o intervalo de 15 minutos é um mínimo configurado, não uma garantia de execução exacta.
4. **Permissões:** notificações Android dependem da permissão concedida pelo utilizador, especialmente no Android 13 ou superior.
5. **Firebase Console:** as regras incluídas no repositório ainda precisam de ser publicadas manualmente na consola Firebase. O código não consegue publicar regras por si só.
6. **Tokens FCM:** limpeza na nuvem pode ficar pendente se o dispositivo estiver offline. A fila local volta a tentar quando a mesma conta iniciar sessão e a ligação estiver disponível.

### Validação efectuada nesta ronda
- Teste isolado do parser CSV: aprovado (1 linha válida, 1 rejeitada, campos com vírgulas e quebra de linha entre aspas).
- Teste SQL da migração Room 12 → 13: aprovado.
- Verificação estática do registo da migração: aprovada.
- Verificação estática das regras Firestore e do caminho configurado em `firebase.json`: aprovada.
- Verificação das referências de métodos DAO alterados: realizada.
- Integridade do ZIP: verificada após empacotamento.

### Validação ainda não efectuada
- Compilação integral Android/Gradle.
- Testes unitários Android, instrumentados e funcionais.
- Teste real com Firebase Console e dois dispositivos.
- Publicação das regras Firestore.

### Critério de conclusão
O Ponto 4 fica consolidado para o escopo de custo zero/Firebase Spark: alertas locais, caixa de notificações persistente, sincronização eventual, estado de leitura entre dispositivos, registo/limpeza best-effort de tokens e isolamento por UID. O envio push remoto automático fica explicitamente fora do escopo gratuito actual e poderá ser reavaliado quando a aplicação gerar receita.
