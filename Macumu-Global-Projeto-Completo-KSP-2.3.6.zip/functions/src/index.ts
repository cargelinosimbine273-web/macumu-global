import { initializeApp } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import { HttpsError, onCall } from "firebase-functions/v2/https";
import { setGlobalOptions } from "firebase-functions/v2";

initializeApp();
setGlobalOptions({ region: "africa-south1", maxInstances: 10 });

const db = getFirestore();

/**
 * Server-side moderation endpoint. Only accounts with a custom claim admin=true
 * can approve/reject products. The Admin SDK write bypasses Firestore client rules.
 */
export const moderateProduct = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "É necessário iniciar sessão.");
  }
  if (request.auth.token.admin !== true) {
    throw new HttpsError("permission-denied", "Apenas administradores autorizados podem moderar produtos.");
  }

  const globalProductId = request.data?.globalProductId;
  const approved = request.data?.approved;
  if (typeof globalProductId !== "string" || globalProductId.trim().length < 8 || typeof approved !== "boolean") {
    throw new HttpsError("invalid-argument", "Identificador do produto ou decisão inválida.");
  }

  const ref = db.collection("products").doc(globalProductId);
  await db.runTransaction(async (transaction) => {
    const snapshot = await transaction.get(ref);
    if (!snapshot.exists) {
      throw new HttpsError("not-found", "Produto não encontrado no catálogo central.");
    }
    const data = snapshot.data();
    if (!data || typeof data.ownerUid !== "string" || data.globalProductId !== globalProductId) {
      throw new HttpsError("failed-precondition", "O registo do produto não possui identidade/propriedade válida.");
    }
    transaction.update(ref, {
      isApproved: approved,
      moderationStatus: approved ? "APPROVED" : "REJECTED",
      moderatedBy: request.auth!.uid,
      moderatedAt: Date.now(),
      updatedAt: Date.now()
    });
  });

  return { ok: true, globalProductId, approved };
});


// Spark-plan architecture: no automatic server-side FCM sender is deployed.
// Price Watch creates local Android alerts and syncs the in-app inbox through Firestore.
// Do not deploy Cloud Functions while the project must remain on Firebase Spark.
