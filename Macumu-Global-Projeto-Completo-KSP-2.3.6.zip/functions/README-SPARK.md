# Cloud Functions — código reservado para fase futura

Este directório contém a função `moderateProduct` como código-fonte de uma fase futura. **Não executar deploy enquanto o projecto estiver no Firebase Spark.** A implantação de Cloud Functions exige o plano Blaze/conta de facturação.

Na fase actual, a aplicação Android executa a moderação através de uma actualização directa ao Firestore, protegida por `request.auth.token.admin == true` nas regras. O cliente verifica o custom claim para apresentar erros claros, mas a regra Firestore é a barreira de segurança efectiva. A função `moderateProduct` fica reservada para uma fase futura e não é chamada pela aplicação Spark.
