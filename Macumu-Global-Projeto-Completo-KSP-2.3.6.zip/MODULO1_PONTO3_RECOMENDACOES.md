# Módulo 1 — Ponto 3: Recomendações Inteligentes

## Implementação incluída

- Motor local de recomendações em `RecommendationEngine`.
- Actualização automática das sugestões quando mudam o catálogo, os favoritos ou os acompanhamentos de preço.
- Personalização por categorias e mercados dos favoritos.
- Personalização por categorias e mercados dos produtos acompanhados no Price Watch.
- Pontuação complementar por destaque, avaliação, número de opiniões e disponibilidade em stock.
- Exclusão de produtos não aprovados, sem stock e já guardados nos favoritos.
- Explicação visível ao utilizador sobre os sinais usados para ordenar as sugestões.
- Integração da lista recomendada no ecrã Home, mantendo cartões e acções existentes.
- Testes unitários escritos para prioridade de categoria, produtos indisponíveis e produtos acompanhados.

## Privacidade e limites

O motor funciona localmente com dados já disponíveis na aplicação. Não envia histórico pessoal para serviços externos e não utiliza modelos de IA. A designação "inteligentes" refere-se à personalização baseada em sinais e regras explícitas, não a aprendizagem automática.

As sugestões dependem da qualidade e quantidade do catálogo. Sem favoritos ou acompanhamentos, usa destaque, avaliações, opiniões e disponibilidade como critérios iniciais.

## Ficheiros criados/alterados

- `app/src/main/java/com/example/recommendations/RecommendationEngine.kt` (novo)
- `app/src/main/java/com/example/ui/MacumuViewModel.kt`
- `app/src/main/java/com/example/MainActivity.kt`
- `app/src/main/java/com/example/ui/screens/buyer/BuyerHomeScreen.kt`
- `app/src/test/java/com/example/recommendations/RecommendationEngineTest.kt` (novo)

## Validação

- Revisão estática dos ficheiros: realizada.
- Testes unitários: escritos, ainda não executados.
- Compilação Android: não executada neste ambiente.
- Testes funcionais e comportamento em dispositivo: reservados para a bateria final após os sete pontos.
