# Auditoria Ponto 4 — Ronda 7

### Resultado
Foi reforçada a gestão de tokens FCM por instalação, a recuperação de remoções pendentes e a sequência de logout. As regras locais Firestore foram alinhadas com o novo formato.

### Ficheiros principais alterados
- `app/src/main/java/com/example/notifications/PushTokenRegistrar.kt`
- `app/src/main/java/com/example/ui/screens/account/AccountScreen.kt`
- `app/src/main/java/com/example/ui/components/MacumuComponents.kt`
- `FIRESTORE_RULES_CATALOGO.txt`
- `FIRESTORE_RULES_MODULO1.txt`

### Pontos que exigem configuração fora do código
1. Publicar `FIRESTORE_RULES_CATALOGO.txt` no Firebase Console (é o ficheiro apontado por `firebase.json`).
2. Configurar e alojar o backend confiável de FCM. Não colocar chave de conta de serviço nem credenciais Admin no APK.
3. Depois de publicar as regras, validar registo, rotação e remoção de token com contas e dispositivos reais, na fase de testes autorizada pelo utilizador.

### Não alegado
Não foi feita compilação Android, publicação das regras, implantação de backend ou envio real de push nesta ronda.
