# Macumu Global — Ronda 10.2
## Conversão cambial controlada e actualização de ofertas importadas

### Objectivo
Permitir importar ofertas CSV em moedas estrangeiras sem subscrições, servidores pagos ou taxas cambiais inventadas.

### Conversão cambial
- O administrador introduz manualmente a taxa em MZN por uma unidade de USD, EUR, ZAR, CNY ou GBP.
- A taxa exige fonte identificada e data no formato AAAA-MM-DD.
- Só são aceites datas de hoje ou dos últimos sete dias; datas futuras, inválidas ou mais antigas bloqueiam a conversão.
- MZN é aceite sem taxa.
- A conversão usa arredondamento decimal a duas casas.
- A taxa, fonte e data são anexadas à descrição do produto para rastreabilidade.
- As taxas ficam guardadas localmente no dispositivo administrador; não são sincronizadas entre administradores nesta ronda.
- Não existe consulta cambial automática nem garantia de que a taxa introduzida seja a taxa efectiva de liquidação. O administrador deve confirmar a fonte antes de guardar.

### Actualização de produtos
- A identidade do produto continua estável por UID + origem + ID externo.
- Reimportar a mesma oferta actualiza o registo local existente e coloca a alteração na fila de sincronização.
- Não cria uma segunda listagem para o mesmo produto da mesma origem.
- Não permite que uma conta actualize um produto pertencente a outra conta.
- Preserva stock, avaliações e contagem de avaliações.
- Se preço, título ou imagem mudar num produto aprovado, o produto volta a ficar pendente de aprovação. Uma alteração material não entra directamente na vitrine.
- Se não houver alteração material, o estado de aprovação é preservado.

### Segurança e limites
- Todos os preços internos continuam armazenados em MZN.
- A apresentação de preços em moedas estrangeiras foi deliberadamente desactivada onde dependia de taxas fixas antigas. O ecrã apresenta MZN para não induzir o utilizador em erro.
- Não foram adicionados serviços pagos nem chamadas externas de câmbio.
- A fila de sincronização depende da autenticação e das regras Firestore já configuradas/publicadas.

### Validação
- Revisão estática dos ficheiros alterados realizada.
- Não foi executada compilação Android: o pacote não contém `gradlew` e o ambiente não tem Gradle instalado.
- Não foram executados testes funcionais, respeitando a sequência acordada para o Módulo 1.
