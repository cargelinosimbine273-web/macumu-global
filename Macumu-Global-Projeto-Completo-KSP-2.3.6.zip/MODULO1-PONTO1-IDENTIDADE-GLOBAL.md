# Módulo 1 — Ponto 1: identidade global dos produtos

## Alterações incluídas

- `ProductEntity.globalProductId`: identificador textual estável e independente do ID autoincremental do Room.
- Índice único Room para impedir dois produtos locais com o mesmo identificador global.
- Migração Room 3 → 4 sem apagar a tabela `products`.
- Produtos antigos recebem inicialmente `legacy_<id>` e são normalizados para UUID determinístico calculado a partir de vendedor, título e mercado. O mesmo produto legado obtém o mesmo identificador em instalações que tenham os mesmos campos de identidade.
- Novos produtos recebem UUID aleatório no momento da criação.
- DAO e repositório permitem procurar produto pelo identificador global.
- Favoritos passam a usar `globalProductId` como ID do documento Firestore; o ID Room fica apenas como referência local de compatibilidade.
- O listener remoto converte os IDs globais em IDs locais usando o catálogo presente no dispositivo.

## Limites importantes

1. Para um favorito aparecer noutro dispositivo, esse dispositivo também precisa de ter o produto no catálogo local com o mesmo `globalProductId`. Esta alteração resolve a identidade, mas ainda não implementa a replicação/sincronização completa do catálogo de produtos.
2. Produtos novos criados separadamente em dois dispositivos recebem UUIDs diferentes. Para representar o mesmo produto em vários dispositivos, o produto deve ser criado uma vez no catálogo central e o mesmo `globalProductId` deve ser distribuído aos clientes.
3. A migração incluída cobre especificamente bases Room versão 3 para 4. Não foram fornecidas migrações históricas para versões 1 ou 2; por segurança, foi removido o fallback destrutivo. Uma instalação com DB v1/v2 precisará de uma migração específica antes de actualizar.
4. Os favoritos remotos antigos com documentos numéricos são lidos como compatibilidade no dispositivo de origem, mas a migração para IDs globais depende de o produto correspondente existir localmente.

## Regras Firestore

O ficheiro `FIRESTORE_RULES_MODULO1.txt` inclui permissões por UID para `users/{uid}/favorites/{globalProductId}` e `users/{uid}/deviceTokens/{tokenId}`. Publicar regras é uma operação separada; este ZIP não altera o Firebase Console.

## Validação

A estrutura e as alterações de código foram verificadas por inspecção. A compilação Android e os testes Room/Firebase ainda precisam de ser executados no GitHub Actions; não declarar esta versão como compilada até o workflow terminar com sucesso.
