# Ponto 4 — Revisão profunda: primeira ronda de correcções

## Correcções aplicadas

1. **Price Watch por UID:** o DAO passou a devolver apenas acompanhamentos do UID autenticado. O `PriceWatchWorker` deixou de aceitar registos com `ownerUid` vazio como se pertencessem à conta actual.
2. **Notificações por UID:** `NotificationEntity` ganhou `ownerUid`; a migração Room 7→8 adiciona a coluna e o índice. Consultas por papel e marcação como lida exigem o UID.
3. **Alertas sincronizados:** depois de avaliar o preço, o Worker actualiza o estado local e escreve `lastObservedPriceMzn`, `lastAlertedPriceMzn` e `updatedAt` no documento `users/{uid}/priceWatches/{globalProductId}`.
4. **Protecção contra marcação cruzada:** a operação de marcar notificação como lida também exige correspondência do UID.

## Limitações que permanecem nesta ronda

- O identificador primário local de `price_watches` continua a ser `globalProductId`; portanto, duas contas no mesmo dispositivo ainda não conseguem manter acompanhamentos independentes para o mesmo produto. A próxima ronda deve migrar a chave para `(globalProductId, ownerUid)`.
- Notificações antigas migradas recebem `ownerUid=''` e deixam de aparecer nas consultas de utilizadores autenticados. Não foram atribuídas automaticamente a uma conta para evitar exposição de dados.
- A lista `notifications` do ViewModel obtém o UID no momento da criação do ViewModel; a reacção imediata a login/logout sem recriar o ViewModel ainda deve ser melhorada com um fluxo de estado de autenticação.
- O Worker actualiza o Firestore a partir do dispositivo autenticado. Isso sincroniza o estado do acompanhamento, mas não constitui envio push para outros dispositivos.
- Não foi executada compilação Gradle nem teste em dispositivo nesta ronda. Foi feita apenas revisão estática e verificação de integridade do arquivo.
