# Macumu Global — Módulo 1, Ponto 4
## Ronda 4: recuperação de falhas, idempotência e regras Firestore

### Alterações desta ronda

1. **Alertas idempotentes:** `NotificationEntity` ganhou `eventKey`, com índice único por `ownerUid`. Alertas Price Watch usam uma chave determinística baseada no produto e no preço observado. Repetições do Worker não criam várias linhas iguais no centro de notificações.
2. **Migração Room 9 → 10:** adiciona `eventKey`, atribui chaves próprias às notificações antigas e cria o índice único sem apagar o histórico existente.
3. **Recuperação após interrupção:** o Worker grava a notificação antes de actualizar o estado do acompanhamento. Ao repetir a tarefa, a chave única evita duplicar a entrada; o mesmo ID Android substitui a notificação do sistema em vez de criar outra.
4. **Firebase sem bloqueio de thread:** a gravação Firestore passou de `Tasks.await` (bloqueante) para uma espera suspensa de `Task<Void>`, sem bloquear a thread de execução do WorkManager.
5. **Retry:** falhas de Firestore ou de execução devolvem `Result.retry()`. O WorkManager aplica backoff exponencial. Cancelamentos e mudanças de conta interrompem o processamento.
6. **Propriedade do acompanhamento:** o documento Price Watch inclui `ownerUid`; as regras Firestore exigem que corresponda ao UID autenticado.
7. **Agendamento:** o Worker tem tag própria e política de backoff exponencial, mantendo a condição de rede ligada.

### Ficheiros alterados

- `app/src/main/java/com/example/data/local/Entities.kt`
- `app/src/main/java/com/example/data/local/Daos.kt`
- `app/src/main/java/com/example/data/local/AppDatabase.kt`
- `app/src/main/java/com/example/notifications/PriceWatchWorker.kt`
- `app/src/main/java/com/example/notifications/PriceWatchScheduler.kt`
- `app/src/main/java/com/example/ui/MacumuViewModel.kt`
- `FIRESTORE_RULES_CATALOGO.txt`
- `FIRESTORE_RULES_MODULO1.txt`

### Limitações que permanecem

- O Price Watch compara preços que já existem no catálogo local sincronizado. Não consulta automaticamente preços em AliExpress, Alibaba, SHEIN ou outras plataformas; isso depende de APIs/acordos e de uma fonte de preços autorizada.
- O WorkManager é periódico e oportunista. O intervalo mínimo configurado é 15 minutos, mas o Android pode atrasar a execução por bateria, Doze ou restrições do fabricante.
- Notificações locais podem ser emitidas sem Cloud Functions. Push remoto automático para campanhas ou eventos Firestore exige um servidor confiável de envio; não se deve colocar credenciais de servidor FCM dentro do APK.
- As regras Firestore foram actualizadas nos ficheiros de regras do projecto, mas ainda precisam de ser publicadas na consola Firebase ou através de uma implantação autorizada. Não foram publicadas nesta ronda.

### Validação

- Integridade do ZIP: será verificada após empacotamento.
- Compilação Android: não executada; não existe Gradle Wrapper executável (`gradlew`) neste projecto e Gradle não está instalado neste ambiente.
- Testes funcionais: continuam adiados conforme a decisão do projecto, até os sete pontos do Módulo 1 estarem concluídos.
