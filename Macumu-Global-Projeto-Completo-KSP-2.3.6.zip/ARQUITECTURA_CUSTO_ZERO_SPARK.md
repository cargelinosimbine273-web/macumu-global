# Macumu Global — Arquitectura de custo zero nesta fase

## Regra de projecto
Até o Macumu Global começar a gerar receita, não activar facturação, não associar cartão bancário e não utilizar serviços que exijam Blaze ou billing account.

## Serviços permitidos nesta fase
- Firebase Authentication: métodos sem custo e dentro dos limites aplicáveis.
- Firebase Cloud Messaging: recebimento de mensagens FCM sem custo; envio automático por evento exige um emissor confiável que não está disponível apenas com Spark.
- Cloud Firestore: usar apenas dentro das quotas gratuitas e optimizar leituras/escritas.
- Room: persistência local.
- WorkManager: tarefas locais periódicas, sujeitas às regras do Android.
- Notificações Android locais.

## Serviços adiados
- Cloud Functions e extensões que dependam delas. A moderação actual usa regras Firestore e custom claim administrativo, sem callable function.
- Cloud Run, Cloud Build, Artifact Registry e qualquer serviço Google Cloud que exija billing.
- Servidor externo de push ou de sincronização.
- APIs comerciais pagas, feeds pagos e conectores que exijam subscrição.

## Comportamento de notificações na fase Spark
1. O Price Watch verifica o catálogo já sincronizado no dispositivo.
2. O dispositivo que detecta o preço-alvo apresenta a notificação local.
3. O mesmo evento é guardado em `users/{uid}/notifications/{eventKey}`.
4. Os outros dispositivos recuperam o evento na caixa interna da aplicação.
5. Não se promete push remoto automático em segundo plano para todos os dispositivos.

## Quando houver receita
Reavaliar backend seguro, envio FCM remoto, conectores comerciais e eventual migração para Blaze ou outro fornecedor. A decisão será tomada apenas com orçamento e autorização explícita.
