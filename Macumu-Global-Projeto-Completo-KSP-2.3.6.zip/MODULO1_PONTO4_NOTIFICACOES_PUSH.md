# Módulo 1 — Ponto 4: Notificações (compatível com Firebase Spark)

## Caminho activo no plano gratuito

- `PriceWatchWorker` verifica os acompanhamentos de preço guardados localmente no Room.
- `PriceWatchScheduler` agenda verificações periódicas através do Android WorkManager (intervalo mínimo de 15 minutos e condicionado à disponibilidade de rede).
- Quando o preço local do catálogo aprovado atinge o preço-alvo, o worker grava o aviso no centro de notificações local e tenta apresentar uma notificação Android.
- O estado `lastAlertedPriceMzn` evita repetir o mesmo alerta; se o preço voltar a ficar acima do alvo, o acompanhamento pode alertar novamente numa descida posterior.
- O `MacumuFirebaseMessagingService` e o registo de tokens FCM permanecem preparados para uma futura integração com um servidor autorizado.
- O ViewModel deixa de gerar alertas de preço em paralelo; a avaliação é centralizada no worker para reduzir notificações duplicadas.

## Limites reais do Spark

- Firebase Cloud Messaging pode entregar mensagens sem custo de envio, mas não cria por si só eventos de servidor quando um documento Firestore muda.
- O envio automático FCM por uma Cloud Function de Firestore requer implantação de Cloud Functions, que exige o plano Blaze.
- Por isso, `functions/src/index.ts` fica no projecto como implementação futura, mas **não faz parte do caminho activo Spark** e não deve ser implantada neste plano.
- No Spark, os alertas de preço aqui activos são notificações locais no dispositivo. WorkManager é periódico e oportunista: Android pode atrasar a execução por bateria, rede ou restrições do sistema. Não é um push instantâneo garantido.
- O worker compara preços do catálogo Macumu já sincronizado no dispositivo. Não consulta automaticamente Alibaba, AliExpress, SHEIN ou outros sites externos.
- Campanhas e eventos de pedidos ainda não enviam notificações nesta etapa.

## Activação e uso

1. Confirmar que `google-services.json` corresponde ao Firebase project e ao `applicationId` da aplicação.
2. Confirmar que Firestore está activo e que as regras consolidadas cobrem `users/{uid}/priceWatches` e as restantes colecções usadas pela aplicação.
3. Abrir a aplicação pelo menos uma vez para o Android agendar o worker.
4. Conceder permissão de notificações em Android 13 ou superior. Se a permissão for negada, o aviso continuará registado no centro interno, mas o sistema Android não o mostrará como notificação.
5. Manter ligação à internet para o catálogo sincronizar; a verificação do preço utiliza os dados locais disponíveis.

## Estado de validação

- Implementação estática do worker, scheduler e integração no arranque: incluída.
- Build Android: ainda não executado nesta revisão.
- Teste em dispositivo, permissões, atraso do WorkManager e recepção de notificações: ainda não executados.
- Deploy de Cloud Functions: deliberadamente não configurado para o plano Spark.
