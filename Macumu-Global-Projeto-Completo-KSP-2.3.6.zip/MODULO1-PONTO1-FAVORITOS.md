# Macumu Global — Módulo 1 / Ponto 1: Favoritos

## Implementado nesta versão
- Mantém favoritos no armazenamento local do Android para utilização offline.
- Quando existe sessão Firebase Authentication, sincroniza em `users/{uid}/favorites/{productId}`.
- Usa o UID da conta para separar favoritos de utilizadores diferentes.
- Ao iniciar sessão, combina os favoritos locais legados/visitante com os favoritos remotos, evitando apagar dados existentes na primeira sincronização.
- Mantém os favoritos associados à conta quando o utilizador termina sessão ou muda de dispositivo.
- Firestore Android mantém cache offline por padrão; alterações pendentes são sincronizadas quando a ligação regressa.

## Regras Firestore
O ficheiro `FIRESTORE_RULES_MODULO1.txt` contém o conjunto completo de regras para os caminhos actualmente usados pelo módulo: `utilizadores`, `users/{uid}/deviceTokens` e `users/{uid}/favorites`.
Antes de publicar, comparar com regras adicionais que o projecto possa ter criado entretanto. Estas regras negam acesso a todas as colecções não listadas.

## Estrutura do documento de favorito
Colecção: `users/{uid}/favorites`
ID do documento: ID numérico do produto convertido para texto.
Campos:
- `productId`: número do produto local.
- `createdAt`: timestamp do servidor.

## Limites conhecidos
- A sincronização remota só funciona quando o utilizador está autenticado no Firebase.
- O catálogo actual usa IDs Room locais. Para sincronizar favoritos entre instalações, o catálogo precisa de IDs de produto estáveis e iguais em todos os dispositivos. IDs auto-gerados localmente pelo Room podem não representar o mesmo produto em duas instalações. Antes de produção, os produtos devem receber um identificador global atribuído pelo backend.
- Esta entrega implementa o ponto 1; não declara os outros seis pontos concluídos.
