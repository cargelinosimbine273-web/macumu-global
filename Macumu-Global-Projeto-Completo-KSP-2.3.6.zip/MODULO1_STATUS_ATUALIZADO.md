# Macumu Global — Estado do Módulo 1

| Ponto | Componente | Estado de desenvolvimento |
|---|---|---|
| 1 | Favoritos e sincronização | Consolidado em revisão estática; validação real pendente |
| 2 | Macumu Price Watch | Implementação inicial integrada; validação real pendente |
| 3 | Recomendações inteligentes | Implementação inicial integrada; testes pendentes |
| 4 | Notificações push | Integração Android/FCM e função de alerta de preço adicionadas; configuração/deploy e testes pendentes |
| 5 | Campanhas dinâmicas | Pendente |
| 6 | Segurança | Pendente de auditoria final integrada |
| 7 | Consolidação geral | Pendente |

## Regra de execução
Não iniciar o Módulo 2 antes de concluir os sete pontos do Módulo 1. A bateria de testes funcionais será realizada após a conclusão dos sete pontos, conforme decisão do projecto.

## Observação
O código do Ponto 4 prepara notificações push reais de Price Watch via Firebase Cloud Messaging, mas só funcionará depois de confirmar o projecto Firebase, registar tokens em dispositivos autenticados e implantar a Cloud Function `notifyPriceWatchers`. Não declarar o serviço operacional antes dessa activação e dos testes.


## Ponto 4 — adaptação Firebase Spark (14/11/2026)
- Worker local Price Watch e scheduler WorkManager adicionados.
- Notificações locais Android + registo no centro interno.
- Cloud Functions retiradas do caminho activo e do firebase.json; envio remoto automático fica para futura infraestrutura Blaze/servidor.
- Build e testes de dispositivo ainda pendentes; não declarar Ponto 4 validado em produção.
