# Macumu Global — Módulo 1 — Ponto 4
## Auditoria estática final da Ronda 11.2

Data: 14/11/2026

### Escopo inspeccionado
- `NotificationSyncWorker.kt`
- `Daos.kt`
- `Entities.kt`
- `AppDatabase.kt`
- `MacumuRepository.kt`
- `MacumuViewModel.kt`
- `firebase.json`
- `FIRESTORE_RULES_CATALOGO.txt`

### Resultados confirmados
1. As eliminações pendentes são consultadas por `getPendingDeletions(uid)` em cada execução autenticada, fora da condição do marcador `dirty_uid`.
2. O DAO filtra a fila de eliminações por `ownerUid`; o Worker valida novamente `deletion.ownerUid == uid`.
3. A operação remota `delete().awaitResult()` precede a remoção da tombstone local. Uma falha mantém o registo local para nova tentativa.
4. A criação da tombstone e a remoção do acompanhamento local estão dentro de `db.withTransaction`.
5. A sincronização de acompanhamentos activos continua condicionada ao marcador `dirty_uid`.
6. Room está na versão 14 e regista a migração 13→14, que cria a tabela `price_watch_deletions` e o índice por UID/data.
7. `firebase.json` aponta para `FIRESTORE_RULES_CATALOGO.txt`. As regras locais limitam leitura/eliminação de `priceWatches` ao UID e validam os campos de criação/actualização. As regras de notificações limitam actualizações ao campo `isRead`.

### Validações executadas nesta auditoria
- Verificações estáticas dos caminhos de sincronização, ordem de operações e isolamento por UID: OK.
- Teste SQLite isolado da tabela de tombstones, consulta por UID e remoção: OK.
- Integridade do ZIP: OK (`unzip -t`, sem erros).

### Limitações e pendências
- Não foi possível executar compilação Android: não existe `gradlew` no arquivo e não há Gradle instalado no ambiente.
- Não foi executada validação das regras com Firebase CLI/Rules Emulator.
- Não foi possível confirmar se as regras foram publicadas na Firebase Console.
- Não foram realizados testes de integração com Firebase real, nem testes funcionais em dispositivos.
- A fila de eliminações depende de o WorkManager executar com rede disponível e de existir uma sessão autenticada para o UID proprietário.

### Conclusão
A falha específica da Ronda 11.1 — dependência indevida do marcador `dirty_uid` para processar eliminações — está corrigida no código da Ronda 11.2. A auditoria estática e o teste SQLite isolado passaram. Contudo, o Ponto 4 **não pode ser declarado totalmente fechado** enquanto a compilação Android, a validação/publicação das regras Firestore e os testes de integração não forem realizados.

**Não avançar para o Ponto 5 nesta fase.**
