# Módulo 1 — Ponto 2: Macumu Price Watch

## Implementação incluída

- Persistência Room das listas de acompanhamento (`price_watches`).
- Histórico local de observações de preço (`price_history`).
- Migração Room 6 → 7, sem apagar os dados anteriores.
- Definição explícita de um preço-alvo em MZN a partir do cartão do produto.
- Ecrã próprio acessível pela navegação inferior, com produtos acompanhados, preço actual, preço-alvo, variação desde o início e até cinco observações recentes.
- Remoção de um acompanhamento.
- Sincronização dos acompanhamentos autenticados em `users/{uid}/priceWatches/{globalProductId}`.
- Regras Firestore específicas para impedir que uma conta leia ou altere os acompanhamentos de outra.
- Criação de notificação interna quando o preço observado no catálogo Macumu atinge ou fica abaixo do alvo. Se o preço voltar a subir acima do alvo, um novo cruzamento poderá gerar novo alerta.

## Limites importantes

1. O Price Watch observa os preços que chegam ao catálogo Macumu (Room/Firestore). Não faz scraping nem consulta automaticamente Alibaba, AliExpress, SHEIN, Temu ou Amazon.
2. Para observar preços externos, cada parceiro terá de disponibilizar API/feed autorizado ou outra integração contratual válida.
3. Nesta etapa o alerta é registado no centro de notificações interno da aplicação. A entrega push específica de alertas de preço será consolidada no Ponto 4 — Notificações Push.
4. Os valores são guardados em MZN. A apresentação noutras moedas usa a conversão já existente no projecto; o preço-alvo não é convertido nem persistido noutra moeda.
5. A sincronização Firestore depende de regras publicadas e de sessão Firebase válida.

## Ficheiros criados/alterados

- `app/src/main/java/com/example/data/local/Entities.kt`
- `app/src/main/java/com/example/data/local/Daos.kt`
- `app/src/main/java/com/example/data/local/AppDatabase.kt`
- `app/src/main/java/com/example/data/repository/MacumuRepository.kt`
- `app/src/main/java/com/example/ui/MacumuViewModel.kt`
- `app/src/main/java/com/example/ui/components/MacumuComponents.kt`
- `app/src/main/java/com/example/ui/screens/buyer/PriceWatchScreen.kt` (novo)
- `app/src/main/java/com/example/MainActivity.kt`
- `FIRESTORE_RULES_CATALOGO.txt`

## Estado de validação

- Revisão estática dos ficheiros alterados: realizada.
- Integridade do ZIP: será verificada na entrega.
- Compilação Android: não executada neste ambiente; o comando `gradle` não está instalado e o projecto não contém `gradlew` executável.
- Testes funcionais em dispositivo e sincronização Firebase real: reservados para a fase final de testes, conforme decisão do utilizador.
