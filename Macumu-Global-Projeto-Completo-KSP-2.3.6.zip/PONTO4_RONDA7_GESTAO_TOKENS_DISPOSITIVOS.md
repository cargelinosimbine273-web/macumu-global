# Macumu Global — Ponto 4 — Ronda 7: gestão de tokens e dispositivos

## Alterações aplicadas

1. **Identidade estável da instalação:** cada instalação Android recebe um UUID persistido localmente. O token FCM deixa de ser usado como ID do documento Firestore.
2. **Um documento por instalação:** o registo passa a usar `users/{uid}/deviceTokens/{installationId}` e guarda `ownerUid`, `installationId`, `token`, `platform` e `updatedAt`.
3. **Rotação de token:** quando o FCM muda o token, o mesmo documento da instalação é actualizado, em vez de criar um documento novo para cada token.
4. **Compatibilidade com registos antigos:** quando o token muda, a aplicação tenta apagar o documento legado cujo ID era o próprio token.
5. **Fila durável de limpeza:** IDs de documentos cuja remoção falhou permanecem em SharedPreferences e são novamente tentados quando a mesma conta autentica.
6. **Logout com limite de espera:** a limpeza na nuvem é tentada enquanto a conta antiga ainda está autenticada. O logout termina após a conclusão ou após quatro segundos, para não prender a interface indefinidamente.
7. **Navegação após logout:** os dois pontos de saída da sessão só abrem o ecrã inicial depois de o processo de logout terminar.
8. **Regras Firestore mais restritas:** criação/actualização de tokens exige UID proprietário, ID da instalação correspondente, token textual e plataforma Android.

## Estrutura dos documentos

`users/{uid}/deviceTokens/{installationId}`

Exemplo de campos:

- `ownerUid`: UID autenticado proprietário.
- `installationId`: UUID estável da instalação.
- `token`: token FCM actual.
- `platform`: `android`.
- `updatedAt`: timestamp do servidor.

## Limites que permanecem por razões de autorização e infraestrutura

- Se a remoção do documento falhar e o utilizador nunca voltar a autenticar a mesma conta, o cliente não pode apagar esse documento mais tarde sob regras que protegem o UID. A fila local permite recuperar quando a mesma conta voltar; limpeza administrativa global exigirá o backend confiável da próxima fase.
- A aplicação pode invalidar o token FCM localmente, mas a operação depende do serviço FCM e da conectividade.
- As regras actualizadas ainda têm de ser publicadas no Firebase Console. O código local não altera as regras já activas no projecto remoto.
- Esta ronda não instala nem publica o servidor externo de envio push. A API/servidor deve manter credenciais Firebase Admin fora do APK, ser configurada com um fornecedor e segredos seguros e só depois ser ligada aos eventos.

## Validação

- Revisão estática dos fluxos de registo, rotação, limpeza e logout.
- Verificação textual de que os dois pontos de logout aguardam o callback.
- Compilação Android e testes funcionais não executados nesta ronda. O projecto continua sem `gradlew` e sem Gradle instalado neste ambiente, respeitando a decisão de adiar os testes até concluir os sete pontos do Módulo 1.
