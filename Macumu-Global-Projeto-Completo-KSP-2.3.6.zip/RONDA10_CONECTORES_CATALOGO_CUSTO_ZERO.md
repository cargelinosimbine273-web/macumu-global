# Macumu Global — Ronda 10: Conectores de catálogo (Spark / custo zero)

## Objectivo
Preparar uma camada comum de conectores sem afirmar que as plataformas já estão ligadas. Nesta fase não são introduzidas subscrições, servidores pagos, chaves privadas no APK ou chamadas automáticas a lojas externas.

## Implementado nesta ronda
- `CatalogConnectorInfo` e `CatalogConnectorRegistry`: inventário explícito das fontes e do estado real de acesso.
- `CatalogConnector` e `ImportedOffer`: contrato normalizado para futuras APIs e feeds autorizados.
- `CatalogCsvImporter`: importador local CSV, sem dependência de servidor, com validação de campos, preço, moeda e URLs HTTPS.
- URLs de produto, imagem e afiliado são tratadas separadamente. URLs não HTTPS são rejeitadas/ignoradas.
- A importação apenas analisa e normaliza dados; não publica automaticamente ofertas nem cria preços fictícios.

## Estado real por plataforma
| Fonte | Estado nesta versão | Condição para automatizar |
|---|---|---|
| AliExpress | Acesso API por confirmar/aprovar | Conta/programa de afiliados e credenciais/API access autorizados |
| Alibaba.com | API sujeita a aprovação | Registo de developer, aprovação da aplicação e permissões da API |
| SHEIN | Sem feed público de afiliados comprovado nesta revisão | Acordo/acesso apropriado; a Open Platform consultada é orientada a operações de vendedores |
| Digistore24 | API disponível com chave | Chave da conta com permissões mínimas; nunca colocar no APK |
| Lojas moçambicanas | CSV manual pronto | Cada loja deve fornecer feed/API e autorizar a utilização dos dados |

## Limites deliberados
- Não existe ainda sincronização automática com AliExpress, Alibaba, SHEIN ou Digistore24.
- Não foram incluídas credenciais, tokens ou chaves.
- Não há scraping de páginas, contorno de autenticação ou recolha contrária aos termos das plataformas.
- O conversor de moedas e a publicação no catálogo não fazem parte do importador CSV desta ronda.
- O importador não grava directamente na Room/Firestore: a revisão humana e a validação comercial devem ocorrer antes da publicação.

## Modelo de CSV
Cabeçalhos obrigatórios: `sourceId,externalProductId,title,price,currency,productUrl`.
Cabeçalhos opcionais: `description,category,imageUrl,affiliateUrl,availabilityText`.
Preço deve ser numérico e positivo. URLs devem usar HTTPS. Uma linha inválida é ignorada.

## Fontes oficiais consultadas
- Alibaba Open Platform: https://openapi.alibaba.com/doc/doc.htm — registo de developer, aprovação da aplicação, App Key/Secret e permissões.
- SHEIN Open Platform: https://open.sheincorp.com/pt/documents/apidoc/1000001 — documentação pública de APIs de operação de vendedores.
- Digistore24 API: https://www.digistore24.com/api/docs/index.html e https://dev.digistore24.com/hc/en-us/articles/32479630493585-API-basics — API com autenticação por chave.
- AliExpress: o acesso ao programa/API de afiliados deve ser confirmado na conta oficial antes de activar qualquer conector; esta ronda não declara acesso aprovado.

## Validação
Revisão estática do código realizada. Não foi executada compilação Android nem teste funcional, respeitando a decisão do projecto de concluir os sete pontos antes dos testes. A integridade do ZIP será verificada após empacotamento.
