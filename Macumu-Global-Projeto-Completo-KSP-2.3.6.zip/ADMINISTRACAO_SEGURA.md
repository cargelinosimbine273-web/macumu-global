# Administração segura do catálogo Macumu Global — modo Firebase Spark

## Comportamento nesta fase sem orçamento
- A aprovação/rejeição é feita directamente no Firestore pelo utilizador autenticado com o custom claim `admin: true`.
- A aplicação renova o ID token e verifica o claim para apresentar uma mensagem clara.
- A autorização efectiva é sempre aplicada pelas Firestore Security Rules (`isAdmin()`); não existe função administrativa executada no cliente sem controlo das regras.
- A publicação de um produto usa Firestore `create()` e não permite ao vendedor substituir um documento global existente.
- A função `moderateProduct` em `functions/` fica reservada para uma fase futura e não deve ser implantada no Firebase Spark.

## Activação necessária no Firebase Console
1. Confirmar que o projecto permanece no plano Spark e não associar uma conta de facturação.
2. Publicar `FIRESTORE_RULES_CATALOGO.txt` no Firestore Rules.
3. Atribuir o custom claim `admin: true` apenas ao UID do administrador, usando um procedimento confiável com Firebase Admin SDK executado pelo proprietário do projecto. Esta atribuição inicial não é feita pela aplicação Android.
4. O administrador deve terminar e voltar a iniciar sessão para renovar o ID token.
5. Confirmar que a conta administrativa consegue aprovar um produto e que uma conta normal não consegue alterar os campos de moderação.

## Atribuição do administrador
- Obter o UID em Firebase Console > Authentication > Users.
- Nunca atribuir `admin: true` no código Android, no Firestore ou num campo de perfil editável pelo utilizador.
- Nunca colocar chave de service account no repositório ou APK.
- Guardar o UID do administrador autorizado em registo interno seguro.

## Limitações explícitas
- As regras incluídas no ZIP ainda precisam de ser publicadas manualmente na consola Firebase.
- A aplicação e as regras não foram implantadas/validadas na conta Firebase nesta sessão.
- Não executar `firebase deploy --only functions` enquanto o projecto estiver no Spark: Cloud Functions requer Blaze/conta de facturação.
- O directório `functions/` contém código reservado para uma fase futura; não faz parte do runtime Spark actual.
- Compilação Android e testes funcionais não foram executados nesta ronda.
