# Macumu Global — Ponto 4 — Ronda 11.2

## Correcção aplicada

O `NotificationSyncWorker` anteriormente processava `price_watch_deletions` apenas quando `dirty_uid` nas SharedPreferences correspondia à conta autenticada. Isso criava uma dependência indevida: uma interrupção abrupta entre a gravação da tombstone Room e a gravação do marcador podia deixar uma eliminação pendente sem ser enviada ao Firestore.

A Ronda 11.2 remove essa condição. Em cada execução do worker com sessão autenticada, as eliminações pendentes são consultadas por UID e processadas antes da reconciliação dos acompanhamentos activos. O marcador `dirty_uid` continua a controlar apenas a sincronização dos acompanhamentos activos, preservando a redução de operações Firestore no Firebase Spark.

A tombstone local só é removida depois de o `delete()` remoto terminar com sucesso. Se a aplicação parar depois da eliminação remota e antes da remoção local, a próxima execução repete a eliminação, que é idempotente.

## Segurança e isolamento

- O DAO consulta tombstones exclusivamente com `ownerUid = uid`.
- O worker valida novamente `deletion.ownerUid == uid`.
- O worker verifica se a sessão autenticada continua a ser a mesma antes de cada operação remota.
- O caminho Firestore continua limitado a `users/{uid}/priceWatches/{globalProductId}`.

## Validações efectuadas

- Inspecção do bloco de sincronização antes e depois da alteração.
- Verificação estática de que `getPendingDeletions(uid)` é chamado sem condição `dirtyUid`.
- Verificação estática de que `removeDeletion(globalProductId, uid)` ocorre apenas depois de `delete().awaitResult()`.
- Verificação estática da filtragem por UID no DAO e no worker.
- Integridade do ZIP da Ronda 11.2.

## Limitações não resolvidas por esta ronda

- Não foi executada compilação Android completa: o projecto não contém `gradlew` e não há Gradle instalado neste ambiente.
- Não foram realizados testes de integração com Firebase real nem testes funcionais em dois dispositivos.
- As regras Firestore continuam a necessitar de publicação manual na Firebase Console; esta ronda não confirma publicação.
- A sincronização continua sujeita à disponibilidade de rede e às condições de execução do WorkManager.

## Estado

A falha específica de dependência do marcador foi corrigida no código. O Ponto 4 ainda requer validação de compilação e testes Firebase antes de ser declarado totalmente fechado. Não avançar para o Ponto 5 nesta fase.
