# Correcao de compilacao — KSP

A versao do plugin Kotlin Symbol Processing foi atualizada de 2.3.5 para 2.3.6 em `gradle/libs.versions.toml`.

Motivo: a excecao `Application.getApplication() is null` observada no GitHub Actions corresponde a um problema reportado no KSP 2.3.5 e indicado como corrigido no KSP 2.3.6.

Esta alteracao corrige a versao do processador, mas nao representa uma compilacao validada. O workflow deve ser executado novamente para confirmar o resultado.
