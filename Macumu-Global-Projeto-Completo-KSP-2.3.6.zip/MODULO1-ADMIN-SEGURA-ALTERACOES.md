# Módulo 1 — Administração segura e aprovação do catálogo

## Alterações desta entrega
1. A aprovação/rejeição de anúncios remotos deixou de ser uma escrita directa do Android no Firestore.
2. O Android chama a Cloud Function `moderateProduct` na região `africa-south1`.
3. A Cloud Function valida `request.auth.token.admin === true` antes de alterar a moderação.
4. O estado local só é actualizado depois de a operação remota ter sucesso.
5. A publicação de anúncios passou de `set()` para `create()`, impedindo sobrescrever inadvertidamente um documento com o mesmo ID global.
6. Foi adicionado o SDK Android Firebase Functions.
7. Foram incluídos `firebase.json`, `.firebaserc`, código TypeScript e script seguro de atribuição do custom claim.

## Activação obrigatória no Firebase
Esta entrega prepara código e configuração, mas não implanta recursos na conta Firebase. O proprietário precisa implantar a Cloud Function e atribuir o claim `admin: true` à conta administrativa correcta num ambiente confiável. Só depois deve publicar as regras do ficheiro `FIRESTORE_RULES_CATALOGO.txt`.

## Validação
- Inspecção estática dos ficheiros e consistência da configuração: realizada.
- Compilação Android: não executada; Gradle não está instalado neste ambiente e o repositório não contém `gradle-wrapper.jar`.
- Compilação TypeScript/deploy Firebase: não executados; dependências e credenciais de deploy não foram instaladas/disponibilizadas.
- Teste com Firestore real: pendente.
