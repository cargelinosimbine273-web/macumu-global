# Módulo 1 — Ponto 1: Favoritos e sincronização

## Resultado da revisão estática

**Estado: revisão do código concluída; validação funcional reservada para a fase final de testes dos sete pontos.**

### Componentes verificados
- `ui/MacumuViewModel.kt`: estado local dos favoritos, separação por UID, observação da sessão Firebase, leitura em tempo real da subcolecção `users/{uid}/favorites` e gravação por `globalProductId`.
- `data/local/Entities.kt`: `ProductEntity` contém identificador global separado do ID numérico local do Room.
- `data/local/AppDatabase.kt`: migrações 3→4, 4→5 e 5→6 preservam os registos existentes e criam a fila de sincronização.
- `data/local/Daos.kt`: consultas por ID global e operações da fila de sincronização.
- `data/repository/MacumuRepository.kt`: preservação do ID local ao actualizar um produto já conhecido e persistência da fila antes do envio.
- `data/repository/CloudCatalogSync.kt`: publicação pendente, consulta de produtos aprovados e aprovação delegada à Cloud Function.
- `sync/CatalogSyncWorker.kt` e `CatalogSyncScheduler.kt`: sincronização com rede disponível, tentativa imediata e repetição periódica.
- `FIRESTORE_RULES_CATALOGO.txt` e `functions/`: regras e função de moderação presentes no projecto; ainda dependem de publicação/configuração no Firebase.

### Correcção de identidade confirmada
Os documentos remotos de favoritos são resolvidos por `globalProductId` (ou pelo ID do documento), nunca pelo ID numérico de uma instalação Room diferente. A recuperação pontual do Firestore é executada em `Dispatchers.IO`.

### Limitações e condições para os testes finais
1. Não foi executado build Android nem teste em dispositivo nesta revisão; não afirmar que o APK compila até o workflow do GitHub terminar com sucesso.
2. Não foi validada uma sincronização real entre duas contas/dispositivos; isso fica para a bateria de testes após os sete pontos, conforme solicitado.
3. O Firebase precisa de regras compatíveis publicadas e da Cloud Function `moderateProduct` implantada. Não publicar as regras incluídas sem comparar com todas as colecções usadas pelo projecto e preservar as regras necessárias.
4. As migrações incluídas cobrem as versões 3→4→5→6. Se existir uma instalação antiga com base de dados versão 1 ou 2, é necessário criar e validar os caminhos de migração correspondentes antes de actualizar essa instalação.
5. Produtos legados duplicados com o mesmo vendedor, título e mercado podem receber um sufixo baseado no ID local. Esses casos não devem ser considerados sincronizáveis entre dispositivos até receberem um identificador global comum e estável.
6. A fila de publicação depende de o produto ter `ownerUid` preenchido; a publicação exige sessão Firebase autenticada.

## Critério de passagem
O Ponto 1 fica **concluído ao nível da revisão e consolidação do código**, com build, migrações em instalação real, regras Firebase e sincronização multi-dispositivo explicitamente pendentes para a fase de testes finais. O próximo ponto de desenvolvimento é o **Ponto 2 — Macumu Price Watch**.
