package com.example.notifications

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.local.NotificationEntity
import com.example.data.local.PriceHistoryEntity
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first

/** Checks cached catalogue prices and issues idempotent local alerts without Cloud Functions. */
class PriceWatchWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val auth = FirebaseAuth.getInstance()
        val uid = auth.currentUser?.uid ?: return Result.success()
        val db = AppDatabase.getDatabase(applicationContext)

        return try {
            val watchItems = db.priceWatchDao().observeWatches(uid).first()
            val products = db.productDao().getAllProductsOnce().associateBy { it.globalProductId }

            for (watch in watchItems) {
                ensureActiveAndSameUser(auth, uid)
                if (watch.ownerUid != uid) continue
                val product = products[watch.globalProductId] ?: continue
                if (!product.isApproved) continue
                val price = product.promoPriceMzn ?: product.priceMzn
                if (!price.isFinite() || price <= 0.0) continue

                if (price != watch.lastObservedPriceMzn) {
                    val historyKey = "price:${watch.globalProductId}:${price.toBits()}"
                    db.priceWatchDao().insertHistoryIfAbsent(
                        PriceHistoryEntity(
                            globalProductId = watch.globalProductId,
                            priceMzn = price,
                            source = "LOCAL_PRICE_WATCH",
                            eventKey = historyKey
                        )
                    )
                }

                val reached = price <= watch.targetPriceMzn &&
                    (watch.lastAlertedPriceMzn == null || price < watch.lastAlertedPriceMzn)
                val nextAlertedPrice = when {
                    reached -> price
                    price > watch.targetPriceMzn -> null
                    else -> watch.lastAlertedPriceMzn
                }
                val watchStateChanged = price != watch.lastObservedPriceMzn ||
                    nextAlertedPrice != watch.lastAlertedPriceMzn
                val updatedWatch = watch.copy(
                    lastObservedPriceMzn = price,
                    lastAlertedPriceMzn = nextAlertedPrice,
                    updatedAt = if (watchStateChanged) System.currentTimeMillis() else watch.updatedAt
                )

                if (reached) {
                    ensureActiveAndSameUser(auth, uid)
                    val title = "Alerta de preço: ${product.title}"
                    val message = "O preço está em ${price.toLong()} MZN. O teu preço-alvo era ${watch.targetPriceMzn.toLong()} MZN."
                    val eventKey = "pricewatch:${watch.globalProductId}:${price.toBits()}"
                    db.notificationDao().insertNotificationIfAbsent(
                        NotificationEntity(
                            targetRole = "COMPRADOR",
                            ownerUid = uid,
                            eventKey = eventKey,
                            title = title,
                            message = message
                        )
                    )
                    // Deliver locally first: offline users still receive the alert on this device.
                    // Re-issuing the same Android ID replaces the prior alert rather than duplicating it.
                    showDeviceNotification(title, message, eventKey.hashCode())

                    // Room is the durable outbox. Remote synchronization is handled by a
                    // separate network-constrained worker, so offline devices still alert.
                    NotificationSyncScheduler.enqueue(applicationContext, uid)
                }

                // Persist observation state locally. The Price Watch cloud document is
                // maintained by the account listener/scheduler; no network is required here.
                if (watchStateChanged) {
                    db.priceWatchDao().upsertWatch(updatedWatch)
                    applicationContext.getSharedPreferences("macumu_price_watch_sync", Context.MODE_PRIVATE)
                        .edit().putString("dirty_uid", uid).putString("dirty_marker", java.util.UUID.randomUUID().toString()).apply()
                    NotificationSyncScheduler.enqueue(applicationContext, uid)
                }
            }
            Result.success()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            // WorkManager applies its configured backoff; the deterministic event key prevents duplicates.
            Result.retry()
        }
    }

    private fun ensureActiveAndSameUser(auth: FirebaseAuth, expectedUid: String) {
        if (isStopped || auth.currentUser?.uid != expectedUid) {
            throw CancellationException("Sessão alterada durante a verificação de preços")
        }
    }

    private fun showDeviceNotification(title: String, message: String, id: Int) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                applicationContext,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) return

        val notification = NotificationCompat.Builder(
            applicationContext,
            MacumuFirebaseMessagingService.CHANNEL_ID
        )
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(applicationContext).notify(id, notification)
        } catch (_: SecurityException) {
            // Permission may be revoked between the permission check and delivery.
        }
    }
}

