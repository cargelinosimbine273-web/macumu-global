package com.example.notifications

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/** Keeps one FCM registration per app installation and authenticated account. */
object PushTokenRegistrar {
    private const val KEY_REGISTERED_UID = "registered_uid"
    private const val KEY_REGISTERED_TOKEN = "registered_token"
    private const val KEY_DEVICE_ID = "installation_id"
    private const val KEY_PENDING_DELETIONS = "pending_token_deletions"
    private const val SIGN_OUT_TIMEOUT_MS = 4_000L

    fun register(context: Context) {
        val appContext = context.applicationContext
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        retryPendingDeletions(appContext, uid)
        FirebaseMessaging.getInstance().token
            .addOnSuccessListener { token ->
                if (FirebaseAuth.getInstance().currentUser?.uid == uid) {
                    saveToken(appContext, uid, token)
                }
            }
    }

    fun registerToken(context: Context, token: String) {
        val appContext = context.applicationContext
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid == null) {
            appContext.getSharedPreferences(MacumuFirebaseMessagingService.PREFS, Context.MODE_PRIVATE)
                .edit().putString(MacumuFirebaseMessagingService.KEY_PENDING_TOKEN, token).apply()
            return
        }
        retryPendingDeletions(appContext, uid)
        saveToken(appContext, uid, token)
    }

    /**
     * Queues cloud cleanup durably, attempts deletion while the old UID is still
     * authenticated, and always completes logout after success or a short timeout.
     * Failed cloud deletions remain queued for the next login of that same UID.
     */
    fun signOut(context: Context, onSignedOut: () -> Unit = {}) {
        val appContext = context.applicationContext
        val auth = FirebaseAuth.getInstance()
        val uid = auth.currentUser?.uid
        val prefs = appContext.getSharedPreferences(MacumuFirebaseMessagingService.PREFS, Context.MODE_PRIVATE)
        val registeredUid = prefs.getString(KEY_REGISTERED_UID, null)
        val token = prefs.getString(KEY_REGISTERED_TOKEN, null)
        val deviceId = getInstallationId(prefs)

        val completed = AtomicBoolean(false)
        Handler(Looper.getMainLooper()).postDelayed(
            { finishSignOut(auth, prefs, completed, onSignedOut) }, SIGN_OUT_TIMEOUT_MS
        )

        if (uid == null || registeredUid != uid) {
            finishSignOut(auth, prefs, completed, onSignedOut)
            return
        }

        enqueueDeletion(prefs, uid, deviceId)
        if (!token.isNullOrBlank()) enqueueDeletion(prefs, uid, token) // legacy token-as-document-ID record

        // Token invalidation and Firestore cleanup are independent best-effort operations.
        FirebaseMessaging.getInstance().deleteToken().addOnCompleteListener {
            // No dependency on this result: Firestore cleanup is still attempted.
        }
        val docs = mutableListOf(deviceId)
        if (!token.isNullOrBlank()) docs.add(token)
        deleteCloudDocuments(appContext, uid, docs) {
            finishSignOut(auth, prefs, completed, onSignedOut)
        }
    }

    private fun finishSignOut(
        auth: FirebaseAuth,
        prefs: android.content.SharedPreferences,
        completed: AtomicBoolean,
        onSignedOut: () -> Unit
    ) {
        if (!completed.compareAndSet(false, true)) return
        prefs.edit()
            .remove(KEY_REGISTERED_UID)
            .remove(KEY_REGISTERED_TOKEN)
            .remove(MacumuFirebaseMessagingService.KEY_PENDING_TOKEN)
            .apply()
        auth.signOut()
        Handler(Looper.getMainLooper()).post { onSignedOut() }
    }

    private fun saveToken(context: Context, uid: String, token: String) {
        if (FirebaseAuth.getInstance().currentUser?.uid != uid || token.isBlank()) return
        val prefs = context.getSharedPreferences(MacumuFirebaseMessagingService.PREFS, Context.MODE_PRIVATE)
        val deviceId = getInstallationId(prefs)
        val previousUid = prefs.getString(KEY_REGISTERED_UID, null)
        val previousToken = prefs.getString(KEY_REGISTERED_TOKEN, null)
        val userTokens = FirebaseFirestore.getInstance().collection("users").document(uid)
            .collection("deviceTokens")

        val data = mapOf(
            "ownerUid" to uid,
            "installationId" to deviceId,
            "token" to token,
            "platform" to "android",
            "updatedAt" to FieldValue.serverTimestamp()
        )
        userTokens.document(deviceId).set(data).addOnSuccessListener {
            if (FirebaseAuth.getInstance().currentUser?.uid != uid) return@addOnSuccessListener
            prefs.edit().putString(KEY_REGISTERED_UID, uid).putString(KEY_REGISTERED_TOKEN, token)
                .remove(MacumuFirebaseMessagingService.KEY_PENDING_TOKEN).apply()
            // Clean up the old schema where the FCM token itself was the document ID.
            if (previousUid == uid && !previousToken.isNullOrBlank() && previousToken != token) {
                enqueueDeletion(prefs, uid, previousToken)
                deleteCloudDocuments(context, uid, listOf(previousToken)) {}
            }
        }
    }

    private fun getInstallationId(prefs: android.content.SharedPreferences): String {
        val existing = prefs.getString(KEY_DEVICE_ID, null)
        if (!existing.isNullOrBlank()) return existing
        val created = UUID.randomUUID().toString()
        prefs.edit().putString(KEY_DEVICE_ID, created).commit()
        return created
    }

    private fun retryPendingDeletions(context: Context, uid: String) {
        val prefs = context.getSharedPreferences(MacumuFirebaseMessagingService.PREFS, Context.MODE_PRIVATE)
        val pending = prefs.getStringSet(KEY_PENDING_DELETIONS, emptySet()).orEmpty().toSet()
        pending.filter { it.startsWith("$uid|") }.forEach { entry ->
            val documentId = entry.substringAfter('|')
            if (documentId.isNotBlank()) deleteCloudDocuments(context, uid, listOf(documentId)) {}
        }
    }

    private fun enqueueDeletion(prefs: android.content.SharedPreferences, uid: String, documentId: String) {
        if (documentId.isBlank()) return
        val updated = prefs.getStringSet(KEY_PENDING_DELETIONS, emptySet()).orEmpty().toMutableSet()
        updated.add("$uid|$documentId")
        prefs.edit().putStringSet(KEY_PENDING_DELETIONS, updated).commit()
    }

    private fun deleteCloudDocuments(
        context: Context,
        uid: String,
        documentIds: List<String>,
        onFinished: () -> Unit
    ) {
        if (documentIds.isEmpty()) {
            onFinished()
            return
        }
        val prefs = context.getSharedPreferences(MacumuFirebaseMessagingService.PREFS, Context.MODE_PRIVATE)
        val firestore = FirebaseFirestore.getInstance()
        var remaining = documentIds.distinct().size
        val lock = Any()
        documentIds.distinct().forEach { documentId ->
            firestore.collection("users").document(uid).collection("deviceTokens").document(documentId)
                .delete().addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val updated = prefs.getStringSet(KEY_PENDING_DELETIONS, emptySet()).orEmpty().toMutableSet()
                        updated.remove("$uid|$documentId")
                        prefs.edit().putStringSet(KEY_PENDING_DELETIONS, updated).apply()
                    }
                    val done = synchronized(lock) { --remaining == 0 }
                    if (done) onFinished()
                }
        }
    }
}
