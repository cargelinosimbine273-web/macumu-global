package com.example.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.data.local.AppDatabase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CancellationException
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Synchronizes Room notification outbox records to the user's Firestore inbox. */
class NotificationSyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return Result.success()
        val database = AppDatabase.getDatabase(applicationContext)
        val dao = database.notificationDao()
        val priceWatchDao = database.priceWatchDao()
        val firestore = FirebaseFirestore.getInstance()
        return try {
            for (notification in dao.getPendingCloudSync(uid)) {
                if (isStopped || FirebaseAuth.getInstance().currentUser?.uid != uid) {
                    throw CancellationException("A conta mudou durante a sincronização de notificações.")
                }
                if (notification.ownerUid != uid || notification.eventKey.isBlank()) continue
                val ref = firestore.collection("users").document(uid)
                    .collection("notifications").document(notification.eventKey)
                val finalReadState = firestore.runTransaction { transaction ->
                    val existing = transaction.get(ref)
                    if (existing.exists()) {
                        // A read state is monotonic: another device cannot turn a read alert unread.
                        val mergedReadState = (existing.getBoolean("isRead") == true) || notification.isRead
                        transaction.update(ref, "isRead", mergedReadState)
                        mergedReadState
                    } else {
                        transaction.set(ref, mapOf(
                            "ownerUid" to uid,
                            "targetRole" to notification.targetRole,
                            "eventKey" to notification.eventKey,
                            "title" to notification.title,
                            "message" to notification.message,
                            "relatedOrderCode" to notification.relatedOrderCode,
                            "isRead" to notification.isRead,
                            "timestamp" to notification.timestamp
                        ))
                        notification.isRead
                    }
                }.awaitResult()
                dao.updateReadStateFromCloud(uid, notification.eventKey, finalReadState)
            }
            // Process durable deletion tombstones on every authenticated sync cycle.
            // This queue is the source of truth for deletions; it must never depend on the
            // SharedPreferences dirty marker, which can be missing after an abrupt app stop.
            val watchPrefs = applicationContext.getSharedPreferences("macumu_price_watch_sync", Context.MODE_PRIVATE)
            val dirtyUid = watchPrefs.getString("dirty_uid", null)
            val dirtyMarker = watchPrefs.getString("dirty_marker", null)
            for (deletion in priceWatchDao.getPendingDeletions(uid)) {
                if (isStopped || FirebaseAuth.getInstance().currentUser?.uid != uid) {
                    throw CancellationException("A conta mudou durante a sincronização das eliminações Price Watch.")
                }
                if (deletion.ownerUid != uid) continue
                firestore.collection("users").document(uid).collection("priceWatches")
                    .document(deletion.globalProductId).delete().awaitResult()
                // Remove the tombstone only after Firestore confirms the idempotent delete.
                priceWatchDao.removeDeletion(deletion.globalProductId, uid)
            }
            // Reconcile active Price Watch records only when a local change marked them dirty,
            // conserving Firebase Spark reads/writes without delaying queued deletions.
            if (dirtyUid == uid) for (watch in priceWatchDao.getWatchesOnce(uid)) {
                if (isStopped || FirebaseAuth.getInstance().currentUser?.uid != uid) {
                    throw CancellationException("A conta mudou durante a sincronização de alertas de preço.")
                }
                if (watch.ownerUid != uid) continue
                firestore.collection("users").document(uid)
                    .collection("priceWatches").document(watch.globalProductId)
                    .set(mapOf(
                        "globalProductId" to watch.globalProductId,
                        "ownerUid" to uid,
                        "targetPriceMzn" to watch.targetPriceMzn,
                        "baselinePriceMzn" to watch.baselinePriceMzn,
                        "lastObservedPriceMzn" to watch.lastObservedPriceMzn,
                        "lastAlertedPriceMzn" to watch.lastAlertedPriceMzn,
                        "createdAt" to watch.createdAt,
                        "updatedAt" to watch.updatedAt
                    ), com.google.firebase.firestore.SetOptions.merge()).awaitResult()
            }
            if (dirtyUid == uid && watchPrefs.getString("dirty_marker", null) == dirtyMarker) {
                watchPrefs.edit().remove("dirty_uid").remove("dirty_marker").apply()
            }
            Result.success()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            Result.retry()
        }
    }
}

private suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { continuation ->
    addOnCompleteListener { task ->
        if (!continuation.isActive) return@addOnCompleteListener
        if (task.isSuccessful) {
            @Suppress("UNCHECKED_CAST")
            continuation.resume(task.result as T)
        } else {
            continuation.resumeWithException(
                task.exception ?: IllegalStateException("Falha ao sincronizar notificação.")
            )
        }
    }
}
