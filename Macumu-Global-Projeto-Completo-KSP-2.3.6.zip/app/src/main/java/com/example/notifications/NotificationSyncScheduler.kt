package com.example.notifications

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/** Spark-compatible notification outbox scheduling; uses only on-device WorkManager. */
object NotificationSyncScheduler {
    private const val PERIODIC_NAME = "macumu_notification_outbox_periodic"
    private const val IMMEDIATE_NAME = "macumu_notification_outbox_now"

    fun schedule(context: Context) {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val request = PeriodicWorkRequestBuilder<NotificationSyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            PERIODIC_NAME, ExistingPeriodicWorkPolicy.KEEP, request
        )
    }

    fun enqueue(context: Context, uid: String) {
        if (uid.isBlank()) return
        val request = OneTimeWorkRequestBuilder<NotificationSyncWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .addTag("macumu_notification_outbox_$uid")
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "$IMMEDIATE_NAME-$uid", ExistingWorkPolicy.KEEP, request
        )
    }
}
