package com.example.recommendations

import com.example.data.local.ProductEntity

/**
 * Motor de recomendações local, explicável e offline.
 * Usa sinais observáveis da própria aplicação; não afirma ser IA nem envia
 * histórico pessoal para serviços externos.
 */
object RecommendationEngine {
    data class Result(val products: List<ProductEntity>, val explanation: String)

    fun recommend(
        products: List<ProductEntity>,
        favoriteProductIds: Set<Long>,
        watchedGlobalIds: Set<String>,
        limit: Int = 8
    ): Result {
        val eligible = products.filter { it.isApproved && it.stock > 0 && it.id !in favoriteProductIds }
        if (eligible.isEmpty()) return Result(emptyList(), "Ainda não há produtos disponíveis para recomendar.")

        val favorites = products.filter { it.id in favoriteProductIds }
        val preferredCategories = favorites.groupingBy { it.category }.eachCount()
        val preferredMarkets = favorites.map { it.marketName }.filter { it.isNotBlank() }.toSet()
        val watchedProducts = products.filter { it.globalProductId in watchedGlobalIds }
        val watchedCategories = watchedProducts.map { it.category }.toSet()
        val watchedMarkets = watchedProducts.map { it.marketName }.filter { it.isNotBlank() }.toSet()

        val ranked = eligible.map { product ->
            var score = 0.0
            val favoriteCategoryCount = preferredCategories[product.category] ?: 0
            if (favoriteCategoryCount > 0) score += 5.0 + favoriteCategoryCount.coerceAtMost(3)
            if (product.category in watchedCategories) score += 4.0
            if (product.marketName.isNotBlank() && product.marketName in preferredMarkets) score += 2.5
            if (product.marketName.isNotBlank() && product.marketName in watchedMarkets) score += 2.0
            if (product.isFeatured) score += 2.0
            score += product.rating.coerceIn(0f, 5f) * 1.2
            score += kotlin.math.ln1p(product.reviewCount.coerceAtLeast(0).toDouble())
            if (product.isNational) score += 0.25
            // Desempate estável: avaliações, depois produto mais recente.
            Triple(product, score, product.rating * 1000f + product.createdAt / 1_000_000_000f)
        }.sortedWith(compareByDescending<Triple<ProductEntity, Double, Float>> { it.second }
            .thenByDescending { it.third })
            .take(limit).map { it.first }

        val explanation = when {
            favorites.isNotEmpty() && watchedProducts.isNotEmpty() ->
                "Sugestões relacionadas com os seus favoritos e produtos que acompanha, combinadas com avaliações e disponibilidade."
            favorites.isNotEmpty() ->
                "Sugestões relacionadas com as categorias dos seus favoritos, combinadas com avaliações e disponibilidade."
            watchedProducts.isNotEmpty() ->
                "Sugestões relacionadas com os produtos cujo preço acompanha, combinadas com avaliações e disponibilidade."
            else ->
                "Selecção inicial baseada em destaque, avaliações, opiniões e disponibilidade."
        }
        return Result(ranked, explanation)
    }
}
