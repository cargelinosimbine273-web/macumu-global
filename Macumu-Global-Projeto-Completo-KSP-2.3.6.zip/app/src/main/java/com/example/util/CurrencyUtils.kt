package com.example.util

/** All monetary values in the marketplace are stored and settled in MZN.
 * Do not display estimated foreign-currency conversions from hard-coded or stale rates.
 * Foreign-currency display can be enabled later using a dated, validated exchange-rate snapshot.
 */
object CurrencyUtils {
    fun formatPrice(amountMzn: Double, currency: String): String {
        val safeAmount = if (amountMzn.isFinite()) amountMzn else 0.0
        return "%,.2f MZN".format(java.util.Locale.US, safeAmount).replace(",", " ").trim()
    }
}
