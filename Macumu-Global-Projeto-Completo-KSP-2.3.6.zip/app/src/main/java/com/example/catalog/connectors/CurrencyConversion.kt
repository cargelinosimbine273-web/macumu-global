package com.example.catalog.connectors

import java.math.BigDecimal
import java.math.RoundingMode

/** Manual, administrator-supplied exchange rates. Each rate means MZN for one unit of foreign currency.
 * No network call or automatic market-rate claim is made; the administrator must record the source/date.
 */
object CurrencyConversion {
    fun toMzn(amount: Double, currency: String, ratesMznPerUnit: Map<String, Double>): Double? {
        if (!amount.isFinite() || amount <= 0.0) return null
        val code = currency.trim().uppercase()
        if (code == "MZN") return amount
        val rate = ratesMznPerUnit[code] ?: return null
        if (!rate.isFinite() || rate <= 0.0) return null
        return BigDecimal.valueOf(amount).multiply(BigDecimal.valueOf(rate))
            .setScale(2, RoundingMode.HALF_UP).toDouble().takeIf { it.isFinite() && it > 0.0 }
    }
}
