package com.example.catalog.connectors

import java.net.URI
import java.util.Locale

/** Availability is deliberately explicit: a connector is not "live" until the platform
 * has granted the required API/feed access and the owner has supplied credentials. */
enum class ConnectorAvailability {
    MANUAL_IMPORT_READY,
    API_ACCESS_REQUIRES_APPROVAL,
    ACCOUNT_API_KEY_REQUIRED,
    PARTNER_FEED_REQUIRED,
    NOT_AVAILABLE_FOR_PUBLIC_PRODUCT_FEED
}

data class CatalogConnectorInfo(
    val id: String,
    val displayName: String,
    val availability: ConnectorAvailability,
    val description: String,
    val officialDocumentationUrl: String? = null
)

data class ImportedOffer(
    val sourceId: String,
    val externalProductId: String,
    val title: String,
    val description: String = "",
    val category: String = "Outros",
    val price: Double,
    val currency: String,
    val imageUrl: String = "",
    val productUrl: String,
    val affiliateUrl: String = "",
    val availabilityText: String = "Disponibilidade a confirmar",
    val importedAt: Long = System.currentTimeMillis()
)

/** Normalized contract for future official API and partner-feed adapters. */
interface CatalogConnector {
    val info: CatalogConnectorInfo
    fun normalize(raw: Map<String, String>): ImportedOffer?
}

object CatalogConnectorRegistry {
    val connectors: List<CatalogConnectorInfo> = listOf(
        CatalogConnectorInfo(
            id = "aliexpress",
            displayName = "AliExpress",
            availability = ConnectorAvailability.API_ACCESS_REQUIRES_APPROVAL,
            description = "A integração automática depende de acesso aprovado à API de afiliados e de credenciais próprias.",
            officialDocumentationUrl = "https://portals.aliexpress.com/"
        ),
        CatalogConnectorInfo(
            id = "alibaba",
            displayName = "Alibaba.com",
            availability = ConnectorAvailability.API_ACCESS_REQUIRES_APPROVAL,
            description = "A Open Platform exige registo de programador, aprovação da aplicação e permissões para as APIs necessárias.",
            officialDocumentationUrl = "https://openapi.alibaba.com/doc/doc.htm"
        ),
        CatalogConnectorInfo(
            id = "shein",
            displayName = "SHEIN",
            availability = ConnectorAvailability.NOT_AVAILABLE_FOR_PUBLIC_PRODUCT_FEED,
            description = "A documentação pública consultada é orientada a operações de vendedores; não comprova um feed público de afiliados para catálogo Macumu. Exige acordo/acesso apropriado.",
            officialDocumentationUrl = "https://open.sheincorp.com/pt/documents/apidoc/1000001"
        ),
        CatalogConnectorInfo(
            id = "digistore24",
            displayName = "Digistore24",
            availability = ConnectorAvailability.ACCOUNT_API_KEY_REQUIRED,
            description = "A API existe, mas requer uma chave da conta e permissões adequadas; não guardar a chave no APK.",
            officialDocumentationUrl = "https://www.digistore24.com/api/docs/index.html"
        ),
        CatalogConnectorInfo(
            id = "mozambique",
            displayName = "Lojas moçambicanas",
            availability = ConnectorAvailability.PARTNER_FEED_REQUIRED,
            description = "Importação por CSV pronta; sincronização automática requer autorização e um feed/API fornecido por cada loja."
        )
    )

    fun find(id: String): CatalogConnectorInfo? = connectors.firstOrNull { it.id == id }
}

/**
 * CSV import is the zero-cost bootstrap path. Expected headers (case-insensitive):
 * sourceId, externalProductId, title, description, category, price, currency,
 * imageUrl, productUrl, affiliateUrl, availabilityText.
 * It parses and validates data only; it does not publish products automatically.
 */
object CatalogCsvImporter {
    private val requiredHeaders = setOf("sourceid", "externalproductid", "title", "price", "currency", "producturl")

    data class RejectedCsvRow(val rowNumber: Int, val reason: String)
    data class ImportReport(val offers: List<ImportedOffer>, val totalRows: Int, val rejected: List<RejectedCsvRow>)

    fun parse(csv: String): List<ImportedOffer> = parseWithReport(csv).offers

    private data class CsvRecord(val startLine: Int, val cells: List<String>)

    fun parseWithReport(csv: String): ImportReport {
        require(csv.length <= 5 * 1024 * 1024) { "O ficheiro CSV excede o limite de 5 MB." }
        val records = parseRecords(csv.trimStart('\uFEFF'))
        if (records.size < 2) return ImportReport(emptyList(), 0, emptyList())
        val headers = records.first().cells.map { it.trim().lowercase(Locale.ROOT) }
        require(headers.toSet().containsAll(requiredHeaders)) {
            "CSV inválido. Cabeçalhos obrigatórios: ${requiredHeaders.joinToString(", ")}"
        }
        require(headers.distinct().size == headers.size) { "CSV inválido: existem cabeçalhos duplicados." }
        val offers = mutableListOf<ImportedOffer>()
        val rejected = mutableListOf<RejectedCsvRow>()
        records.drop(1).forEach { record ->
            val rowNumber = record.startLine
            val cells = record.cells
            if (cells.size != headers.size) {
                rejected += RejectedCsvRow(rowNumber, "Número de colunas diferente do cabeçalho (${cells.size}/${headers.size}).")
                return@forEach
            }
            val row = headers.mapIndexed { column, key -> key to cells[column].trim() }.toMap()
            val source = row["sourceid"].orEmpty().lowercase(Locale.ROOT)
            val externalId = row["externalproductid"].orEmpty()
            val title = row["title"].orEmpty()
            val price = row["price"]?.replace(',', '.')?.toDoubleOrNull()
            val currency = row["currency"].orEmpty().uppercase(Locale.ROOT)
            val productUrl = row["producturl"].orEmpty()
            val reason = when {
                source.isBlank() -> "sourceId vazio"
                !source.matches(Regex("[a-z0-9_-]{2,40}")) -> "sourceId inválido"
                externalId.isBlank() || externalId.length > 180 -> "externalProductId vazio ou demasiado longo"
                title.isBlank() || title.length > 180 -> "título vazio ou demasiado longo"
                price == null || !price.isFinite() || price <= 0.0 -> "preço inválido"
                currency !in setOf("MZN", "USD", "EUR", "ZAR", "CNY", "GBP") -> "moeda não suportada"
                !isHttpsUrl(productUrl) -> "productUrl deve usar HTTPS válido"
                row["imageurl"].orEmpty().isNotBlank() && !isHttpsUrl(row["imageurl"].orEmpty()) -> "imageUrl deve usar HTTPS válido"
                row["affiliateurl"].orEmpty().isNotBlank() && !isHttpsUrl(row["affiliateurl"].orEmpty()) -> "affiliateUrl deve usar HTTPS válido"
                else -> null
            }
            if (reason != null) {
                rejected += RejectedCsvRow(rowNumber, reason)
            } else {
                offers += ImportedOffer(
                    sourceId = source, externalProductId = externalId, title = title,
                    description = row["description"].orEmpty(),
                    category = row["category"].takeUnless { it.isNullOrBlank() } ?: "Outros",
                    price = price!!, currency = currency,
                    imageUrl = row["imageurl"].orEmpty(), productUrl = productUrl,
                    affiliateUrl = row["affiliateurl"].orEmpty(),
                    availabilityText = row["availabilitytext"].orEmpty().ifBlank { "Disponibilidade a confirmar" }
                )
            }
        }
        return ImportReport(offers, records.size - 1, rejected)
    }

    /** RFC-4180 style parser: supports escaped quotes, commas and line breaks inside quoted cells. */
    private fun parseRecords(csv: String): List<CsvRecord> {
        val records = mutableListOf<CsvRecord>()
        val cells = mutableListOf<String>()
        val cell = StringBuilder()
        var quoted = false
        var line = 1
        var recordStartLine = 1
        var index = 0
        while (index < csv.length) {
            val ch = csv[index]
            when {
                ch == '"' && quoted && index + 1 < csv.length && csv[index + 1] == '"' -> {
                    cell.append('"'); index++
                }
                ch == '"' -> quoted = !quoted
                (ch == ',' && !quoted) -> { cells += cell.toString(); cell.setLength(0) }
                (ch == '\n' || ch == '\r') && !quoted -> {
                    if (ch == '\r' && index + 1 < csv.length && csv[index + 1] == '\n') index++
                    cells += cell.toString(); cell.setLength(0)
                    if (cells.any { it.isNotBlank() }) records += CsvRecord(recordStartLine, cells.toList())
                    cells.clear(); line++; recordStartLine = line
                }
                else -> {
                    cell.append(ch)
                    if (ch == '\n') line++
                }
            }
            index++
        }
        require(!quoted) { "CSV inválido: existe uma célula com aspas não fechadas." }
        cells += cell.toString()
        if (cells.any { it.isNotBlank() }) records += CsvRecord(recordStartLine, cells.toList())
        return records
    }

    private fun isHttpsUrl(value: String): Boolean = try {
        val uri = URI(value)
        uri.scheme.equals("https", ignoreCase = true) && !uri.host.isNullOrBlank() && uri.userInfo == null
    } catch (_: Exception) { false }

}
