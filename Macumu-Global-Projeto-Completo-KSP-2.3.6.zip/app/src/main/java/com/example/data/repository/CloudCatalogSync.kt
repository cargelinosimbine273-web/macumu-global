package com.example.data.repository

import com.example.data.local.ProductEntity
import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Client-side catalogue transport. Sellers can publish only their own pending listings;
 * approved catalogue entries are readable by all signed-in users. Approval itself is
 * deliberately server/admin controlled by Firestore rules.
 */
class CloudCatalogSync(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private val products = firestore.collection("products")

    suspend fun publishPending(product: ProductEntity) = withContext(Dispatchers.IO) {
        val uid = auth.currentUser?.uid ?: throw IllegalStateException("É necessário iniciar sessão para publicar produtos.")
        require(product.ownerUid == uid) { "O produto não pertence à conta autenticada." }
        require(product.globalProductId.isNotBlank()) { "O produto não tem identificador global." }
        val data = product.toCloudMap().toMutableMap().apply {
            put("ownerUid", uid)
            put("isApproved", false)
            put("updatedAt", System.currentTimeMillis())
        }
        val ref = products.document(product.globalProductId)
        val existing = Tasks.await(ref.get())
        if (existing.exists()) {
            val existingOwner = existing.getString("ownerUid")
            val alreadyApproved = existing.getBoolean("isApproved") == true
            require(existingOwner == uid) { "Este identificador global já pertence a outro vendedor." }
            require(!alreadyApproved) { "Um produto aprovado não pode ser substituído pelo vendedor." }
            // Update only seller-editable fields. This supports a genuine re-import of a
            // pending offer without touching moderation, ratings, ownership or approval data.
            Tasks.await(ref.update(mapOf(
                "title" to data["title"],
                "description" to data["description"],
                "category" to data["category"],
                "priceMzn" to data["priceMzn"],
                "promoPriceMzn" to data["promoPriceMzn"],
                "stock" to data["stock"],
                "sellerName" to data["sellerName"],
                "sellerType" to data["sellerType"],
                "sellerLocation" to data["sellerLocation"],
                "isNational" to data["isNational"],
                "imageUrl" to data["imageUrl"],
                "deliveryEstimate" to data["deliveryEstimate"],
                "marketName" to data["marketName"],
                "regionZone" to data["regionZone"],
                "updatedAt" to System.currentTimeMillis()
            )))
        } else {
            try {
                Tasks.await(ref.create(data))
            } catch (error: Exception) {
                // Handle concurrent/retried create safely; never overwrite another owner's doc.
                val afterRace = Tasks.await(ref.get())
                require(afterRace.exists() && afterRace.getString("ownerUid") == uid &&
                    afterRace.getBoolean("isApproved") != true) {
                    throw error
                }
            }
        }
    }

    suspend fun downloadApproved(): List<ProductEntity> = withContext(Dispatchers.IO) {
        val snapshot = Tasks.await(products.whereEqualTo("isApproved", true).get())
        snapshot.documents.mapNotNull { doc -> doc.toProductEntity() }
    }

    /**
     * Spark-compatible moderation: Firestore Security Rules enforce the trusted admin
     * custom claim. The client refreshes and checks the claim for clear UX, while the
     * Firestore rules remain the actual security boundary.
     */
    suspend fun setApprovalAsAdmin(globalProductId: String, approved: Boolean) = withContext(Dispatchers.IO) {
        require(globalProductId.isNotBlank()) { "Identificador global do produto inválido." }
        val user = auth.currentUser ?: throw IllegalStateException("Inicia sessão como administrador.")
        val tokenResult = Tasks.await(user.getIdToken(true))
        require(tokenResult.claims["admin"] == true) {
            "Esta conta não possui autorização administrativa no Firebase."
        }
        val now = System.currentTimeMillis()
        Tasks.await(products.document(globalProductId).update(
            mapOf(
                "isApproved" to approved,
                "moderationStatus" to if (approved) "APPROVED" else "REJECTED",
                "moderatedBy" to user.uid,
                "moderatedAt" to now,
                "updatedAt" to now
            )
        ))
    }

    fun listenApprovedCatalog(
        onProducts: (List<ProductEntity>) -> Unit,
        onError: (Exception) -> Unit = {}
    ): ListenerRegistration = products.whereEqualTo("isApproved", true)
        .addSnapshotListener { snapshot, error ->
            if (error != null) { onError(error); return@addSnapshotListener }
            if (snapshot != null) onProducts(snapshot.documents.mapNotNull { it.toProductEntity() })
        }

    private fun ProductEntity.toCloudMap(): Map<String, Any?> = mapOf(
        "globalProductId" to globalProductId,
        "ownerUid" to ownerUid,
        "title" to title,
        "description" to description,
        "category" to category,
        "priceMzn" to priceMzn,
        "promoPriceMzn" to promoPriceMzn,
        "stock" to stock,
        "sellerId" to sellerId,
        "sellerName" to sellerName,
        "sellerType" to sellerType,
        "sellerLocation" to sellerLocation,
        "isNational" to isNational,
        "rating" to rating.toDouble(),
        "reviewCount" to reviewCount,
        "imageUrl" to imageUrl,
        "deliveryEstimate" to deliveryEstimate,
        "isApproved" to isApproved,
        "isFeatured" to isFeatured,
        "marketName" to marketName,
        "regionZone" to regionZone,
        "createdAt" to createdAt
    )

    private fun com.google.firebase.firestore.DocumentSnapshot.toProductEntity(): ProductEntity? {
        val globalId = getString("globalProductId") ?: id
        val title = getString("title") ?: return null
        val description = getString("description") ?: ""
        val category = getString("category") ?: "Outros"
        return ProductEntity(
            id = 0,
            globalProductId = globalId,
            ownerUid = getString("ownerUid") ?: "",
            title = title,
            description = description,
            category = category,
            priceMzn = getDouble("priceMzn") ?: 0.0,
            promoPriceMzn = getDouble("promoPriceMzn"),
            stock = (getLong("stock") ?: 0L).toInt(),
            sellerId = getLong("sellerId") ?: 0L,
            sellerName = getString("sellerName") ?: "Vendedor Macumu",
            sellerType = getString("sellerType") ?: "FORMAL",
            sellerLocation = getString("sellerLocation") ?: "",
            isNational = getBoolean("isNational") ?: true,
            rating = (getDouble("rating") ?: 0.0).toFloat(),
            reviewCount = (getLong("reviewCount") ?: 0L).toInt(),
            imageUrl = getString("imageUrl") ?: "",
            deliveryEstimate = getString("deliveryEstimate") ?: "A confirmar",
            isApproved = true,
            isFeatured = getBoolean("isFeatured") ?: false,
            marketName = getString("marketName") ?: "",
            regionZone = getString("regionZone") ?: "",
            createdAt = getLong("createdAt") ?: System.currentTimeMillis()
        )
    }
}
