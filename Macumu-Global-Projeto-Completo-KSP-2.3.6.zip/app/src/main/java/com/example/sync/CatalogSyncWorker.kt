package com.example.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.data.local.AppDatabase
import com.example.data.repository.MacumuRepository
import com.google.firebase.auth.FirebaseAuth

/** Retries seller uploads from the Room outbox and refreshes approved listings. */
class CatalogSyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return try {
            val database = AppDatabase.getDatabase(applicationContext)
            val repository = MacumuRepository(database)
            // Public approved catalogue may be refreshed even for signed-out visitors.
            repository.syncApprovedCloudCatalog()
            val uid = FirebaseAuth.getInstance().currentUser?.uid
            if (!uid.isNullOrBlank()) {
                if (!repository.processCatalogUploadQueue(uid)) Result.retry() else Result.success()
            } else {
                // Keep the queue; it will be retried after the user signs in and the app schedules sync.
                Result.success()
            }
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
