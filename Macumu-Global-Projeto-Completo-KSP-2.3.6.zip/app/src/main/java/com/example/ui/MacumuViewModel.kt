package com.example.ui

import android.app.Application
import android.content.SharedPreferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AffiliateLinkEntity
import com.example.data.local.AppDatabase
import com.example.data.local.CartItemEntity
import com.example.data.local.DisputeEntity
import com.example.data.local.LedgerEntryEntity
import com.example.data.local.NotificationEntity
import com.example.data.local.OrderEntity
import com.example.data.local.ProductEntity
import com.example.data.local.PriceWatchEntity
import com.example.data.local.PriceHistoryEntity
import com.example.data.local.WithdrawalEntity
import com.example.catalog.connectors.ImportedOffer
import com.example.data.repository.MacumuRepository
import com.example.recommendations.RecommendationEngine
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import com.example.data.local.UserRegistrationEntity
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class CatalogImportItemResult(
    val sourceId: String,
    val externalProductId: String,
    val title: String,
    val status: String,
    val detail: String,
    val localProductId: Long? = null
)

enum class AppRole(val label: String, val description: String) {
    COMPRADOR("Comprador", "Explore produtos nacionais e globais com pagamento seguro"),
    VENDEDOR("Vendedor", "Comercialize produtos formais e informais sem taxas ocultas"),
    AFILIADO("Afiliado", "Ganhe até 15% de comissão partilhando links no WhatsApp"),
    ADMIN("Gestão / Desenvolvedor", "Acesso restrito: Validação de adesões e custódia")
}

sealed class ActionPermission {
    data object Allowed : ActionPermission()
    data class RequiresLogin(val action: String, val message: String) : ActionPermission()
    data class AwaitingApproval(val userName: String, val requestedRole: String) : ActionPermission()
}

sealed class Screen {
    data object WelcomeRoleSelect : Screen()
    data object Home : Screen()
    data class ProductDetail(val productId: Long) : Screen()
    data object Cart : Screen()
    data object Checkout : Screen()
    data class OrderTracking(val orderCode: String) : Screen()
    data object SellerDashboard : Screen()
    data object PublishProduct : Screen()
    data object AffiliateDashboard : Screen()
    data object AdminDashboard : Screen()
    data object Account : Screen()
    data object Notifications : Screen()
    data object PriceWatch : Screen()
}

class MacumuViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: MacumuRepository

    private val homePreferences: SharedPreferences =
        application.getSharedPreferences("macumu_home_preferences", android.content.Context.MODE_PRIVATE)

    private val _favoriteProductIds = MutableStateFlow(
        homePreferences.getStringSet("favorite_product_ids", emptySet())?.mapNotNull { it.toLongOrNull() }?.toSet() ?: emptySet()
    )
    val favoriteProductIds: StateFlow<Set<Long>> = _favoriteProductIds.asStateFlow()

    private val _priceWatchTargets = MutableStateFlow(
        homePreferences.all.filterKeys { it.startsWith("price_watch_") }
            .mapNotNull { (key, value) -> key.removePrefix("price_watch_").toLongOrNull()?.let { id -> (value as? Float)?.let { id to it.toDouble() } } }
            .toMap()
    )
    val priceWatchTargets: StateFlow<Map<Long, Double>> = _priceWatchTargets.asStateFlow()
    private val _priceHistoryByProduct = MutableStateFlow<Map<String, List<PriceHistoryEntity>>>(emptyMap())
    val priceHistoryByProduct: StateFlow<Map<String, List<PriceHistoryEntity>>> = _priceHistoryByProduct.asStateFlow()
    private val _catalogImportResults = MutableStateFlow<List<CatalogImportItemResult>>(emptyList())
    val catalogImportResults: StateFlow<List<CatalogImportItemResult>> = _catalogImportResults.asStateFlow()
    private val _catalogRetryMessage = MutableStateFlow("")
    val catalogRetryMessage: StateFlow<String> = _catalogRetryMessage.asStateFlow()

    private val firebaseAuth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    private var favoritesListener: ListenerRegistration? = null
    private var priceWatchListener: ListenerRegistration? = null
    private var notificationCloudListener: ListenerRegistration? = null
    private var catalogListener: ListenerRegistration? = null
    private var authListener: FirebaseAuth.AuthStateListener? = null
    private var activeFavoritesUid: String? = null
    private val authenticatedUid = MutableStateFlow(firebaseAuth.currentUser?.uid.orEmpty())

    init {
        val db = AppDatabase.getDatabase(application)
        repository = MacumuRepository(db)
        observeFavoriteAccount()
        viewModelScope.launch {
            combine(
                repository.getAllProducts(),
                authenticatedUid.flatMapLatest { uid ->
                    if (uid.isBlank()) kotlinx.coroutines.flow.flowOf(emptyList())
                    else repository.observePriceWatches(uid)
                }
            ) { allProducts, watches -> allProducts to watches }.collect { (allProducts, watches) ->
                val productsByGlobalId = allProducts.associateBy { it.globalProductId }
                val mapped = mutableMapOf<Long, Double>()
                val histories = mutableMapOf<String, List<PriceHistoryEntity>>()
                watches.forEach { watch ->
                    productsByGlobalId[watch.globalProductId]?.let { product ->
                        mapped[product.id] = watch.targetPriceMzn
                    }
                    histories[watch.globalProductId] = repository.observePriceHistory(watch.globalProductId).first()
                }
                _priceWatchTargets.value = mapped
                _priceHistoryByProduct.value = histories
            }
        }
        // Pull centrally approved listings into Room; Room remains the offline source of truth.
        viewModelScope.launch { runCatching { repository.syncApprovedCloudCatalog() } }
        // Live listener updates Room as soon as an approved product changes in Firestore.
        catalogListener = repository.listenApprovedCatalog(
            onProducts = { remote ->
                viewModelScope.launch {
                    repository.saveRemoteCatalog(remote)
                    // Re-resolve cloud favorites after their products arrive locally.
                    activeFavoritesUid?.let { refreshFavoritesFromCloud(it) }
                }
            }
        )
    }

    /**
     * Mantém os favoritos locais disponíveis offline e sincroniza usando o ID global do produto.
     * O ID numérico Room permanece apenas como referência local para a interface antiga.
     */
    private fun observeFavoriteAccount() {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            authenticatedUid.value = auth.currentUser?.uid.orEmpty()
            favoritesListener?.remove()
            favoritesListener = null
            priceWatchListener?.remove()
            priceWatchListener = null
            notificationCloudListener?.remove()
            notificationCloudListener = null
            val user = auth.currentUser
            if (user == null) {
                activeFavoritesUid = null
                _favoriteProductIds.value = readFavoriteIds("favorite_product_ids")
                return@AuthStateListener
            }

            activeFavoritesUid = user.uid
            notificationCloudListener = firestore.collection("users").document(user.uid)
                .collection("notifications").addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || firebaseAuth.currentUser?.uid != user.uid) return@addSnapshotListener
                    viewModelScope.launch {
                        snapshot.documents.forEach { document ->
                            val eventKey = document.getString("eventKey") ?: document.id
                            val title = document.getString("title") ?: return@forEach
                            val message = document.getString("message") ?: ""
                            val timestamp = document.getLong("timestamp") ?: System.currentTimeMillis()
                            val role = document.getString("targetRole") ?: "COMPRADOR"
                            repository.saveCloudNotification(NotificationEntity(
                                targetRole = role, ownerUid = user.uid, eventKey = eventKey,
                                title = title, message = message,
                                isRead = document.getBoolean("isRead") ?: false,
                                timestamp = timestamp
                            ))
                        }
                    }
                }
            com.example.sync.CatalogSyncScheduler.requestImmediate(application)
            priceWatchListener = firestore.collection("users").document(user.uid)
                .collection("priceWatches").addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    viewModelScope.launch {
                        snapshot.documents.forEach { document ->
                            val globalId = document.getString("globalProductId") ?: document.id
                            val target = document.getDouble("targetPriceMzn") ?: return@forEach
                            val baseline = document.getDouble("baselinePriceMzn") ?: target
                            val observed = document.getDouble("lastObservedPriceMzn") ?: baseline
                            repository.savePriceWatch(PriceWatchEntity(
                                globalProductId = globalId, ownerUid = user.uid,
                                targetPriceMzn = target, baselinePriceMzn = baseline,
                                lastObservedPriceMzn = observed,
                                lastAlertedPriceMzn = document.getDouble("lastAlertedPriceMzn"),
                                createdAt = document.getLong("createdAt") ?: System.currentTimeMillis(),
                                updatedAt = document.getLong("updatedAt") ?: System.currentTimeMillis()
                            ))
                        }
                    }
                }
            val accountKey = "favorite_product_ids_${user.uid}"
            val accountIds = readFavoriteIds(accountKey)
            val legacyGuestIds = readFavoriteIds("favorite_product_ids")
            val initialIds = accountIds + legacyGuestIds
            saveFavoriteIdsLocally(initialIds)
            homePreferences.edit().remove("favorite_product_ids").apply()

            var firstSnapshot = true
            favoritesListener = firestore.collection("users")
                .document(user.uid)
                .collection("favorites")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener
                    viewModelScope.launch {
                        val remoteLocalIds = snapshot.documents.mapNotNull { document ->
                            val globalId = document.getString("globalProductId") ?: document.id
                            // Never interpret another device's Room row ID as this device's ID.
                            repository.getProductByGlobalId(globalId)?.id
                        }.toSet()

                        if (firstSnapshot) {
                            firstSnapshot = false
                            val merged = _favoriteProductIds.value + remoteLocalIds
                            saveFavoriteIdsLocally(merged)
                            // Migra favoritos locais/antigos para documentos identificados globalmente.
                            (merged - remoteLocalIds).forEach { id ->
                                writeFavoriteToCloud(user.uid, id, true)
                            }
                        } else {
                            saveFavoriteIdsLocally(remoteLocalIds)
                        }
                    }
                }
        }
        authListener = listener
        firebaseAuth.addAuthStateListener(listener)
    }

    private suspend fun refreshFavoritesFromCloud(uid: String) {
        if (activeFavoritesUid != uid) return
        runCatching {
            val localIds = withContext(Dispatchers.IO) {
                val snapshot = com.google.android.gms.tasks.Tasks.await(
                    firestore.collection("users").document(uid).collection("favorites").get()
                )
                snapshot.documents.mapNotNull { document ->
                    val globalId = document.getString("globalProductId") ?: document.id
                    repository.getProductByGlobalId(globalId)?.id
                }.toSet()
            }
            if (activeFavoritesUid == uid) saveFavoriteIdsLocally(localIds)
        }
    }

    private fun readFavoriteIds(key: String): Set<Long> =
        homePreferences.getStringSet(key, emptySet())
            ?.mapNotNull(String::toLongOrNull)?.toSet() ?: emptySet()

    private fun saveFavoriteIdsLocally(ids: Set<Long>) {
        _favoriteProductIds.value = ids
        val uid = activeFavoritesUid
        val key = if (uid == null) "favorite_product_ids" else "favorite_product_ids_${uid}"
        homePreferences.edit().putStringSet(key, ids.map(Long::toString).toSet()).apply()
    }

    private fun writeFavoriteToCloud(uid: String, productId: Long, favorite: Boolean) {
        viewModelScope.launch {
            val product = repository.getProductById(productId) ?: return@launch
            val reference = firestore.collection("users").document(uid)
                .collection("favorites").document(product.globalProductId)
            if (favorite) {
                reference.set(
                    mapOf(
                        "globalProductId" to product.globalProductId,
                        "legacyLocalProductId" to product.id,
                        "productTitle" to product.title,
                        "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                    )
                )
            } else {
                reference.delete()
            }
        }
    }

    override fun onCleared() {
        favoritesListener?.remove()
        priceWatchListener?.remove()
        notificationCloudListener?.remove()
        catalogListener?.remove()
        authListener?.let { firebaseAuth.removeAuthStateListener(it) }
        super.onCleared()
    }

    // Navigation and Role State
    private val _currentRole = MutableStateFlow(AppRole.COMPRADOR)
    val currentRole: StateFlow<AppRole> = _currentRole.asStateFlow()

    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val screenBackStack = mutableListOf<Screen>()

    // Global Preferences
    private val _currency = MutableStateFlow("MZN")
    val currency: StateFlow<String> = _currency.asStateFlow()

    private val _language = MutableStateFlow("Português")
    val language: StateFlow<String> = _language.asStateFlow()

    // Filters
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("Todas")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedScope = MutableStateFlow("TODOS") // "TODOS", "NACIONAL", "GLOBAL"
    val selectedScope: StateFlow<String> = _selectedScope.asStateFlow()

    private val _selectedMarket = MutableStateFlow<String?>(null)
    val selectedMarket: StateFlow<String?> = _selectedMarket.asStateFlow()

    private val _selectedInformalZone = MutableStateFlow("TODOS") // "TODOS", "SUL", "CENTRO", "NORTE"
    val selectedInformalZone: StateFlow<String> = _selectedInformalZone.asStateFlow()

    // Data Streams from Repository
    val products: StateFlow<List<ProductEntity>> = repository.getAllProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Recomendações locais e explicáveis, recalculadas quando catálogo/favoritos/acompanhamentos mudam. */
    val recommendedProducts: StateFlow<RecommendationEngine.Result> = combine(
        repository.getAllProducts(), favoriteProductIds, repository.observePriceWatches(firebaseAuth.currentUser?.uid.orEmpty())
    ) { allProducts, favorites, watches ->
        RecommendationEngine.recommend(
            products = allProducts,
            favoriteProductIds = favorites,
            watchedGlobalIds = watches.map { it.globalProductId }.toSet()
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        RecommendationEngine.Result(emptyList(), "A preparar recomendações…")
    )

    val priceWatchItems: StateFlow<List<Pair<ProductEntity, PriceWatchEntity>>> = combine(
        repository.getAllProducts(), repository.observePriceWatches(firebaseAuth.currentUser?.uid.orEmpty())
    ) { allProducts, watches ->
        val byGlobalId = allProducts.associateBy { it.globalProductId }
        watches.mapNotNull { watch -> byGlobalId[watch.globalProductId]?.let { it to watch } }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun observePriceHistory(globalProductId: String) = repository.observePriceHistory(globalProductId)

    val cartItems: StateFlow<List<CartItemEntity>> = repository.getCartItems()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<OrderEntity>> = repository.getAllOrders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val ledgerEntries: StateFlow<List<LedgerEntryEntity>> = repository.getAllLedgerEntries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val withdrawals: StateFlow<List<WithdrawalEntity>> = repository.getAllWithdrawals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val affiliateLinks: StateFlow<List<AffiliateLinkEntity>> = repository.getAffiliateLinks("AFIL-MOZ-88")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val disputes: StateFlow<List<DisputeEntity>> = repository.getAllDisputes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Marks a notification locally first, then mirrors the read state to the account inbox. */
    fun markNotificationAsRead(notification: NotificationEntity) {
        val uid = firebaseAuth.currentUser?.uid ?: return
        if (notification.ownerUid != uid || notification.eventKey.isBlank()) return
        viewModelScope.launch {
            repository.markNotificationAsRead(uid, notification.eventKey)
            com.example.notifications.NotificationSyncScheduler.enqueue(getApplication(), uid)
        }
    }

    /** Rebinds the notification stream whenever the authenticated account changes. */
    val notifications: StateFlow<List<NotificationEntity>> = authenticatedUid
        .flatMapLatest { uid ->
            if (uid.isBlank()) kotlinx.coroutines.flow.flowOf(emptyList())
            else repository.getNotificationsForRole("COMPRADOR", uid)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Price observations and history are owned by PriceWatchWorker. Keeping this
        // ViewModel read-only avoids racing the worker and skipping price-change events.
    }

    // Registrations & Developer Approval Stream
    val userRegistrations: StateFlow<List<UserRegistrationEntity>> = repository.getAllUserRegistrations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active User (null = Visitante/Guest)
    private val _currentUser = MutableStateFlow<UserRegistrationEntity?>(null)
    val currentUser: StateFlow<UserRegistrationEntity?> = _currentUser.asStateFlow()

    // Developer / Administrator Security Protection
    private val _isDeveloperAuthenticated = MutableStateFlow(false)
    val isDeveloperAuthenticated: StateFlow<Boolean> = _isDeveloperAuthenticated.asStateFlow()

    // 99.5% Online Connectivity Indicator
    private val _isOnline = MutableStateFlow(true)
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    // Action requiring authentication/approval prompt modal
    private val _authPromptAction = MutableStateFlow<String?>(null)
    val authPromptAction: StateFlow<String?> = _authPromptAction.asStateFlow()

    // Notice when account is pending developer review
    private val _pendingApprovalNotice = MutableStateFlow<UserRegistrationEntity?>(null)
    val pendingApprovalNotice: StateFlow<UserRegistrationEntity?> = _pendingApprovalNotice.asStateFlow()

    // Filtered Products for Buyer Home - Universal search across all items
    val filteredProducts: StateFlow<List<ProductEntity>> = combine(
        products, _searchQuery, _selectedCategory, _selectedScope, _selectedMarket
    ) { list, query, category, scope, market ->
        val cleanQuery = query.trim()
        list.filter { product ->
            val matchesQuery = cleanQuery.isBlank() ||
                    product.title.contains(cleanQuery, ignoreCase = true) ||
                    product.description.contains(cleanQuery, ignoreCase = true) ||
                    product.category.contains(cleanQuery, ignoreCase = true) ||
                    product.sellerLocation.contains(cleanQuery, ignoreCase = true) ||
                    product.sellerName.contains(cleanQuery, ignoreCase = true) ||
                    product.marketName.contains(cleanQuery, ignoreCase = true) ||
                    product.regionZone.contains(cleanQuery, ignoreCase = true)

            // When searching, find across all products unless user specifically locked a category/market
            val matchesCategory = (cleanQuery.isNotBlank() && category == "Todas") ||
                    category == "Todas" || product.category.equals(category, ignoreCase = true)

            val matchesScope = when {
                cleanQuery.isNotBlank() -> true
                scope == "NACIONAL" -> product.isNational
                scope == "GLOBAL" -> !product.isNational
                else -> true
            }

            val matchesMarket = market.isNullOrBlank() ||
                    product.marketName.equals(market, ignoreCase = true) ||
                    product.sellerLocation.contains(market, ignoreCase = true)

            product.isApproved && matchesQuery && matchesCategory && matchesScope && matchesMarket
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Financial Balances Derived from Ledger
    val financialStats: StateFlow<FinancialStats> = ledgerEntries.combine(orders) { entries, allOrders ->
        var escrowLocked = 0.0
        var sellerAvailable = 0.0
        var affiliateBalance = 0.0
        var platformCommissions = 0.0

        for (entry in entries) {
            when (entry.account) {
                "ESCROW_CUSTODIA" -> {
                    if (entry.type == "CREDITO") escrowLocked += entry.amountMzn
                    else escrowLocked -= entry.amountMzn
                }
                "CARTEIRA_VENDEDOR" -> {
                    if (entry.type == "CREDITO") sellerAvailable += entry.amountMzn
                    else sellerAvailable -= entry.amountMzn
                }
                "CARTEIRA_AFILIADO" -> {
                    if (entry.type == "CREDITO") affiliateBalance += entry.amountMzn
                    else affiliateBalance -= entry.amountMzn
                }
                "COMISSAO_PLATAFORMA" -> {
                    if (entry.type == "CREDITO") platformCommissions += entry.amountMzn
                }
            }
        }

        val gmv = allOrders.sumOf { it.totalMzn }
        FinancialStats(
            escrowLockedMzn = escrowLocked.coerceAtLeast(0.0),
            sellerAvailableMzn = sellerAvailable.coerceAtLeast(0.0),
            affiliateBalanceMzn = affiliateBalance.coerceAtLeast(0.0),
            platformCommissionsMzn = platformCommissions.coerceAtLeast(0.0),
            totalGmvMzn = gmv,
            totalOrdersCount = allOrders.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FinancialStats())

    // Navigation Methods
    fun navigateTo(screen: Screen) {
        screenBackStack.add(_currentScreen.value)
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        if (screenBackStack.isNotEmpty()) {
            _currentScreen.value = screenBackStack.removeAt(screenBackStack.size - 1)
            return true
        }
        if (_currentScreen.value !is Screen.Home) {
            _currentScreen.value = Screen.Home
            return true
        }
        return false
    }

    fun selectRole(role: AppRole) {
        _currentRole.value = role
        when (role) {
            AppRole.COMPRADOR -> _currentScreen.value = Screen.Home
            AppRole.VENDEDOR -> _currentScreen.value = Screen.SellerDashboard
            AppRole.AFILIADO -> _currentScreen.value = Screen.AffiliateDashboard
            AppRole.ADMIN -> _currentScreen.value = Screen.AdminDashboard
        }
    }

    fun setCurrency(newCurrency: String) {
        _currency.value = newCurrency
    }

    fun setLanguage(newLanguage: String) {
        _language.value = newLanguage
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun selectScope(scope: String) {
        _selectedScope.value = scope
    }

    fun selectMarket(marketName: String?) {
        _selectedMarket.value = marketName
    }

    fun selectInformalZone(zone: String) {
        _selectedInformalZone.value = zone
    }

    fun clearAllFilters() {
        _searchQuery.value = ""
        _selectedCategory.value = "Todas"
        _selectedScope.value = "TODOS"
        _selectedMarket.value = null
        _selectedInformalZone.value = "TODOS"
    }

    // Favoritos persistentes localmente e sincronizados com Firestore quando há sessão.
    fun toggleFavorite(productId: Long) {
        val updated = _favoriteProductIds.value.toMutableSet().apply {
            if (!add(productId)) remove(productId)
        }.toSet()
        saveFavoriteIdsLocally(updated)
        firebaseAuth.currentUser?.uid?.let { uid ->
            writeFavoriteToCloud(uid, productId, productId in updated)
        }
    }

    /** Cria um acompanhamento com preço-alvo explícito e persiste-o localmente. */
    fun startPriceWatch(product: ProductEntity, targetPriceMzn: Double) {
        val current = product.promoPriceMzn ?: product.priceMzn
        if (targetPriceMzn <= 0.0 || targetPriceMzn >= current || !targetPriceMzn.isFinite()) return
        viewModelScope.launch {
            val uid = firebaseAuth.currentUser?.uid ?: return@launch
            val now = System.currentTimeMillis()
            val watch = PriceWatchEntity(
                globalProductId = product.globalProductId, ownerUid = uid,
                targetPriceMzn = targetPriceMzn, baselinePriceMzn = current,
                lastObservedPriceMzn = current, createdAt = now, updatedAt = now
            )
            repository.savePriceWatch(watch)
            repository.recordPrice(product.globalProductId, current, "INITIAL_PRICE")
            getApplication<Application>().getSharedPreferences("macumu_price_watch_sync", android.content.Context.MODE_PRIVATE)
                .edit().putString("dirty_uid", uid).putString("dirty_marker", java.util.UUID.randomUUID().toString()).apply()
            com.example.notifications.NotificationSyncScheduler.enqueue(getApplication(), uid)
        }
    }

    fun removePriceWatch(productId: Long) {
        viewModelScope.launch {
            val uid = firebaseAuth.currentUser?.uid ?: return@launch
            val product = repository.getProductById(productId) ?: return@launch
            repository.deletePriceWatch(product.globalProductId, uid)
            getApplication<Application>().getSharedPreferences("macumu_price_watch_sync", android.content.Context.MODE_PRIVATE)
                .edit().putString("dirty_uid", uid).putString("dirty_marker", java.util.UUID.randomUUID().toString()).apply()
            com.example.notifications.NotificationSyncScheduler.enqueue(getApplication(), uid)
        }
    }

    // Actions
    fun addToCart(product: ProductEntity, quantity: Int = 1) {
        viewModelScope.launch {
            repository.addToCart(product, quantity)
        }
    }

    fun updateCartQuantity(id: Long, quantity: Int) {
        viewModelScope.launch {
            repository.updateCartQuantity(id, quantity)
        }
    }

    fun removeFromCart(id: Long) {
        viewModelScope.launch {
            repository.removeFromCart(id)
        }
    }

    fun placeOrder(
        buyerName: String,
        buyerPhone: String,
        province: String,
        cityOrDistrict: String,
        neighborhood: String,
        referencePoint: String,
        paymentMethod: String,
        affiliateCode: String?,
        onOrderSuccess: (String) -> Unit
    ) {
        viewModelScope.launch {
            val items = cartItems.value
            if (items.isEmpty()) return@launch
            val orderCode = repository.placeOrder(
                buyerName = buyerName,
                buyerPhone = buyerPhone,
                province = province,
                cityOrDistrict = cityOrDistrict,
                neighborhood = neighborhood,
                referencePoint = referencePoint,
                items = items,
                paymentMethod = paymentMethod,
                affiliateCode = affiliateCode
            )
            onOrderSuccess(orderCode)
        }
    }

    fun confirmOrderReception(orderCode: String) {
        viewModelScope.launch {
            repository.confirmOrderReception(orderCode)
        }
    }

    fun updateSellerOrderStatus(orderCode: String, newStatus: String) {
        viewModelScope.launch {
            repository.updateSellerOrderStatus(orderCode, newStatus)
        }
    }

    fun publishProduct(
        title: String,
        description: String,
        category: String,
        priceMzn: Double,
        promoPriceMzn: Double?,
        stock: Int,
        sellerType: String,
        sellerLocation: String,
        isNational: Boolean,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.createProduct(
                ProductEntity(
                    title = title,
                    description = description,
                    category = category,
                    priceMzn = priceMzn,
                    promoPriceMzn = promoPriceMzn,
                    stock = stock,
                    sellerId = 101L,
                    ownerUid = firebaseAuth.currentUser?.uid.orEmpty(),
                    sellerName = if (sellerType == "INFORMAL") "Bazar & Vendedor Local" else "Loja Oficial Registada",
                    sellerType = sellerType,
                    sellerLocation = sellerLocation,
                    isNational = isNational,
                    isApproved = false // O produto vai para análise da comissão; só após aprovação vai para a vitrine pública
                )
            )
            onSuccess()
        }
    }

    /** Importa ofertas CSV como pendentes e apresenta o resultado individual de cada linha.
     * A gravação local e a fila Room são o primeiro passo; a sincronização Firestore é assíncrona.
     */
    fun importCatalogOffers(offers: List<ImportedOffer>) {
        viewModelScope.launch {
            val uid = firebaseAuth.currentUser?.uid
            if (uid.isNullOrBlank()) {
                _catalogImportResults.value = offers.map { offer ->
                    CatalogImportItemResult(offer.sourceId, offer.externalProductId, offer.title, "FALHOU", "Sessão não autenticada.")
                }
                return@launch
            }
            val results = mutableListOf<CatalogImportItemResult>()
            val seenBatchKeys = mutableSetOf<String>()
            offers.forEach { offer ->
                try {
                    require(firebaseAuth.currentUser?.uid == uid) { "A conta mudou durante a importação; operação interrompida." }
                    val normalizedSource = offer.sourceId.trim().lowercase(java.util.Locale.ROOT)
                    val normalizedExternalId = offer.externalProductId.trim()
                    require(normalizedSource.matches(Regex("[a-z0-9_-]{2,40}"))) { "Identificador da origem inválido." }
                    require(normalizedExternalId.isNotBlank() && normalizedExternalId.length <= 180) { "Identificador externo inválido." }
                    require(seenBatchKeys.add("$normalizedSource|${normalizedExternalId.lowercase(java.util.Locale.ROOT)}")) {
                        "Produto duplicado no mesmo ficheiro; a primeira ocorrência foi mantida."
                    }
                    require(offer.currency.equals("MZN", true)) { "Preço ainda não convertido para MZN." }
                    require(offer.price.isFinite() && offer.price > 0.0) { "Preço inválido." }
                    require(offer.title.isNotBlank() && offer.title.length <= 180) { "Título vazio ou demasiado longo." }
                    require(isValidCatalogHttpsUrl(offer.productUrl)) { "Ligação do produto deve ser HTTPS válida." }
                    require(offer.imageUrl.isBlank() || isValidCatalogHttpsUrl(offer.imageUrl)) { "Ligação da imagem inválida; utilize HTTPS." }
                    require(offer.affiliateUrl.isBlank() || isValidCatalogHttpsUrl(offer.affiliateUrl)) { "Ligação de afiliado inválida; utilize HTTPS." }
                    val stableOfferId = java.util.UUID.nameUUIDFromBytes(
                        "$uid|$normalizedSource|${normalizedExternalId.lowercase(java.util.Locale.ROOT)}".toByteArray(Charsets.UTF_8)
                    ).toString()
                    val existing = repository.getProductByGlobalId(stableOfferId)
                    require(existing == null || existing.ownerUid == uid) { "Produto pertence a outra conta; actualização bloqueada." }
                    val sourceDescription = buildString {
                        append(offer.description)
                        append("\n\nReferência externa: ${offer.externalProductId}")
                        append("\nOrigem: ${offer.productUrl}")
                        if (offer.affiliateUrl.isNotBlank()) append("\nLigação de afiliado: ${offer.affiliateUrl}")
                        if (offer.availabilityText.isNotBlank()) append("\nDisponibilidade: ${offer.availabilityText}")
                        append("\nData da última importação: ${offer.importedAt}")
                    }.trim()
                    val materialChange = existing != null && (
                        existing.priceMzn != offer.price || existing.title != offer.title ||
                            existing.category != offer.category ||
                            (offer.imageUrl.isNotBlank() && existing.imageUrl != offer.imageUrl) ||
                            !existing.description.contains("Origem: ${offer.productUrl}") ||
                            (offer.affiliateUrl.isNotBlank() && !existing.description.contains("Ligação de afiliado: ${offer.affiliateUrl}")) ||
                            (offer.description.isNotBlank() && !existing.description.startsWith(offer.description))
                        )
                    if (existing?.isApproved == true && !materialChange) {
                        results += CatalogImportItemResult(offer.sourceId, offer.externalProductId, offer.title,
                            "SEM_ALTERACOES", "Produto já publicado; os dados relevantes não mudaram.", existing.id)
                        return@forEach
                    }
                    require(existing?.isApproved != true) {
                        "Produto já publicado. Alterações relevantes exigem revisão administrativa; a versão aprovada foi preservada."
                    }
                    val importedProduct = ProductEntity(
                        id = existing?.id ?: 0L,
                        globalProductId = stableOfferId,
                        ownerUid = uid,
                        title = offer.title,
                        description = sourceDescription,
                        category = offer.category,
                        priceMzn = offer.price,
                        stock = existing?.stock ?: 0,
                        sellerId = existing?.sellerId ?: 0L,
                        sellerName = "Catálogo Macumu • ${offer.sourceId}",
                        sellerType = "FORMAL",
                        sellerLocation = if (offer.sourceId.equals("mozambique", true)) "Moçambique" else "Internacional",
                        isNational = offer.sourceId.equals("mozambique", true),
                        rating = existing?.rating ?: 0f,
                        reviewCount = existing?.reviewCount ?: 0,
                        imageUrl = offer.imageUrl.ifBlank { existing?.imageUrl.orEmpty() },
                        deliveryEstimate = "A confirmar pelo fornecedor",
                        isApproved = false,
                        isFeatured = existing?.isFeatured ?: false,
                        marketName = offer.sourceId,
                        regionZone = if (offer.sourceId.equals("mozambique", true)) "SUL" else "INTERNACIONAL",
                        createdAt = existing?.createdAt ?: System.currentTimeMillis()
                    )
                    val localId = if (existing == null) repository.createProduct(importedProduct).toLong() else {
                        repository.updateImportedProduct(importedProduct)
                        existing.id
                    }
                    results += CatalogImportItemResult(offer.sourceId, offer.externalProductId, offer.title,
                        "NA_FILA", "Guardado localmente; sincronização com Firestore pendente.", localId)
                } catch (error: Exception) {
                    results += CatalogImportItemResult(offer.sourceId, offer.externalProductId, offer.title,
                        "FALHOU", error.message ?: error.javaClass.simpleName)
                }
            }
            _catalogImportResults.value = results
            _catalogRetryMessage.value = "${results.count { it.status == "NA_FILA" }} produto(s) guardado(s) na fila local; ${results.count { it.status == "FALHOU" }} falha(s) de validação/gravação."
        }
    }

    private fun isValidCatalogHttpsUrl(value: String): Boolean = try {
        val uri = java.net.URI(value.trim())
        uri.scheme.equals("https", true) && !uri.host.isNullOrBlank() && uri.userInfo == null
    } catch (_: Exception) { false }

    /** Reprocessa a fila durável; itens que falharem permanecem na Room com tentativas e erro registados. */
    fun retryCatalogSynchronization() {
        viewModelScope.launch {
            if (firebaseAuth.currentUser == null) {
                _catalogRetryMessage.value = "Inicie sessão para sincronizar o catálogo."
                return@launch
            }
            val uid = firebaseAuth.currentUser?.uid
            if (uid.isNullOrBlank()) {
                _catalogRetryMessage.value = "A sessão terminou. Inicie sessão para continuar."
                return@launch
            }
            val allSucceeded = runCatching { repository.processCatalogUploadQueue(uid) }.getOrDefault(false)
            val pending = runCatching { repository.getCatalogUploadQueue(uid) }.getOrDefault(emptyList())
            _catalogRetryMessage.value = if (pending.isEmpty() && allSucceeded) {
                "Sincronização concluída: não existem produtos pendentes."
            } else {
                "${pending.size} produto(s) continuam pendentes. Consulte os erros e tente novamente quando a ligação estiver estável."
            }
            if (_catalogImportResults.value.isNotEmpty()) {
                val pendingById = pending.associateBy { it.productLocalId }
                _catalogImportResults.value = _catalogImportResults.value.map { item ->
                    val queueItem = item.localProductId?.let(pendingById::get)
                    when {
                        item.status !in setOf("NA_FILA", "PENDENTE") -> item
                        queueItem == null -> item.copy(status = "SINCRONIZADO", detail = "Enviado para Firestore; aprovação administrativa continua necessária.")
                        else -> item.copy(status = "PENDENTE", detail = "Tentativas: ${queueItem.attempts}. " + queueItem.lastError.ifBlank { "A aguardar nova tentativa de sincronização." })
                    }
                }
            }
        }
    }

    fun approveProduct(productId: Long) {
        viewModelScope.launch {
            repository.setProductApproval(productId, true)
        }
    }

    fun rejectProduct(productId: Long) {
        viewModelScope.launch {
            repository.setProductApproval(productId, false)
        }
    }

    fun requestWithdrawal(
        beneficiaryType: String,
        name: String,
        method: String,
        phoneOrAccount: String,
        amountMzn: Double,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.requestWithdrawal(
                beneficiaryType = beneficiaryType,
                beneficiaryName = name,
                method = method,
                phoneNumberOrAccount = phoneOrAccount,
                amountMzn = amountMzn
            )
            onSuccess()
        }
    }

    fun processWithdrawal(id: Long, approved: Boolean) {
        viewModelScope.launch {
            repository.processWithdrawal(id, approved)
        }
    }

    fun generateAffiliateLink(product: ProductEntity, onGenerated: (AffiliateLinkEntity) -> Unit) {
        viewModelScope.launch {
            val link = repository.generateAffiliateLink(product, "AFIL-MOZ-88")
            onGenerated(link)
        }
    }

    fun recordAffiliateClick(linkId: Long) {
        viewModelScope.launch {
            repository.recordAffiliateClick(linkId)
        }
    }

    fun openDispute(
        orderCode: String,
        buyerName: String,
        sellerName: String,
        reason: String,
        description: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.createDispute(orderCode, buyerName, sellerName, reason, description)
            onSuccess()
        }
    }

    fun resolveDispute(disputeId: Long, orderCode: String, refundToBuyer: Boolean, notes: String) {
        viewModelScope.launch {
            repository.resolveDispute(disputeId, orderCode, refundToBuyer, notes)
        }
    }

    // --- Developer Security & Authentication ---
    /**
     * Administrative access is intentionally disabled in this test build.
     * A PIN embedded in an APK can be extracted and is not a secure access control.
     * Re-enable this only after implementing server-side role checks (Firebase Auth
     * custom claims + Firestore Security Rules or an equivalent trusted backend).
     */
    fun verifyDeveloperPin(pin: String): Boolean {
        _isDeveloperAuthenticated.value = false
        return false
    }

    fun logoutDeveloper() {
        _isDeveloperAuthenticated.value = false
        _currentRole.value = AppRole.COMPRADOR
        _currentScreen.value = Screen.Home
    }

    // --- User Registration & Developer Approval ---
    fun setAuthPromptAction(action: String?) {
        _authPromptAction.value = action
    }

    fun setPendingApprovalNotice(user: UserRegistrationEntity?) {
        _pendingApprovalNotice.value = user
    }

    fun registerUser(
        fullName: String,
        phoneNumber: String,
        email: String,
        requestedRole: String,
        sellerType: String,
        businessName: String,
        province: String,
        onSuccess: (UserRegistrationEntity) -> Unit
    ) {
        viewModelScope.launch {
            val id = repository.registerUser(
                fullName = fullName,
                phoneNumber = phoneNumber,
                email = email,
                requestedRole = requestedRole,
                sellerType = sellerType,
                businessName = businessName,
                province = province
            )
            val newReg = repository.getRegistrationById(id) ?: UserRegistrationEntity(
                id = id,
                fullName = fullName,
                phoneNumber = phoneNumber,
                email = email,
                requestedRole = requestedRole,
                sellerType = sellerType,
                businessName = businessName,
                province = province,
                status = "PENDING_APPROVAL"
            )
            _currentUser.value = newReg
            _pendingApprovalNotice.value = newReg
            _authPromptAction.value = null
            onSuccess(newReg)
        }
    }

    fun loginUser(user: UserRegistrationEntity) {
        _currentUser.value = user
        _authPromptAction.value = null
        if (user.status == "PENDING_APPROVAL") {
            _pendingApprovalNotice.value = user
        }
    }

    fun logoutUser() {
        _currentUser.value = null
        _currentRole.value = AppRole.COMPRADOR
        _currentScreen.value = Screen.Home
    }

    fun approveUserRegistration(id: Long, notes: String = "Validado e aprovado pelo Desenvolvedor") {
        viewModelScope.launch {
            repository.approveUserRegistration(id, notes)
            if (_currentUser.value?.id == id) {
                _currentUser.value = _currentUser.value?.copy(status = "APPROVED", approvedAt = System.currentTimeMillis())
                _pendingApprovalNotice.value = null
            }
        }
    }

    fun rejectUserRegistration(id: Long, notes: String = "Rejeitado na verificação") {
        viewModelScope.launch {
            repository.rejectUserRegistration(id, notes)
            if (_currentUser.value?.id == id) {
                _currentUser.value = _currentUser.value?.copy(status = "REJECTED")
            }
        }
    }

    /**
     * Checks if a user is permitted to perform a critical action:
     * - "COMPRAR"
     * - "VENDER"
     * - "AFILIAR"
     */
    fun checkPermission(action: String): ActionPermission {
        val user = _currentUser.value
        return when {
            user == null -> ActionPermission.RequiresLogin(
                action = action,
                message = when (action) {
                    "COMPRAR" -> "Para adicionar ao carrinho e finalizar compras protegidas por custódia, crie ou inicie sessão na sua conta."
                    "VENDER" -> "Para publicar produtos em mercados formais ou feiras informais, é necessário cadastrar a sua loja/bazar."
                    "AFILIAR" -> "Para gerar links e receber comissões de até 15%, crie a sua conta de afiliado."
                    else -> "É necessário iniciar sessão ou registar a sua conta no Macumu Global."
                }
            )
            user.status == "PENDING_APPROVAL" -> ActionPermission.AwaitingApproval(
                userName = user.fullName,
                requestedRole = user.requestedRole
            )
            else -> ActionPermission.Allowed
        }
    }
}


data class FinancialStats(
    val escrowLockedMzn: Double = 0.0,
    val sellerAvailableMzn: Double = 0.0,
    val affiliateBalanceMzn: Double = 0.0,
    val platformCommissionsMzn: Double = 0.0,
    val totalGmvMzn: Double = 0.0,
    val totalOrdersCount: Int = 0
)
