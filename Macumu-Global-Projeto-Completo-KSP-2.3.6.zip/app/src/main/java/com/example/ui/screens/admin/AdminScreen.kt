package com.example.ui.screens.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import com.example.catalog.connectors.CatalogCsvImporter
import com.example.catalog.connectors.CatalogConnectorRegistry
import com.example.catalog.connectors.ImportedOffer
import com.example.catalog.connectors.CurrencyConversion
import com.example.ui.CatalogImportItemResult
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.DisputeEntity
import com.example.data.local.LedgerEntryEntity
import com.example.data.local.ProductEntity
import com.example.data.local.UserRegistrationEntity
import com.example.data.local.WithdrawalEntity
import com.example.ui.FinancialStats
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DarkNavyBackground
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavyCardBorder
import com.example.ui.theme.DarkNavyCardElevated
import com.example.ui.theme.EmolaBlue
import com.example.ui.theme.EscrowAmber
import com.example.ui.theme.MacumuOrange
import com.example.ui.theme.MpesaGreen
import com.example.ui.theme.TextDarkMuted
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.util.CurrencyUtils
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

@Composable
private fun FxRateField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun AdminScreen(
    financialStats: FinancialStats,
    disputes: List<DisputeEntity>,
    withdrawals: List<WithdrawalEntity>,
    ledgerEntries: List<LedgerEntryEntity>,
    products: List<ProductEntity>,
    userRegistrations: List<UserRegistrationEntity> = emptyList(),
    currency: String,
    onResolveDispute: (disputeId: Long, orderCode: String, refundBuyer: Boolean, notes: String) -> Unit,
    onProcessWithdrawal: (id: Long, approved: Boolean) -> Unit,
    onApproveRegistration: (Long) -> Unit = {},
    onRejectRegistration: (Long) -> Unit = {},
    onApproveProduct: (Long) -> Unit = {},
    onRejectProduct: (Long) -> Unit = {},
    onImportCatalogOffers: (List<ImportedOffer>) -> Unit = {},
    importResults: List<CatalogImportItemResult> = emptyList(),
    catalogRetryMessage: String = "",
    onRetryCatalogSync: () -> Unit = {},
    onExitDeveloperMode: () -> Unit = {}
) {
    val pendingCount = userRegistrations.count { it.status == "PENDING_APPROVAL" }
    val pendingProductsCount = products.count { !it.isApproved }
    var selectedTab by remember { mutableStateOf(if (pendingCount > 0) "ADESOES" else if (pendingProductsCount > 0) "PRODUTOS" else "GERAL") }
    val context = LocalContext.current
    var importedOffers by remember { mutableStateOf<List<ImportedOffer>>(emptyList()) }
    var rejectedCsvRows by remember { mutableStateOf<List<CatalogCsvImporter.RejectedCsvRow>>(emptyList()) }
    var importMessage by remember { mutableStateOf("Seleccione um ficheiro CSV para pré-visualizar o catálogo.") }
    val fxPrefs = remember { context.getSharedPreferences("macumu_manual_fx_rates", android.content.Context.MODE_PRIVATE) }
    var usdRate by remember { mutableStateOf(fxPrefs.getString("USD", "") ?: "") }
    var eurRate by remember { mutableStateOf(fxPrefs.getString("EUR", "") ?: "") }
    var zarRate by remember { mutableStateOf(fxPrefs.getString("ZAR", "") ?: "") }
    var cnyRate by remember { mutableStateOf(fxPrefs.getString("CNY", "") ?: "") }
    var gbpRate by remember { mutableStateOf(fxPrefs.getString("GBP", "") ?: "") }
    var fxSource by remember { mutableStateOf(fxPrefs.getString("SOURCE", "") ?: "") }
    var fxDate by remember { mutableStateOf(fxPrefs.getString("DATE", "") ?: "") }
    var fxMessage by remember { mutableStateOf("As taxas são introduzidas manualmente. Confirme sempre a fonte e a data.") }
    var fxHistory by remember { mutableStateOf<List<String>>(emptyList()) }
    var cloudRatesAvailable by remember { mutableStateOf(false) }
    val fxUid = FirebaseAuth.getInstance().currentUser?.uid
    val fxDb = remember { FirebaseFirestore.getInstance() }
    DisposableEffect(fxUid) {
        var ratesListener: ListenerRegistration? = null
        var historyListener: ListenerRegistration? = null
        if (!fxUid.isNullOrBlank()) {
            ratesListener = fxDb.collection("platformConfig").document("exchangeRates")
                .addSnapshotListener { snapshot, error ->
                    if (error == null && snapshot != null && snapshot.exists()) {
                        val data = snapshot.data.orEmpty()
                        val rates = data["rates"] as? Map<*, *>
                        fun rate(code: String) = (rates?.get(code) as? Number)?.toString().orEmpty()
                        usdRate = rate("USD").ifBlank { usdRate }
                        eurRate = rate("EUR").ifBlank { eurRate }
                        zarRate = rate("ZAR").ifBlank { zarRate }
                        cnyRate = rate("CNY").ifBlank { cnyRate }
                        gbpRate = rate("GBP").ifBlank { gbpRate }
                        fxSource = (data["source"] as? String).orEmpty().ifBlank { fxSource }
                        fxDate = (data["date"] as? String).orEmpty().ifBlank { fxDate }
                        cloudRatesAvailable = true
                        fxPrefs.edit().putString("USD", usdRate).putString("EUR", eurRate).putString("ZAR", zarRate)
                            .putString("CNY", cnyRate).putString("GBP", gbpRate).putString("SOURCE", fxSource).putString("DATE", fxDate).apply()
                    }
                }
            historyListener = fxDb.collection("platformConfig").document("exchangeRates")
                .collection("history").orderBy("recordedAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .limit(5).addSnapshotListener { snapshot, error ->
                    if (error == null) fxHistory = snapshot?.documents?.map { doc ->
                        "${doc.getString("date").orEmpty()} • ${doc.getString("source").orEmpty()} • ${doc.getString("summary").orEmpty()}"
                    }.orEmpty()
                }
        }
        onDispose { ratesListener?.remove(); historyListener?.remove() }
    }
    fun currentRates(): Map<String, Double> {
        val sourceDateValid = runCatching {
            val recorded = java.time.LocalDate.parse(fxDate)
            val today = java.time.LocalDate.now()
            !recorded.isAfter(today) && !recorded.isBefore(today.minusDays(7))
        }.getOrDefault(false)
        if (fxSource.isBlank() || !sourceDateValid) return emptyMap()
        return listOf("USD" to usdRate, "EUR" to eurRate, "ZAR" to zarRate, "CNY" to cnyRate, "GBP" to gbpRate)
            .mapNotNull { (code, value) -> value.replace(',', '.').toDoubleOrNull()?.takeIf { it.isFinite() && it > 0.0 }?.let { code to it } }.toMap()
    }
    val csvPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: error("Não foi possível abrir o ficheiro seleccionado.")
            }.onSuccess { csv ->
                runCatching { CatalogCsvImporter.parseWithReport(csv) }
                    .onSuccess { report ->
                        val offers = report.offers
                        importedOffers = offers
                        rejectedCsvRows = report.rejected
                        val rates = currentRates()
                        val convertible = offers.count { CurrencyConversion.toMzn(it.price, it.currency, rates) != null }
                        val excluded = offers.size - convertible
                        val rejectedSummary = report.rejected.take(4).joinToString("; ") { "linha ${it.rowNumber}: ${it.reason}" }
                        importMessage = "${report.totalRows} linhas analisadas: ${offers.size} válidas, ${report.rejected.size} rejeitadas. $convertible convertíveis; $excluded sem taxa válida." +
                            if (rejectedSummary.isNotBlank()) " Erros: $rejectedSummary" else ""
                    }
                    .onFailure { error -> importedOffers = emptyList(); rejectedCsvRows = emptyList(); importMessage = error.message ?: "CSV inválido." }
            }.onFailure { error -> importedOffers = emptyList(); rejectedCsvRows = emptyList(); importMessage = error.message ?: "Falha ao ler o ficheiro." }
        }
    }

    val reportSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            val header = "origem;id_externo;produto;estado;detalhe\n"
            val successfulRows = importResults.map { item -> listOf(item.sourceId, item.externalProductId, item.title, item.status, item.detail) }
            val rejectedRows = rejectedCsvRows.map { row -> listOf("CSV", "linha ${row.rowNumber}", "", "CSV_REJEITADO", row.reason) }
            val rows = (successfulRows + rejectedRows).joinToString("\n") { columns ->
                columns.joinToString(";") { value -> "\"${value.replace("\"", "\"\"").replace("\n", " ").replace(";", ",")}\"" }
            }
            runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(header + rows) } }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkNavyBackground)
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Admin Header
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkNavyCardElevated),
                border = BorderStroke(1.dp, DarkNavyCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(MacumuOrange.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = MacumuOrange, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Consola do Desenvolvedor & Admin", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                            Text("Validação de Novos Membros & Custódia", color = TextMuted, fontSize = 10.sp)
                        }
                    }

                    OutlinedButton(
                        onClick = onExitDeveloperMode,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                        border = BorderStroke(1.dp, Color(0xFFEF4444)),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text("Sair", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Subtabs
        item {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "ADESOES" to "Adesões ($pendingCount)",
                    "PRODUTOS" to "Produtos ($pendingProductsCount)",
                    "GERAL" to "Geral",
                    "DISPUTAS" to "Disputas (${disputes.size})",
                    "LEVANTAMENTOS" to "Saques (${withdrawals.count { it.status == "PENDENTE" }})",
                    "LEDGER" to "Ledger",
                    "IMPORTAR" to "Importar"
                ).forEach { (code, label) ->
                    val isSelected = selectedTab == code
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) MacumuOrange else DarkNavyCard,
                        border = BorderStroke(1.dp, if (isSelected) MacumuOrange else DarkNavyCardBorder),
                        modifier = Modifier
                            .clickable { selectedTab = code }
                            .testTag("admin_tab_${code.lowercase()}")
                    ) {
                        Box(modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp), contentAlignment = Alignment.Center) {
                            Text(
                                text = label,
                                color = if (isSelected) Color.White else TextMuted,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        when (selectedTab) {
            "ADESOES" -> {
                // Section: Developer Validation of New Registrations
                item {
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF142438)),
                        border = BorderStroke(1.dp, EmolaBlue.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AdminPanelSettings,
                                    contentDescription = null,
                                    tint = MacumuOrange,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Validação de Adesões pelo Desenvolvedor",
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.5.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "Cada utilizador que se inscreve deve receber o aval do desenvolvedor antes de poder comprar com custódia, publicar produtos ou auferir comissões.",
                                color = TextMuted,
                                fontSize = 10.5.sp,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }

                if (userRegistrations.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                        ) {
                            Text(
                                text = "Nenhuma solicitação de adesão no momento.",
                                color = TextMuted,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                } else {
                    items(userRegistrations) { reg ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                            border = BorderStroke(
                                1.dp,
                                if (reg.status == "PENDING_APPROVAL") EscrowAmber.copy(alpha = 0.8f) else DarkNavyCardBorder
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = reg.fullName,
                                            color = TextWhite,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "Contacto: ${reg.phoneNumber} ${if (reg.email.isNotBlank()) "• ${reg.email}" else ""}",
                                            color = TextMuted,
                                            fontSize = 10.5.sp
                                        )
                                        if (reg.businessName.isNotBlank()) {
                                            Text(
                                                text = "Loja/Bazar: ${reg.businessName} (${reg.province})",
                                                color = MacumuOrange,
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        } else {
                                            Text(
                                                text = "Localização: ${reg.province}",
                                                color = TextMuted,
                                                fontSize = 10.sp
                                            )
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = when (reg.requestedRole) {
                                            "VENDEDOR" -> if (reg.sellerType == "INFORMAL") Color(0xFF4A2500) else Color(0xFF0F3254)
                                            "AFILIADO" -> Color(0xFF2A1550)
                                            else -> Color(0xFF133220)
                                        }
                                    ) {
                                        Text(
                                            text = when (reg.requestedRole) {
                                                "VENDEDOR" -> if (reg.sellerType == "INFORMAL") "Bazar Informal" else "Loja Formal"
                                                "AFILIADO" -> "Afiliado"
                                                else -> "Comprador"
                                            },
                                            color = TextWhite,
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Status Badge
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = when (reg.status) {
                                            "APPROVED" -> Color(0xFF0D331A)
                                            "REJECTED" -> Color(0xFF3E1212)
                                            else -> Color(0xFF3B2706)
                                        }
                                    ) {
                                        Text(
                                            text = when (reg.status) {
                                                "APPROVED" -> "✅ Aprovado pelo Desenvolvedor"
                                                "REJECTED" -> "❌ Adesão Rejeitada"
                                                else -> "⏳ Aguarda Aval do Desenvolvedor"
                                            },
                                            color = when (reg.status) {
                                                "APPROVED" -> MpesaGreen
                                                "REJECTED" -> DangerRed
                                                else -> EscrowAmber
                                            },
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }

                                    // Action buttons if pending
                                    if (reg.status == "PENDING_APPROVAL") {
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            OutlinedButton(
                                                onClick = { onRejectRegistration(reg.id) },
                                                shape = RoundedCornerShape(6.dp),
                                                colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                                                border = BorderStroke(0.5.dp, DangerRed),
                                                modifier = Modifier.height(28.dp)
                                            ) {
                                                Text("Recusar", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                            }

                                            Button(
                                                onClick = { onApproveRegistration(reg.id) },
                                                shape = RoundedCornerShape(6.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = MpesaGreen),
                                                modifier = Modifier.height(28.dp).testTag("approve_user_${reg.id}")
                                            ) {
                                                Text("Aprovar", color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            "PRODUTOS" -> {
                // Section: Platform Analysis Commission for Product Showcase Moderation
                item {
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF142438)),
                        border = BorderStroke(1.dp, EmolaBlue.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Storefront,
                                    contentDescription = null,
                                    tint = MacumuOrange,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Comissão de Análise de Produtos",
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.5.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "Os produtos registados pelos vendedores (formais ou informais) só vão automaticamente para a vitrine pública após a autorização da comissão de moderação.",
                                color = TextMuted,
                                fontSize = 10.5.sp,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }

                if (products.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                        ) {
                            Text(
                                text = "Nenhum produto cadastrado no catálogo.",
                                color = TextMuted,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                } else {
                    items(products) { prod ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                            border = BorderStroke(
                                1.dp,
                                if (!prod.isApproved) EscrowAmber.copy(alpha = 0.8f) else DarkNavyCardBorder
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = prod.title,
                                            color = TextWhite,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.5.sp
                                        )
                                        Text(
                                            text = "Vendedor: ${prod.sellerName} (${prod.sellerType}) • ${prod.sellerLocation}",
                                            color = TextMuted,
                                            fontSize = 10.5.sp
                                        )
                                        Text(
                                            text = "Preço: ${CurrencyUtils.formatPrice(prod.priceMzn, currency)} • Stock: ${prod.stock}",
                                            color = MacumuOrange,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        val importedAt = Regex("Data da última importação: (\\d+)").find(prod.description)?.groupValues?.getOrNull(1)?.toLongOrNull()
                                        if (importedAt != null && System.currentTimeMillis() - importedAt > 30L * 24 * 60 * 60 * 1000) {
                                            Text("⚠ Catálogo desactualizado há mais de 30 dias", color = EscrowAmber, fontSize = 9.sp)
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (prod.isApproved) Color(0xFF0D331A) else Color(0xFF3B2706)
                                    ) {
                                        Text(
                                            text = if (prod.isApproved) "✅ Na Vitrine Pública" else "⏳ Em Análise",
                                            color = if (prod.isApproved) MpesaGreen else EscrowAmber,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (!prod.isApproved) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            OutlinedButton(
                                                onClick = { onRejectProduct(prod.id) },
                                                shape = RoundedCornerShape(6.dp),
                                                colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                                                border = BorderStroke(0.5.dp, DangerRed),
                                                modifier = Modifier.height(28.dp)
                                            ) {
                                                Text("Recusar", fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                            }

                                            Button(
                                                onClick = { onApproveProduct(prod.id) },
                                                shape = RoundedCornerShape(6.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = MpesaGreen),
                                                modifier = Modifier.height(28.dp).testTag("approve_product_${prod.id}")
                                            ) {
                                                Text("Aprovar p/ Vitrine Pública", color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    } else {
                                        Text(
                                            text = "Aprovado pela Comissão da Plataforma",
                                            color = TextDarkMuted,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            "IMPORTAR" -> {
                item {
                    Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = DarkNavyCard), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Taxas cambiais manuais (MZN por 1 unidade)", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Sem serviços pagos nem taxas automáticas. Introduza valores confirmados numa fonte bancária/cambial. Só aceitamos taxas datadas de hoje ou dos últimos 7 dias; depois disso, a conversão fica bloqueada até actualizar.", color = TextMuted, fontSize = 10.sp)
                            FxRateField("1 USD = ? MZN", usdRate) { usdRate = it }
                            FxRateField("1 EUR = ? MZN", eurRate) { eurRate = it }
                            FxRateField("1 ZAR = ? MZN", zarRate) { zarRate = it }
                            FxRateField("1 CNY = ? MZN", cnyRate) { cnyRate = it }
                            FxRateField("1 GBP = ? MZN", gbpRate) { gbpRate = it }
                            FxRateField("Fonte da taxa (banco/casa de câmbio)", fxSource) { fxSource = it }
                            FxRateField("Data da taxa (AAAA-MM-DD)", fxDate) { fxDate = it }
                            Button(onClick = {
                                val values = listOf(usdRate, eurRate, zarRate, cnyRate, gbpRate)
                                val valid = values.all { it.isBlank() || (it.replace(',', '.').toDoubleOrNull()?.let { n -> n.isFinite() && n > 0.0 } == true) }
                                val dateValid = runCatching {
                                    val recorded = java.time.LocalDate.parse(fxDate)
                                    val today = java.time.LocalDate.now()
                                    !recorded.isAfter(today) && !recorded.isBefore(today.minusDays(7))
                                }.getOrDefault(false)
                                if (!valid || fxSource.isBlank() || !dateValid) fxMessage = "Preencha fonte e data válida (AAAA-MM-DD), não futura e com até 7 dias; taxas positivas."
                                else {
                                    fxPrefs.edit().putString("USD", usdRate).putString("EUR", eurRate).putString("ZAR", zarRate).putString("CNY", cnyRate).putString("GBP", gbpRate).putString("SOURCE", fxSource).putString("DATE", fxDate).apply()
                                    val rates = listOf("USD" to usdRate, "EUR" to eurRate, "ZAR" to zarRate, "CNY" to cnyRate, "GBP" to gbpRate)
                                        .mapNotNull { (code, value) -> value.replace(',', '.').toDoubleOrNull()?.let { code to it } }.toMap()
                                    val summary = rates.entries.joinToString { "${it.key}=${it.value}" }
                                    val payload = mapOf("rates" to rates, "source" to fxSource.trim(), "date" to fxDate.trim(),
                                        "updatedBy" to (fxUid ?: ""), "updatedAt" to System.currentTimeMillis())
                                    if (fxUid.isNullOrBlank()) {
                                        fxMessage = "Taxas guardadas localmente. Entre numa conta administrativa para sincronizar com outros administradores."
                                    } else {
                                        fxDb.collection("platformConfig").document("exchangeRates").set(payload)
                                            .addOnSuccessListener {
                                                fxDb.collection("platformConfig").document("exchangeRates").collection("history").add(
                                                    mapOf("rates" to rates, "source" to fxSource.trim(), "date" to fxDate.trim(),
                                                        "summary" to summary, "recordedBy" to fxUid, "recordedAt" to System.currentTimeMillis())
                                                ).addOnSuccessListener { fxMessage = "Taxas guardadas e sincronizadas. Fonte: $fxSource • Data: $fxDate" }
                                                    .addOnFailureListener { fxMessage = "Taxas sincronizadas, mas o histórico não foi gravado. Verifique as regras Firestore." }
                                            }
                                            .addOnFailureListener { fxMessage = "Taxas guardadas localmente; sincronização recusada. Publique as regras e confirme a autorização administrativa. Nenhum serviço pago foi activado." }
                                    }
                                }
                            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MacumuOrange)) { Text("Guardar taxas cambiais", color = Color.White) }
                            Text(fxMessage, color = TextMuted, fontSize = 10.sp)
                            Text(if (cloudRatesAvailable) "Taxas sincronizadas entre administradores autorizados." else "Modo local: sincronização disponível após publicação das regras e autorização administrativa.", color = TextMuted, fontSize = 9.sp)
                            if (fxHistory.isNotEmpty()) {
                                Text("Histórico recente de taxas", color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                                fxHistory.forEach { entry -> Text(entry, color = TextMuted, fontSize = 9.sp) }
                            }
                        }
                    }
                }
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                        border = BorderStroke(1.dp, DarkNavyCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Importação de catálogo (CSV)", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Importação local sem servidor pago. Os produtos são submetidos como pendentes e só aparecem na vitrine depois da aprovação.", color = TextMuted, fontSize = 11.sp)
                            Button(
                                onClick = { csvPicker.launch(arrayOf("text/*", "text/csv", "application/vnd.ms-excel")) },
                                colors = ButtonDefaults.buttonColors(containerColor = MacumuOrange),
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Seleccionar ficheiro CSV", color = Color.White) }
                            Text(importMessage, color = TextMuted, fontSize = 11.sp)
                            if (importedOffers.isNotEmpty()) {
                                Text("Pré-visualização (${importedOffers.size})", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                importedOffers.take(8).forEach { offer ->
                                    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                        Text(offer.title, color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                        Text("${offer.price} ${offer.currency} • ${offer.sourceId} • ${offer.category}", color = TextMuted, fontSize = 10.sp)
                                    }
                                }
                                if (importedOffers.size > 8) Text("+ ${importedOffers.size - 8} ofertas…", color = TextMuted, fontSize = 10.sp)
                                val rates = currentRates()
                                val conversionResults = importedOffers.map { offer ->
                                    val converted = CurrencyConversion.toMzn(offer.price, offer.currency, rates)
                                    val convertedOffer = converted?.let {
                                        val conversionNote = if (offer.currency.equals("MZN", true)) "" else "\nConversão manual: ${offer.price} ${offer.currency} = ${"%.2f".format(java.util.Locale.US, it)} MZN; taxa aplicada: ${rates[offer.currency.uppercase(java.util.Locale.ROOT)]} MZN por unidade; fonte: $fxSource; data: $fxDate."
                                        offer.copy(price = it, currency = "MZN", description = (offer.description + conversionNote).trim())
                                    }
                                    offer to convertedOffer
                                }
                                val convertedOffers = conversionResults.mapNotNull { it.second }
                                val unconvertedCount = conversionResults.count { it.second == null }
                                if (unconvertedCount > 0) {
                                    Text("ATENÇÃO: $unconvertedCount produto(s) não têm taxa cambial válida e serão excluídos desta submissão. Actualize as taxas ou importe-os posteriormente.", color = DangerRed, fontSize = 10.sp)
                                }
                                Button(
                                    onClick = {
                                        onImportCatalogOffers(convertedOffers)
                                        importMessage = "Processamento iniciado para ${convertedOffers.size} produto(s). O resultado individual será apresentado abaixo; sincronização e aprovação são etapas distintas."
                                        importedOffers = emptyList()
                                    },
                                    enabled = convertedOffers.isNotEmpty(),
                                    colors = ButtonDefaults.buttonColors(containerColor = MpesaGreen),
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Submeter ${convertedOffers.size} produtos convertíveis em MZN", color = Color.White) }
                            }
                            if (importResults.isNotEmpty() || rejectedCsvRows.isNotEmpty()) {
                                Text("Relatório por produto", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("${importResults.count { it.status == "SINCRONIZADO" }} sincronizados • ${importResults.count { it.status == "NA_FILA" || it.status == "PENDENTE" }} pendentes • ${importResults.count { it.status == "FALHOU" }} falhas • ${importResults.count { it.status == "SEM_ALTERACOES" }} sem alterações • ${rejectedCsvRows.size} linhas CSV rejeitadas", color = TextMuted, fontSize = 10.sp)
                                importResults.take(30).forEach { result ->
                                    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                        Text("${result.status} — ${result.title}", color = if (result.status == "FALHOU" || result.status == "PENDENTE") DangerRed else TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
                                        Text("${result.sourceId}/${result.externalProductId}: ${result.detail}", color = TextMuted, fontSize = 9.sp)
                                    }
                                }
                                rejectedCsvRows.take(10).forEach { row -> Text("CSV_REJEITADO — linha ${row.rowNumber}: ${row.reason}", color = DangerRed, fontSize = 9.sp) }
                                if (importResults.size > 30 || rejectedCsvRows.size > 10) Text("O relatório exportado inclui todos os registos, inclusive os que não aparecem nesta pré-visualização.", color = TextMuted, fontSize = 9.sp)
                                OutlinedButton(onClick = { reportSaver.launch("macumu_relatorio_importacao.csv") }, modifier = Modifier.fillMaxWidth()) { Text("Exportar relatório CSV", color = TextWhite) }
                                OutlinedButton(onClick = onRetryCatalogSync, modifier = Modifier.fillMaxWidth()) { Text("Tentar novamente sincronização", color = TextWhite) }
                                if (catalogRetryMessage.isNotBlank()) Text(catalogRetryMessage, color = TextMuted, fontSize = 10.sp)
                            }
                        }
                    }
                }
                item {
                    Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = DarkNavyCard), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Fontes e estado dos conectores", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            CatalogConnectorRegistry.connectors.forEach { connector ->
                                Text(connector.displayName, color = MacumuOrange, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                                Text(connector.description, color = TextMuted, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
            "GERAL" -> {
                // Key Metrics
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Escrow Balance
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF281E0D)),
                                border = BorderStroke(1.dp, EscrowAmber),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Lock, contentDescription = null, tint = EscrowAmber, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Custódia Retida", color = EscrowAmber, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = CurrencyUtils.formatPrice(financialStats.escrowLockedMzn, currency),
                                        color = TextWhite,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 15.sp
                                    )
                                }
                            }

                            // Platform Fees
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F2618)),
                                border = BorderStroke(1.dp, MpesaGreen),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = MpesaGreen, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Receita Macumu (5%)", color = MpesaGreen, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = CurrencyUtils.formatPrice(financialStats.platformCommissionsMzn, currency),
                                        color = TextWhite,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 15.sp
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Total GMV
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                                border = BorderStroke(1.dp, DarkNavyCardBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Volume Transaccionado (GMV)", color = TextMuted, fontSize = 10.5.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = CurrencyUtils.formatPrice(financialStats.totalGmvMzn, currency),
                                        color = MacumuOrange,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                            }

                            // Orders Count
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                                border = BorderStroke(1.dp, DarkNavyCardBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Total Encomendas", color = TextMuted, fontSize = 10.5.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${financialStats.totalOrdersCount} encomendas",
                                        color = TextWhite,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Recent Activity / Registered Products overview
                item {
                    Text("Catálogo e Vendedores Activos", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                items(products.take(4)) { prod ->
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                        border = BorderStroke(1.dp, DarkNavyCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(prod.title, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
                                Text("${prod.sellerName} (${prod.sellerType}) • ${prod.sellerLocation}", color = TextMuted, fontSize = 10.5.sp)
                            }
                            Text(
                                text = CurrencyUtils.formatPrice(prod.promoPriceMzn ?: prod.priceMzn, currency),
                                color = MacumuOrange,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            "DISPUTAS" -> {
                if (disputes.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                            modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
                        ) {
                            Text(
                                text = "Nenhuma disputa em aberto. Todos os clientes e vendedores estão em conformidade.",
                                color = TextMuted,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                } else {
                    items(disputes) { dispute ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                            border = BorderStroke(1.dp, if (dispute.status == "EM_ANALISE") DangerRed else DarkNavyCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Encomenda: ${dispute.orderCode}",
                                        color = TextWhite,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (dispute.status == "EM_ANALISE") DangerRed.copy(alpha = 0.2f) else MpesaGreen.copy(alpha = 0.2f)
                                    ) {
                                        Text(
                                            text = dispute.status,
                                            color = if (dispute.status == "EM_ANALISE") DangerRed else MpesaGreen,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Reclamante: ${dispute.buyerName} vs ${dispute.sellerName}",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "Motivo: ${dispute.reason}",
                                    color = TextWhite,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.5.sp
                                )
                                Text(
                                    text = dispute.description,
                                    color = TextDarkMuted,
                                    fontSize = 10.5.sp
                                )

                                if (dispute.status == "EM_ANALISE") {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                onResolveDispute(
                                                    dispute.id,
                                                    dispute.orderCode,
                                                    true,
                                                    "Reembolso total autorizado após mediação Macumu"
                                                )
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                                            modifier = Modifier.weight(1f).height(34.dp)
                                        ) {
                                            Text("Reembolsar Comprador", fontSize = 10.5.sp)
                                        }

                                        Button(
                                            onClick = {
                                                onResolveDispute(
                                                    dispute.id,
                                                    dispute.orderCode,
                                                    false,
                                                    "Comprovativo de entrega validado. Fundos libertados ao vendedor."
                                                )
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MpesaGreen),
                                            modifier = Modifier.weight(1f).height(34.dp)
                                        ) {
                                            Text("Libertar p/ Vendedor", fontSize = 10.5.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            "LEVANTAMENTOS" -> {
                if (withdrawals.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                            modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
                        ) {
                            Text(
                                text = "Nenhum pedido de levantamento pendente.",
                                color = TextMuted,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                } else {
                    items(withdrawals) { w ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                            border = BorderStroke(1.dp, DarkNavyCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${w.beneficiaryName} (${w.beneficiaryType})",
                                        color = TextWhite,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = CurrencyUtils.formatPrice(w.amountMzn, currency),
                                        color = MacumuOrange,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp
                                    )
                                }

                                Text(
                                    text = "Canal: ${w.method} • Conta: ${w.phoneNumberOrAccount}",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                if (w.status == "PENDENTE") {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { onProcessWithdrawal(w.id, true) },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MpesaGreen),
                                            modifier = Modifier.weight(1f).height(32.dp)
                                        ) {
                                            Text("Aprovar Payout", fontSize = 11.sp)
                                        }

                                        OutlinedButton(
                                            onClick = { onProcessWithdrawal(w.id, false) },
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, DangerRed),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                                            modifier = Modifier.weight(1f).height(32.dp)
                                        ) {
                                            Text("Recusar", fontSize = 11.sp)
                                        }
                                    }
                                } else {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (w.status == "APROVADO") MpesaGreen.copy(alpha = 0.2f) else DangerRed.copy(alpha = 0.2f)
                                    ) {
                                        Text(
                                            text = "Status: ${w.status}",
                                            color = if (w.status == "APROVADO") MpesaGreen else DangerRed,
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            "LEDGER" -> {
                item {
                    Text(
                        text = "Livro-Razão Contabilístico Imutável (Double-Entry Ledger)",
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp
                    )
                }

                if (ledgerEntries.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Nenhuma movimentação contabilística ainda.",
                                color = TextMuted,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                } else {
                    items(ledgerEntries) { entry ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                            border = BorderStroke(0.5.dp, DarkNavyCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = entry.account,
                                            color = when (entry.account) {
                                                "ESCROW_CUSTODIA" -> EscrowAmber
                                                "CARTEIRA_VENDEDOR" -> MpesaGreen
                                                "CARTEIRA_AFILIADO" -> EmolaBlue
                                                else -> MacumuOrange
                                            },
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(text = "• ${entry.type}", color = TextMuted, fontSize = 10.sp)
                                    }
                                    Text(text = entry.description, color = TextWhite, fontSize = 11.sp, maxLines = 2)
                                    Text(text = "Ref: ${entry.transactionRef} | Enc: ${entry.orderCode}", color = TextDarkMuted, fontSize = 9.sp)
                                }

                                Text(
                                    text = "${if (entry.type == "CREDITO") "+" else "-"}${CurrencyUtils.formatPrice(entry.amountMzn, currency)}",
                                    color = if (entry.type == "CREDITO") MpesaGreen else DangerRed,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.5.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
