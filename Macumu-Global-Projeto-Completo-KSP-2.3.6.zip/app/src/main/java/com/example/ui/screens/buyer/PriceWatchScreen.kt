package com.example.ui.screens.buyer

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.PriceWatchEntity
import com.example.data.local.PriceHistoryEntity
import com.example.data.local.ProductEntity
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.MacumuOrange
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.util.CurrencyUtils

@Composable
fun PriceWatchScreen(
    watches: List<Pair<ProductEntity, PriceWatchEntity>>,
    history: Map<String, List<PriceHistoryEntity>>,
    currency: String,
    onRemove: (Long) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = MacumuOrange)
            Text("Macumu Price Watch", color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 9.dp))
        }
        Text(
            "Acompanha os preços e recebe um aviso quando o valor chegar ao teu objectivo.",
            color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 16.dp)
        )
        if (watches.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = DarkNavyCard), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Ainda não acompanhas nenhum produto.", color = TextWhite, fontWeight = FontWeight.SemiBold)
                    Text("Na vitrine, toca no sino de um produto e define o teu preço-alvo.", color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(watches, key = { it.second.globalProductId }) { (product, watch) ->
                    val current = product.promoPriceMzn ?: product.priceMzn
                    Card(colors = CardDefaults.cardColors(containerColor = DarkNavyCard), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(product.title, color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(product.marketName.ifBlank { product.sellerName }, color = TextMuted, fontSize = 11.sp)
                                }
                                IconButton(onClick = { onRemove(product.id) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Remover acompanhamento", tint = TextMuted)
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text("Preço actual", color = TextMuted, fontSize = 10.sp)
                                    Text(CurrencyUtils.formatPrice(current, currency), color = TextWhite, fontWeight = FontWeight.Bold)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Preço-alvo", color = TextMuted, fontSize = 10.sp)
                                    Text(CurrencyUtils.formatPrice(watch.targetPriceMzn, currency), color = MacumuOrange, fontWeight = FontWeight.Bold)
                                }
                            }
                            val difference = ((watch.baselinePriceMzn - current) / watch.baselinePriceMzn * 100.0).coerceIn(-100.0, 100.0)
                            Text(
                                text = if (difference >= 0) "Variação desde o início: -${"%.1f".format(difference)}%" else "Variação desde o início: +${"%.1f".format(-difference)}%",
                                color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 7.dp)
                            )
                            Text("Última observação: ${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(watch.updatedAt))}", color = TextMuted, fontSize = 10.sp)
                            val recentPrices = history[watch.globalProductId].orEmpty().take(5)
                            if (recentPrices.isNotEmpty()) {
                                Text("Histórico recente", color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, modifier = Modifier.padding(top = 9.dp))
                                recentPrices.forEach { entry ->
                                    Text(
                                        "${CurrencyUtils.formatPrice(entry.priceMzn, currency)} • ${java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(entry.capturedAt))}",
                                        color = TextMuted, fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
