package com.example.recommendations

import com.example.data.local.ProductEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RecommendationEngineTest {
    private fun product(
        id: Long,
        category: String,
        title: String = "Produto $id",
        rating: Float = 4.0f,
        stock: Int = 5,
        market: String = "Loja Central",
        featured: Boolean = false
    ) = ProductEntity(
        id = id,
        globalProductId = "global-$id",
        title = title,
        description = "Descrição",
        category = category,
        priceMzn = 1000.0,
        stock = stock,
        sellerId = 1,
        sellerName = "Vendedor",
        sellerType = "FORMAL",
        sellerLocation = "Maputo",
        rating = rating,
        reviewCount = 10,
        marketName = market,
        isFeatured = featured
    )

    @Test fun `prioriza categoria dos favoritos e exclui indisponiveis e favoritos`() {
        val favorite = product(1, "Electrónica")
        val related = product(2, "Electrónica", rating = 4.1f)
        val unrelated = product(3, "Moda", rating = 5.0f)
        val outOfStock = product(4, "Electrónica", stock = 0, rating = 5.0f)

        val result = RecommendationEngine.recommend(
            products = listOf(favorite, related, unrelated, outOfStock),
            favoriteProductIds = setOf(1),
            watchedGlobalIds = emptySet()
        )

        assertEquals(listOf(2L, 3L), result.products.map { it.id })
        assertTrue(result.explanation.contains("favoritos"))
    }

    @Test fun `usa produto acompanhado para reforcar categoria`() {
        val watched = product(1, "Casa")
        val related = product(2, "Casa", rating = 3.5f)
        val popular = product(3, "Moda", rating = 5.0f, featured = true)

        val result = RecommendationEngine.recommend(
            products = listOf(watched, related, popular),
            favoriteProductIds = emptySet(),
            watchedGlobalIds = setOf("global-1")
        )

        assertEquals(2L, result.products.first().id)
        assertTrue(result.explanation.contains("acompanha"))
    }
}
