/**
 * Run only in a trusted administrator environment with GOOGLE_APPLICATION_CREDENTIALS
 * pointing to a service-account JSON that has Firebase Auth Admin privileges.
 * Never bundle a service-account key in the Android app or commit it to Git.
 * Usage: node scripts/set-admin-claim.mjs <FIREBASE_AUTH_UID>
 */
import { initializeApp, applicationDefault } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";

const uid = process.argv[2];
if (!uid) {
  console.error("Uso: node scripts/set-admin-claim.mjs <FIREBASE_AUTH_UID>");
  process.exit(1);
}
initializeApp({ credential: applicationDefault(), projectId: "macumu-global" });
const auth = getAuth();
const user = await auth.getUser(uid);
await auth.setCustomUserClaims(uid, { ...(user.customClaims ?? {}), admin: true });
console.log(`Claim admin=true atribuído a ${uid}. Termine sessão e entre novamente na aplicação para actualizar o token.`);
