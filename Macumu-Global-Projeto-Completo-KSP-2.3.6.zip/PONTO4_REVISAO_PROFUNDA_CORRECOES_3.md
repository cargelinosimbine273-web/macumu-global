# Macumu Global — Ponto 4: revisão profunda, ronda 3

## Escopo desta ronda

Esta ronda corrige a gestão do token FCM por instalação/conta, o encerramento de sessão e a solicitação da permissão de notificações no Android 13+.

## Alterações efectuadas

1. `PushTokenRegistrar` guarda localmente o UID e o token efectivamente registado nesta instalação.
2. Ao ocorrer rotação do token FCM, tenta remover o token anterior da subcolecção `users/{uid}/deviceTokens` antes de registar o novo.
3. A gravação do token verifica a sessão antes de escrever e novamente no callback, para evitar associar callbacks atrasados à conta errada.
4. O logout nos dois pontos de interface passa pelo `PushTokenRegistrar.signOut(context)`: tenta apagar o token enquanto a sessão ainda está autenticada e só depois termina a sessão.
5. O listener de autenticação deixou de tentar apagar o token depois do logout, momento em que as regras Firestore já não autorizariam a operação.
6. A permissão `POST_NOTIFICATIONS` deixou de ser pedida indiscriminadamente no arranque de visitantes. Para utilizadores autenticados, o pedido automático ocorre no máximo uma vez; se for recusado, a pessoa poderá activá-lo nas definições Android.
7. O identificador da notificação local de Price Watch passou a incorporar UID + produto, reduzindo colisões entre contas no mesmo dispositivo.

## Limitações conhecidas

- O logout espera pela conclusão da tentativa de eliminação do token no Firestore. Se o dispositivo estiver offline ou a operação ficar pendente, o logout poderá demorar; se a operação falhar, o token remoto poderá permanecer registado. Um backend confiável seria necessário para gerir revogação e envio centralizados de forma robusta.
- O pedido de permissão é feito uma vez automaticamente. Depois de recusa, a aplicação ainda precisa de uma entrada de definições para orientar o utilizador a activar manualmente as notificações nas definições do Android.
- O FCM continua apenas receptor. Não existe envio automático provocado por alterações Firestore no Firebase Spark sem um servidor confiável.
- WorkManager é periódico e oportunista: o intervalo mínimo configurado não garante execução exacta a cada 15 minutos.
- Não foi executada compilação Android nem teste em dispositivo nesta ronda. O projecto não contém `gradlew` e não foi encontrado Gradle instalado no ambiente.

## Verificações realizadas

- Revisão estática dos pontos de registo/rotação/remoção do token e dos dois fluxos de logout.
- Revisão estática da permissão Android 13+ e do identificador das notificações locais.
- Verificação de integridade do ZIP após empacotamento.

## Estado

Ponto 4 continua em revisão. Esta ronda não constitui certificação de compilação nem validação funcional.
