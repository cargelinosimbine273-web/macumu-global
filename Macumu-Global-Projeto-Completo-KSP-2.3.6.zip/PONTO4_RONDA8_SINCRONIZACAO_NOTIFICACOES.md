# Ponto 4 — Ronda 8: sincronização de notificações

## Alterações
- A caixa de notificações continua isolada por UID em `users/{uid}/notifications`.
- Ao receber documentos do Firestore, a aplicação insere notificações ausentes localmente sem duplicar o mesmo `eventKey`.
- O estado `isRead` recebido da nuvem agora actualiza também o registo local já existente, resolvendo a divergência entre dispositivos.
- O ViewModel expõe `markNotificationAsRead(notification)`: actualiza primeiro o estado local e depois o documento da conta no Firestore.
- A sincronização continua a depender da autenticação e das regras Firestore publicadas.

## Recuperação após reinstalação
Quando o utilizador volta a autenticar-se, o listener lê a caixa da conta no Firestore e repovoa a base Room. Notificações que existiam apenas localmente e nunca chegaram à nuvem não podem ser recuperadas após desinstalação.

## Limitações / validação
- O método de marcar como lida fica disponível no ViewModel; a ligação ao gesto de leitura do ecrã deverá ser feita quando a navegação/UX de notificações for consolidada.
- As regras Firestore precisam de estar publicadas na consola Firebase.
- Não foi executada compilação Android nem teste funcional: este projecto continua sem `gradlew` e sem Gradle instalado no ambiente.
- O listener Firestore permite sincronização em tempo real enquanto há conectividade; a cache offline do SDK pode atrasar a convergência até a rede regressar.
