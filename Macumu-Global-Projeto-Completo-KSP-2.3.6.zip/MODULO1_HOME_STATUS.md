# Macumu Global — Módulo 1 Home Dashboard

## Escopo do Módulo 1
1. Favoritos e sincronização de conta.
2. Macumu Price Watch.
3. Recomendações inteligentes.
4. Notificações push.
5. Campanhas dinâmicas.
6. Segurança e permissões.
7. Integração geral e consolidação.

## Estado nesta entrega

- Ponto 1: implementação consolidada no código; **não validada por compilação/testes**.
- Pontos 2–5: existem partes anteriores no projecto, mas ainda não foram auditadas como sistemas completos nesta consolidação.
- Ponto 6: regras e Cloud Function propostas incluídas; implantação/claims dependem de acção no Firebase Console/CLI.
- Ponto 7: integração estrutural reunida; testes completos pendentes.

Não considerar o Módulo 1 concluído até executar a lista de validação em `MODULO1_PONTO1_CONSOLIDADO.md` e a bateria global de testes.
