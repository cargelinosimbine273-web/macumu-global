# Macumu Global — Ronda 10.1: Importador CSV integrado no painel administrativo

## O que foi ligado
- Novo separador **Importar** no painel administrativo.
- Selecção de ficheiro CSV através do selector de documentos Android.
- Leitura UTF-8, validação pelo `CatalogCsvImporter` existente e pré-visualização antes de submeter.
- Exibição do estado real dos conectores (não declara APIs externas como activas).
- Submissão apenas das ofertas em MZN nesta fase. Outras moedas permanecem fora da publicação até existir uma fonte de câmbio fiável e uma política de conversão aprovada.
- Produtos importados são criados como **pendentes de aprovação**, nunca publicados automaticamente.
- Cada produto mantém a referência externa, URL original e URL de afiliado na descrição, além da imagem e origem.
- Identificador determinístico por conta + fonte + ID externo impede que a mesma linha seja importada repetidamente pela mesma conta.
- Utiliza o mecanismo Room + fila de sincronização Firestore já existente; não exige servidor, Cloud Functions, API paga ou credenciais no APK.

## Fluxo operacional
1. Entrar no painel administrativo autorizado.
2. Abrir o separador **Importar**.
3. Seleccionar o CSV preenchido pelo fornecedor ou pela equipa Macumu.
4. Rever a pré-visualização e a contagem de ofertas válidas.
5. Submeter os produtos em MZN.
6. Os produtos ficam pendentes e são enviados pela fila de catálogo quando a conta tem sessão e rede.
7. Um administrador com a autorização Firebase `admin=true` aprova/rejeita o produto. As regras Firestore continuam a ser a fronteira de segurança.

## Limitações deliberadas
- Só MZN é submetido para publicação porque `ProductEntity.priceMzn` representa meticais. Não converter USD/EUR/CNY/ZAR com taxas inventadas.
- A importação não confirma stock, entrega, garantia ou autenticidade do fornecedor. Esses dados devem ser verificados antes da aprovação.
- O preço e a disponibilidade externos podem mudar. A equipa deve actualizar o CSV e reimportar; duplicados da mesma conta/fonte/ID externo são ignorados, portanto actualizações exigem uma futura função de actualização/revisão explícita.
- URLs originais e de afiliado são preservadas como texto de referência. A ligação de compra/afiliado na interface pública ainda exige um campo de destino próprio e revisão UX antes de anunciar essa função como activa.
- A integração automática com AliExpress, Alibaba, SHEIN e Digistore24 continua dependente de aprovação, chave ou feed autorizado.

## Modelo
Ver `MODELO_IMPORTACAO_CATALOGO.csv`. Cabeçalhos obrigatórios: `sourceId,externalProductId,title,price,currency,productUrl`.

## Validação
Revisão estática dos pontos de integração realizada. Não foi executada compilação Android nem teste funcional. O projecto ainda não contém `gradlew` executável e este ambiente não tem Gradle instalado. Regras Firestore devem ser publicadas no Firebase Console antes de sincronizar.
